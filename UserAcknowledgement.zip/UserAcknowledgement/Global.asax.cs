﻿using AssetManagement;
using AssetManagementLibrary;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using Microsoft.IdentityModel.Claims;
using System.IO;
using UserAcknowledgement.App_Start;

namespace UserAcknowledgement
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }

        protected void Session_Start(object sender, EventArgs e)
        {
            Queries queryHelper = new Queries();

            IClaimsIdentity identity = (ClaimsIdentity)base.User.Identity;
            string upn = identity.Claims.Where(c => c.ClaimType == ClaimTypes.Upn).First().Value;

            //string upn = "19047";



            DataSet ds = new DataSet();
            var iploginuser = new List<InputParameters>
                        {
                            new InputParameters {SqlParam = "loginID", ParamValue =@"ITCINFOTECH\" +upn},//@"ITCINFOTECH\" +upn   //User.Identity.Name
                            new InputParameters {SqlParam = "ApplicationID", ParamValue = 22}
                        };
            ds = queryHelper.Getcredentials(iploginuser);

            foreach (DataRow dt in ds.Tables[0].Rows)
            {
                //Session["IsAuthorized"] = dt.Field<Int16>("RoleID");
                Session["EmailID"] = dt.Field<string>("EMAILID");
                Session["IsAuthorized"] = 1;
                Session["PSID"] = dt.Field<string>("PSID");
                Session["Username"] = dt.Field<string>("Name");
                Session["Deptid"] = dt.Field<string>("Deptid");
                Session["Grade"] = dt.Field<string>("Grade");
                Session["PendingReview"] = dt.Field<int>("PendingReview");
            }

            //UserInfo.Instance.UserPSID = Convert.ToString(Session["PSID"]);
            //UserInfo.Instance.EmailID = Convert.ToString(Session["EmailID"]);
            //UserInfo.Instance.DisplayName= Convert.ToString(Session["Username"]);
            //Change According to your testing
            //iploginuser[0].ParamValue = @"ITCINFOTECH\206211"; 
            Session["UserProfile"] = Queries.GetUserProfile(iploginuser);

        }

        private void Application_BeginRequest(object sender, EventArgs e)
        {
            if (String.Compare(Request.Path, Request.ApplicationPath, StringComparison.InvariantCultureIgnoreCase) == 0
                && !(Request.Path.EndsWith("/")))
                Response.Redirect(Request.Path + "/");
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            //Exception _exc = Server.GetLastError();
            //if (_exc.GetType() != typeof(HttpException)) return;
            //if (_exc.Message.Contains("NoCatch") || _exc.Message.Contains("maxUrlLength"))
            //    return;


            //Server.Transfer("Errorpage404.html");
            LogError(Server.GetLastError());

        }
        private void LogError(Exception ex)
        {
            try
            {
                Exception CurrentException = Server.GetLastError();
                string ErrorDetails = CurrentException.ToString();

                File.WriteAllText(Server.MapPath("~/ErrorLog.txt"), ErrorDetails);
            }
            catch (Exception)
            {


            }

        }
    }
}
