﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace UserAcknowledgement.App_Start
{
    public class SettingConfig
    {
    }

    public class EmailConfig
    {
        public static string ToEmailID
        {
            get { return ConfigurationManager.AppSettings["ToEmailAddress"]; }
        }

        public static string ToDevEmailID
        {
            get { return ConfigurationManager.AppSettings["ToDevEmailAddress"]; }
        }

        public static string Host
        {
            get { return ConfigurationManager.AppSettings["smtpHost"]; }
        }

        public static int Port
        {
            get { return int.Parse(ConfigurationManager.AppSettings["smtpPort"]); }
        }

        public static string Subject
        {
            get { return ConfigurationManager.AppSettings["EmailSubject"]; }
        }

        public static string CcDevEmailAddress
        {
            get { return ConfigurationManager.AppSettings["CcDevEmailAddress"]; }
        }

        public static string CcEmailAddress
        {
            get { return ConfigurationManager.AppSettings["CcEmailAddress"]; }
        }

        //06/04/2017
        public static string BccDevEmailAddress
        {
            get { return ConfigurationManager.AppSettings["BccDevEmailAddress"]; }
        }

        public static string BccEmailAddress
        {
            get { return ConfigurationManager.AppSettings["BccEmailAddress"]; }
        }

        public static Boolean IsCcReq
        {
            get { return Convert.ToBoolean(ConfigurationManager.AppSettings["IsCcReq"]); }
        }

        public static Boolean IsBccReq
        {
            get { return Convert.ToBoolean(ConfigurationManager.AppSettings["IsBccReq"]); }
        }
        //End
    }

    public class DefaultConfig
    {
        public static bool IsDev
        {
            get { return  bool.Parse(ConfigurationManager.AppSettings["IsDev"]); }
        }
    }
}