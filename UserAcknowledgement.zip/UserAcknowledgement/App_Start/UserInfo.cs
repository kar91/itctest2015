﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UserAcknowledgement.App_Start
{
    public class UserInfo
    {



        //private static UserInfo _instance = null;
        //private UserInfo() { }

        //public static UserInfo Instance
        //{
        //    get
        //    {
        //        if (_instance == null)
        //        {
        //            _instance = new UserInfo();

        //        }
        //        return _instance;
        //    }
        //} 
         

        private string _UserPSID;

        public string UserPSID
        {
            get { return _UserPSID; }
            set { _UserPSID = value; }
        }

        private string _EmailID;

        public string EmailID
        {
            get { return _EmailID; }
            set { _EmailID = value; }
        }

        private string _DisplayName;

        public string DisplayName
        {
            get { return _DisplayName; }
            set { _DisplayName = value; }
        }

    }
}