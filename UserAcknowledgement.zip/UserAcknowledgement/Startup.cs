﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(UserAcknowledgement.Startup))]
namespace UserAcknowledgement
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
