﻿using AssetManagement;
using AssetManagementLibrary;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.OtherHelpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using UserAcknowledgement.App_Start;
using UserAcknowledgement.Models;

namespace Prototype_v1.Controllers
{
    public class HomeController : Controller
    {



        public ActionResult LoadProfile()
        {

            //   var ds = (UserProfile)Session["UserProfile"];
            ViewBag.username = Session["Username"].ToString();
            ViewBag.psid = "https://profiles.app.itcinfotech.com/USER%20PHOTOS/_w/AV" + Session["PSID"].ToString() + "_jpg.JPG";
            // ViewBag.grade =Session["upn"].ToString();
            return View();
        }

        [HttpGet]
        public ActionResult GetPendingAssets()
        {

            var result = new JsonResult();
            var ipGetAssetsForEndUser = new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserPSID", ParamValue = Session["PSID"].ToString()}
            };
            var pendingDataSet = Extensions.RemoveDuplicates(QueryHelper.GetAssetsForEndUser(ipGetAssetsForEndUser));
            result.Data = new JavaScriptSerializer().Serialize(pendingDataSet);
            return this.Json(result, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public ActionResult GetAcknowledgedAssets()
        {

            var result = new JsonResult();
            var ipGetAckAssetsForEndUser = new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserPSID", ParamValue = Session["PSID"].ToString()}
            };
            var acknowledgedDataSet = QueryHelper.GetAcknowledgedAssetsForEndUser(ipGetAckAssetsForEndUser);
            result.Data = new JavaScriptSerializer().Serialize(acknowledgedDataSet);
            return this.Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult getJson(string param, string comments, string stage, string assettranid, string acknowledge)
        {
            AssetManagementLibrary.Queries qryhelper = new Queries();
            var ipUpdateAssetStatus = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AssetTranID", ParamValue = int.Parse(assettranid)},
                new InputParameters {SqlParam = "SysPurposeStageID", ParamValue = int.Parse(stage)},
                new InputParameters {SqlParam = "ModBy", ParamValue = Session["PSID"].ToString()},
                new InputParameters {SqlParam = "IsEndUserAcknowledged", ParamValue = acknowledge.ToString() == "enduseracknowledge" ? true : false},
                new InputParameters {SqlParam = "Comments", ParamValue = comments.ToString() == "" ? null : Session["PSID"].ToString() + ":User: " + comments.ToString()}
            };
            qryhelper.UpdateForEndUserAck(ipUpdateAssetStatus);
            return null;
        }
        [HttpGet]
        public ActionResult SendMail(string param, string mailbody, string serialNo, string emailid, string assettranid)
        {
            AssetManagementLibrary.Queries qryhelper = new Queries();
            var ipUpdateAssetStatus = SetParamForUserProfile();
            var userProfile = qryhelper.GetUserInfo(ipUpdateAssetStatus);
            var userProfileJson = JsonConvert.SerializeObject(userProfile, Formatting.None, new JsonSerializerSettings() { ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore });
            //seating plan
            dynamic seating = JsonConvert.DeserializeObject(userProfileJson);
            string seatingdetail = (string)((Newtonsoft.Json.Linq.JObject)seating).SelectToken("Table[0].ToBuilding") + "," + (string)((Newtonsoft.Json.Linq.JObject)seating).SelectToken("Table[0].ToArea") + "-" + (string)((Newtonsoft.Json.Linq.JObject)seating).SelectToken("Table[0].ToCubicleNo") + "," + (string)((Newtonsoft.Json.Linq.JObject)seating).SelectToken("Table[0].ToLocation");

            UserInfo objInfo = new UserInfo();
            objInfo.UserPSID= Convert.ToString(Session["PSID"]);
            objInfo.EmailID= Convert.ToString(Session["EmailID"]);
            objInfo.DisplayName=  Convert.ToString(Session["Username"]);

            Task.Factory.StartNew(() =>
            {
                try
                {
                    MailMessage mail = new MailMessage();
                    //  mail.To.Add(ConfigurationManager.AppSettings["EmailFromAddress"].ToString());
                    string configemailid = DefaultConfig.IsDev ? EmailConfig.ToDevEmailID : EmailConfig.ToEmailID;
                    mail.To.Add(configemailid);
                    string ccemailid = DefaultConfig.IsDev ? EmailConfig.CcDevEmailAddress : EmailConfig.CcEmailAddress;
                    if (EmailConfig.IsCcReq)
                        mail.CC.Add(ccemailid);
                    string bccemailid = DefaultConfig.IsDev ? EmailConfig.BccDevEmailAddress : EmailConfig.BccEmailAddress;
                    if (EmailConfig.IsBccReq)
                        mail.Bcc.Add(bccemailid);
                    mail.From = new MailAddress(objInfo.EmailID); //new MailAddress(Session["EmailID"].ToString());
                    mail.Subject = string.Format(EmailConfig.Subject + serialNo, param);


                    string Body = string.Empty;
                    //            string Body = "<html><body><div style='width:100%'>Hello,</div><div style='width:100%;padding-left:2em;margin-bottom:2em;margin-top:1em'>"+mailbody+"</div><div style='width:100%'><table><tr><td>Regards</td></tr><tr><td>" + Session["Username"] .ToString()+ "</td></tr></div></body></html>";

                    using (var reader = new StreamReader(Server.MapPath("~/App_Data/MailTemplate.html")))
                    {
                        Body = String.Format(reader.ReadToEnd(), objInfo.UserPSID, objInfo.DisplayName, seatingdetail, param, serialNo, mailbody, objInfo.DisplayName, objInfo.UserPSID);//Session["Username"].ToString()
                    }

                    mail.Body = Body;
                    mail.IsBodyHtml = true;
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = EmailConfig.Host;
                    smtp.Port = EmailConfig.Port;
                    smtp.UseDefaultCredentials = false;
                    smtp.Credentials = new System.Net.NetworkCredential("username", "password");

                    smtp.Send(mail);
                }
                catch (Exception ex)
                {

                }
            });
            int i;
            var ipassetdiscrepancy = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AssetTranID", ParamValue = (int.TryParse (assettranid, out i) ? (int?) i : null)},//int.Parse(assettranid)
                new InputParameters {SqlParam = "SerialNo", ParamValue = serialNo},
                new InputParameters {SqlParam = "UserPSID", ParamValue = Session["PSID"].ToString()},
                new InputParameters {SqlParam = "Comments", ParamValue = mailbody},
                new InputParameters {SqlParam = "IsActive", ParamValue =true}
            };


            var isinserted = qryhelper.InsertAssetdiscrepancy(ipassetdiscrepancy);

            return null;
        }

        [HttpGet]
        public ActionResult GetUserProfile()
        {

            var result = new JsonResult();
            AssetManagementLibrary.Queries qryhelper = new Queries();
            var ipUpdateAssetStatus = SetParamForUserProfile();
            var userProfile = qryhelper.GetUserInfo(ipUpdateAssetStatus);
            var userProfileJson = JsonConvert.SerializeObject(userProfile, Formatting.None, new JsonSerializerSettings() { ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore });

            return this.Json(userProfileJson, JsonRequestBehavior.AllowGet);
        }

        List<InputParameters> SetParamForUserProfile()
        {
            return new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserPSID", ParamValue = Session["PSID"].ToString()},

            };
        }

        public AssetManagementLibrary.Queries QueryHelper
        {
            get
            {
                return new AssetManagementLibrary.Queries();
            }
        }
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}