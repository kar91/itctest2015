﻿/// <reference path="c:\users\14950\documents\visual studio 2015\Projects\Prototype_v1\Prototype_v1\Scripts/angular.js" />
/// <reference path="c:\users\14950\documents\visual studio 2015\Projects\Prototype_v1\Prototype_v1\Scripts/angular-route.js" />
/// <reference path="c:\users\14950\documents\visual studio 2015\Projects\Prototype_v1\Prototype_v1\Angulartemplates/Profile.html" />
/// <reference path="c:\users\14950\documents\visual studio 2015\Projects\Prototype_v1\Prototype_v1\AngularDirectivetemplates/ActionButton.html" />

var ApplictaionModule = angular.module("mainmod", ['ngRoute', 'ngAnimate', 'angularModalService']);

///controllers

var profilecontroller = ApplictaionModule.controller("profilecontroller", ['$scope', '$location', function ($scope, $location) {

    $scope.test = "alloha1";
    $scope.windowurl = function (path) {
        $location.path(path);

    }
}])


var templatecontroller = ApplictaionModule.controller("templatecontroller", ['$scope', '$location', function ($scope, $location) {


    $scope.windowurl = function (path) {
        alert()
        $location.path(path);

    }
}])


var settingscontroller = ApplictaionModule.controller("settingscontroller", ['$scope', '$location', '$http', function ($scope, $location, $http) {
    var rawdatalist = [];
    $scope.datalist = [];
    $scope.x = false;

    $http({
        method: "GET",
        url: "home/GetPendingAssets"
    }).then(function mySucces(response) {


        rawdatalist = JSON.parse(response.data.Data);
        $scope.datalist =
            _.filter((rawdatalist), function (item) {

                item.IsEndUserAcknowledged = (item.IsEndUserAcknowledged);

                return item.IsEndUserAcknowledged === null;
            })
        $scope.pendinglist = Object.keys($scope.datalist).length;
    }, function myError(response) {
        $scope.myWelcome = response;
    });



    $scope.windowurl = function (path) {

        $location.path(path);

    }
}])

var profilecontroller = ApplictaionModule.controller("profilecontroller", ['$scope', '$location', '$http', '$route', function ($scope, $location, $http, $route) {
    $scope.x = true;
    $scope.datalist = [];
    $http({
        method: "GET",
        url: "home/GetUserProfile"
    }).then(function mySucces(response) {
        $scope.datalist = JSON.parse(response.data);
    }, function myError(response) {
        $scope.myWelcome = response;
    });

}])
var acknowledgecontroller = ApplictaionModule.controller("acknowledgecontroller", ['$scope', '$location', 'ModalService', '$http', '$route', '$sce', function ($scope, $location, ModalService, $http, $route, $sce) {
    $scope.x = true;

    $scope.datalist = [];
    $http({
        method: "GET",
        url: "home/GetPendingAssets"
    }).then(function mySucces(response) {

        $scope.datalist = JSON.parse(response.data.Data);
    }, function myError(response) {
        $scope.myWelcome = response;
    });


    $scope.acknowledge = function (id, key) {
        $http({
            method: "GET",
            url: "home/getJson",
            params: { param: 'param', comments: '', stage: id, assettranid: key, acknowledge: 'enduseracknowledge' }
        }).then(function mySucces(response) {

            $route.reload();

        }, function myError(response) {
            $scope.myWelcome = response;
        });
    }

    $scope.show = function (nextstatus, assettranid, type, header) {
        $("#parentbody").empty();
        _base = [];
        _commentsplit = [];


        var objArr = angular.fromJson($scope.datalist).filter(function (item) {
            if (item.AssetTranId === assettranid) {

                return true;

            }
        });
        var htmlstr = '';
        if (objArr[0].Comments !== null) {
            _base = objArr[0].Comments.split('|')

            $.each(_base, function (key, value) {
                if (value !== "") {

                    _commentsplit.push(value.split(":"));

                }
            });


            $.each(_commentsplit, function (key, value) {


                if (value !== "") {
                    if (angular.isUndefined(value[2])) {
                        value[2] = "Asset Redeployed";
                    }
                    htmlstr += '<tr><td  style="vertical-align: top;width:1%;"><div style="width: 50px; height: 50px; border-radius: 50%; background-color: #009688;">\
                             <img src="https://profiles.app.itcinfotech.com/USER%20PHOTOS/_w/AV' + value[0] + '_jpg.JPG" ng-src="@ViewBag.psid" err-src="Images/defaultuser.png" style="max-height:100%;max-width:100%;border-radius:50%" />\
</div></td><td><div class="talk-bubble tri-right left-top"><div class="talktext">  \
                           <table style="width:100%"> <tr><td><div class="talktext"><p>' + value[2] + '</p></div></td> </tr><tr><td style="float: right"><p style="margin: 0px; font-size: 0.9em; color: #bbdefb">' + value[0] + '(' + value[1] + ')</p>\
                           </td></tr></table> </div></div></td></tr>';
                }
            });
        }
        $scope.body = htmlstr;
        $scope.renderHtml = function (html_code) {
            return $sce.trustAsHtml(html_code);
        };
        
        $scope.textArea = "";        
        $scope.textpattern = /^\s*$/g;
        $scope.stat = nextstatus;
        $scope.assettranid = assettranid;
        $scope.type = type;
        $scope.header = header;
        ModalService.showModal({
            scope: $scope,
            templateUrl: 'modal.html',
            controller: "ModalController"
        }).then(function (modal) {
            modal.element.modal();
            modal.close.then(function (data, result) {


            });
        });
    };

}])

ApplictaionModule.controller('ModalController', function ($scope, $http, $route, close) {

    $scope.close = function (data, result, key, type, assettype) {
        
        //console.log(data)
        id = result;
        comment = data;
        if (comment == null || comment == '')
            $scope.errormsg = "Please enter comments";
        //    return alert("Please enter comments")
        if (type === 'enduseracknowledge' || type === 'enduserreject') {
            $http({
                method: "GET",
                url: "home/getJson",
                params: { param: assettype, comments: comment, stage: id, assettranid: key, acknowledge: type }
            }).then(function mySucces(response) {

                $route.reload();

            }, function myError(response) {
                $scope.myWelcome = response;
            });
        }
        else if (type == 'revert') {
            //console.log(data)
            $http({
                method: "GET",
                url: "home/SendMail",
                params: { param: assettype, mailbody: data, serialNo: result, emailid: "handled in controller", assettranid: key }
            }).then(function mySucces(response) {

                $route.reload();

            }, function myError(response) {
                $scope.myWelcome = response;
            });
        }

        close(result, 500); // close, but give 500ms for bootstrap to animate
    };

    //if (acknowledge === 'acknowledge') {


    //}

});

ApplictaionModule.filter("mydate", function () {
    var re = /\/Date\(([0-9]*)\)\//;
    return function (x) {
        var m = x.match(re);
        if (m) return new Date(parseInt(m[1]));
        else return null;
    };
});
ApplictaionModule.filter('unique', function () {
    return function (collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };
});

function group(data, column) {
    var generatedData = {};
    $.each(data, function (i, dt) {
        var key = dt[column];
        if (!(key in generatedData)) {
            generatedData[key] = [];
        }
        generatedData[key].push(dt);
    });
    return generatedData;
}

var myassettablecontroller = ApplictaionModule.controller("myassettablecontroller", ['$scope', '$location', '$http', 'ModalService', function ($scope, $location, $http, ModalService) {
    $scope.x = 0;

    //  $scope.datalist = [{ "NextStage": null, "AssetType": "Monitor", "SerialNo": "CN03XNMH6418024B0R9L", "QRCode": null, "FromLocation": null, "FromBuilding": null, "FromArea": null, "FromCubicleNo": null, "FromName": null, "FromFloor": null, "ToLocation": null, "ToBuilding": "Tripti", "ToArea": null, "ToCubicleNo": "6", "FARNumber": "AMSTP-000000020914", "ToName": "Kalyani Kumari", "ToFloor": "B Block", "CurrentStatus": "User_Ack", "NextStatus": null, "OverSeer": null, "Psid": null, "FromBuildingId": null, "ToBuildingId": null, "CreatedByName": null, "FromEngineer": null, "ToEngineer": null, "CreatedOn": null, "DateConfigured": null, "ToEmailID": null, "RejectType": null, "AccessGroup": null, "IsInTransit": null, "IsReplacement": false, "ReplacementDate": null, "AssetCount": 0, "AssetStatus": null, "IsConfigureRequired": false, "IsBlocked": 0, "NextStageInfo": "-", "AssetTranId": 6, "AssetId": null, "HpsmNo": "SR-I3L-238926", "SysPurposeId": 0, "PurposeName": "Store to building", "FromFloorId": 0, "FromCubicleId": null, "FromPsid": null, "FromBuildingEnggId": null, "ToFloorId": null, "ToCubicleId": null, "ToPsid": "20621", "MovementEnggId": null, "ToBuildingEnggId": null, "CreatedByPsid": null, "Tier1LeadId": null, "Tier1EnggId": null, "ApprovedByPsid": null, "EndUserId": null, "EndUserCubicleID": null, "IsEndUserAcknowledged": true, "ModDt": "\/Date(1487223539233)\/", "ModBy": "20621", "SysPurposeStageId": null, "Comments": null, "NextStages": [{ "PurposeStageID": null, "PurposeStageName": null }], "CurrentStage": { "PurposeStageID": 179, "PurposeStageName": "User_Ack" } }, { "NextStage": null, "AssetType": "Laptops", "SerialNo": "6BY5ZR1", "QRCode": null, "FromLocation": null, "FromBuilding": null, "FromArea": null, "FromCubicleNo": null, "FromName": null, "FromFloor": null, "ToLocation": null, "ToBuilding": "Tripti", "ToArea": null, "ToCubicleNo": "6", "FARNumber": "AMSTP-000000016534", "ToName": "Kalyani Kumari", "ToFloor": "B Block", "CurrentStatus": "User_Ack", "NextStatus": null, "OverSeer": null, "Psid": null, "FromBuildingId": null, "ToBuildingId": null, "CreatedByName": null, "FromEngineer": null, "ToEngineer": null, "CreatedOn": null, "DateConfigured": null, "ToEmailID": null, "RejectType": null, "AccessGroup": null, "IsInTransit": null, "IsReplacement": false, "ReplacementDate": null, "AssetCount": 0, "AssetStatus": null, "IsConfigureRequired": false, "IsBlocked": 0, "NextStageInfo": "-", "AssetTranId": 5, "AssetId": null, "HpsmNo": "SR-I3L-238926", "SysPurposeId": 0, "PurposeName": "Store to building", "FromFloorId": 0, "FromCubicleId": null, "FromPsid": null, "FromBuildingEnggId": null, "ToFloorId": null, "ToCubicleId": null, "ToPsid": "20621", "MovementEnggId": null, "ToBuildingEnggId": null, "CreatedByPsid": null, "Tier1LeadId": null, "Tier1EnggId": null, "ApprovedByPsid": null, "EndUserId": null, "EndUserCubicleID": null, "IsEndUserAcknowledged": true, "ModDt": "\/Date(1487223536520)\/", "ModBy": "20621", "SysPurposeStageId": null, "Comments": null, "NextStages": [{ "PurposeStageID": null, "PurposeStageName": null }], "CurrentStage": { "PurposeStageID": 17, "PurposeStageName": "User_Ack" } }, { "NextStage": null, "AssetType": "Laptops", "SerialNo": "6BXXYR1", "QRCode": null, "FromLocation": null, "FromBuilding": null, "FromArea": null, "FromCubicleNo": null, "FromName": null, "FromFloor": null, "ToLocation": null, "ToBuilding": "Tripti", "ToArea": null, "ToCubicleNo": "6", "FARNumber": "AMSTP-000000016533", "ToName": "Kalyani Kumari", "ToFloor": "B Block", "CurrentStatus": "User_Ack", "NextStatus": null, "OverSeer": null, "Psid": null, "FromBuildingId": null, "ToBuildingId": null, "CreatedByName": null, "FromEngineer": null, "ToEngineer": null, "CreatedOn": null, "DateConfigured": null, "ToEmailID": null, "RejectType": null, "AccessGroup": null, "IsInTransit": null, "IsReplacement": false, "ReplacementDate": null, "AssetCount": 0, "AssetStatus": null, "IsConfigureRequired": false, "IsBlocked": 0, "NextStageInfo": "-", "AssetTranId": 4, "AssetId": null, "HpsmNo": "SR-I3L-238926", "SysPurposeId": 0, "PurposeName": "Store to building", "FromFloorId": 0, "FromCubicleId": null, "FromPsid": null, "FromBuildingEnggId": null, "ToFloorId": null, "ToCubicleId": null, "ToPsid": "20621", "MovementEnggId": null, "ToBuildingEnggId": null, "CreatedByPsid": null, "Tier1LeadId": null, "Tier1EnggId": null, "ApprovedByPsid": null, "EndUserId": null, "EndUserCubicleID": null, "IsEndUserAcknowledged": true, "ModDt": "\/Date(1487223533467)\/", "ModBy": "20621", "SysPurposeStageId": null, "Comments": null, "NextStages": [{ "PurposeStageID": null, "PurposeStageName": null }], "CurrentStage": { "PurposeStageID": 17, "PurposeStageName": "User_Ack" } }, { "NextStage": null, "AssetType": "Monitor", "SerialNo": "CN03XNMH6418024R0QRS", "QRCode": null, "FromLocation": null, "FromBuilding": null, "FromArea": null, "FromCubicleNo": null, "FromName": null, "FromFloor": null, "ToLocation": null, "ToBuilding": "Tripti", "ToArea": null, "ToCubicleNo": "6", "FARNumber": "AMSTP-000000020916", "ToName": "Kalyani Kumari", "ToFloor": "B Block", "CurrentStatus": "User_Ack", "NextStatus": null, "OverSeer": null, "Psid": null, "FromBuildingId": null, "ToBuildingId": null, "CreatedByName": null, "FromEngineer": null, "ToEngineer": null, "CreatedOn": null, "DateConfigured": null, "ToEmailID": null, "RejectType": null, "AccessGroup": null, "IsInTransit": null, "IsReplacement": false, "ReplacementDate": null, "AssetCount": 0, "AssetStatus": null, "IsConfigureRequired": false, "IsBlocked": 0, "NextStageInfo": "-", "AssetTranId": 7, "AssetId": null, "HpsmNo": "SR-I3L-238926", "SysPurposeId": 0, "PurposeName": "Store to building", "FromFloorId": 0, "FromCubicleId": null, "FromPsid": null, "FromBuildingEnggId": null, "ToFloorId": null, "ToCubicleId": null, "ToPsid": "20621", "MovementEnggId": null, "ToBuildingEnggId": null, "CreatedByPsid": null, "Tier1LeadId": null, "Tier1EnggId": null, "ApprovedByPsid": null, "EndUserId": null, "EndUserCubicleID": null, "IsEndUserAcknowledged": true, "ModDt": "\/Date(1487223531037)\/", "ModBy": "20621", "SysPurposeStageId": null, "Comments": null, "NextStages": [{ "PurposeStageID": null, "PurposeStageName": null }], "CurrentStage": { "PurposeStageID": 185, "PurposeStageName": "User_Ack" } }];

    // console.log($scope.datalist)



}])

var exportoexcelfactory = ApplictaionModule.factory('Excel', function ($window) {
    var uri = 'data:application/vnd.ms-excel;base64,',
        template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
        base64 = function (s) { return $window.btoa(unescape(encodeURIComponent(s))); },
        format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) };
    return {
        tableToExcel: function (tableId, worksheetName) {
            var table = $(tableId),
                ctx = { worksheet: worksheetName, table: table.html() },
                href = uri + base64(format(template, ctx));
            return href;
        }
    };
})


var myassetscontrollers = ApplictaionModule.controller("myassetscontrollers", ['$scope', '$location', '$http', 'ModalService', '$timeout', 'Excel', function ($scope, $location, $http, ModalService, $timeout, Excel) {
    $scope.x = true;


    $scope.windowurl = function (path) {

        $location.path(path);

    }
    $scope.exporttoexcel = function (tableid) {
//        console.log((tableid.target.attributes.data))
        var exportHref = Excel.tableToExcel('newtable105_1', 'DataExport');
        $timeout(function () { location.href = exportHref; }, 100); // trigger download

    }

    $scope.uncompresseddatalist = [];
    $scope.datalist = [];
    $http({
        method: "GET",
        url: "home/GetAcknowledgedAssets"
    }).then(function mySucces(response) {

        $scope.uncompresseddatalist = JSON.parse(response.data.Data);

        var grpResult = group(JSON.parse(response.data.Data), 'ToCubicleNo');
        //console.log($scope.uncompresseddatalist)
        $scope.datalist = grpResult;
    }, function myError(response) {
        $scope.myWelcome = response;
    });
    $scope.totalDisplayed = 5;

    $scope.loadMore = function () {
        $scope.totalDisplayed += 5;
    };
    $scope.datalist = $scope.datalist;
    $scope.formatDate = function (date) {
        var dateOut = new Date(date);
        return dateOut;
    };

    $scope.show = function (btnid, nextstatus, assettranid, type,assettype) {
        
        $scope.textpattern = /^\s*$/g;
        $scope.stat = nextstatus;
        $scope.assettranid = assettranid;
        $scope.type = type;
        $scope.assettype = assettype;
        ModalService.showModal({
            scope: $scope,
            templateUrl: 'modal.html',
            controller: "ModalController"
        }).then(function (modal) {
            modal.element.modal();
            modal.close.then(function (data, result) {


            });
        });
    }
}])

ApplictaionModule.directive('actionbbutton', function () {

    var directive = {};
    directive.restrict = 'E';
    directive.templateUrl = 'AngularDirectivetemplates/ActionButton.html';

    return directive;
})
ApplictaionModule.directive('errSrc', function () {
    return {
        link: function (scope, element, attrs) {
            element.bind('error', function () {
                if (attrs.src != attrs.errSrc) {
                    attrs.$set('src', attrs.errSrc);
                }
            });
        }
    }
});

///routes

ApplictaionModule.controller('ctrl', function ($scope, $rootScope) {

});
//ApplictaionModule.config(['$routeProvider', function ($routeProvider) {
//    $routeProvider
//       .when("/", {
//           templateUrl: "Angulartemplates/Profile.html",

//       })
//      .when("/settings", {
//          templateUrl: "Angulartemplates/Settings.html",

//      })
//     .when("/newtimesheet", {
//         templateUrl: "Angulartemplates/NewTimeSheet.html",

//     })
//    .when("/split", {
//        templateUrl: "Angulartemplates/TaskSplit.html",

//    })

//}]);

ApplictaionModule.config(['$routeProvider', function ($routeProvider) {
    $routeProvider
       .when("/", {
           templateUrl: "Angulartemplates/Settings.html",

       })
     .when("/Acknowledge", {
         templateUrl: "Angulartemplates/AcknowledgeList.html",

     })
    .when("/mylist", {
        templateUrl: "Angulartemplates/MyAssets.html",

    })
        .when("/table", {
            templateUrl: "Angulartemplates/TableView.html",

        })
    .when("/profile", {
        templateUrl: "Angulartemplates/Profile.html",

    })
     .when("/myprofile", {
         templateUrl: "Angulartemplates/Profile.html",

     })
}]);

