﻿using System;

namespace AssetManagement.Tasks
{
    public partial class AssetMovement : System.Web.UI.Page
    {
        //#region Private Variables
        //AssetManagementLibrary.Queries objDal = null;
        //UserEntityClass user = null;
        //DateTime scandate;
        //DataTable dt;
        //#endregion
        protected void Page_Load(object sender, EventArgs e)
        {

            //System.Web.UI.WebControls.Button myObject;
            //myObject = (System.Web.UI.WebControls.Button)Master.FindControl("AsseInventory");
            //myObject.Attributes.Add("class", "flatdivonselect");
            //myObject = (System.Web.UI.WebControls.Button)Master.FindControl("AssetSearch");
            //myObject.Attributes.Add("class", "flatdivonselect");
            //myObject = (System.Web.UI.WebControls.Button)Master.FindControl("AssetDailyReview");
            //myObject.Attributes.Add("class", "flatdivonselect");
            //objDal = new AssetManagementLibrary.Queries();
           
        }

        protected void btnMove_Click(object sender, EventArgs e)
        {

        }

        
        protected void btnLogout_Click(object sender, EventArgs e)
        {
            //Session.Clear();
            //Session.RemoveAll();
            //Session.Abandon();
            //Response.Redirect("HomePage.aspx");
        }

        public void LoadAssetMovementGrid()
        {
            //string PSID = txtPsid.Text;
            //DataSet dtgridinfo = objDal.LoadAssetMovmentGrid(PSID);
            //grdassetmovement.DataSource = dtgridinfo;
            //grdassetmovement.DataBind();
        }

        protected void txtPsid_TextChanged(object sender, EventArgs e)
        {
           // try { 
           // string Psid = txtPsid.Text;
           //// string PSID = txtPsid.Text;
           // DataTable dtLoginInfo = objDal.GetUserName(Psid);
           //// DataSet dtgridinfo = objDal.LoadAssetMovmentGrid(PSID);
           // if (dtLoginInfo.Rows.Count > 0)
           // {
           //     txtName.Text = dtLoginInfo.Rows[0]["Name"].ToString();


           //     if (txtName.Text == string.Empty)
           //     {
           //         //lblErrorMsg.Text = AMDefinitions.PERSONALIZEUSER;
           //         //lblErrorMsg.Text = "User Not Found - Kindly Re-Check the PSID.";
           //     }
           // }
           // else
           // {                
           //    // MessageBox.Show("User Not Found - Kindly Re-Check the PSID.");
           //     //lblPsidError.Text = "User Not Found - Kindly Re-Check the PSID.";
           //     txtPsid.Text = string.Empty;
           //     txtName.Text = string.Empty;
           // }
           // //grdassetmovement.DataSource = dtgridinfo;
           // //grdassetmovement.DataBind();
           // LoadAssetMovementGrid();
           // }
           // catch
           // {
           //     //lblErrorMsg.Text = "User Not Found - Kindly Re-Check the PSID.";
           //     txtName.Text = string.Empty;
           // }
        }

        protected void TotxtPsid_TextChanged(object sender, EventArgs e)
        {
            //try
            //{
            //    string Psid = TotxtPsid.Text;
            //    string PSID = TotxtPsid.Text;
            //    DataTable dtLoginInfo = objDal.GetUserName(Psid);
            //   // DataSet dtgridinfo = objDal.LoadAssetMovmentGrid(PSID);
            //    if (dtLoginInfo.Rows.Count > 0)
            //    {
            //        TotxtName.Text = dtLoginInfo.Rows[0]["Name"].ToString();


            //        if (TotxtName.Text == string.Empty)
            //        {
            //            //lblErrorMsg.Text = AMDefinitions.PERSONALIZEUSER;
            //            //lblErrorMsg.Text = "User Not Found - Kindly Re-Check the PSID.";
            //        }
            //    }
            //    else
            //    {
            //        // MessageBox.Show("User Not Found - Kindly Re-Check the PSID.");
            //        //lblPsidError.Text = "User Not Found - Kindly Re-Check the PSID.";
            //        TotxtPsid.Text = string.Empty;
            //        TotxtName.Text = string.Empty;
            //    }               
            //}
            //catch
            //{
            //    //lblErrorMsg.Text = "User Not Found - Kindly Re-Check the PSID.";
            //    TotxtName.Text = string.Empty;
            //}
        }

        protected void grdassetmovement_Load(object sender, EventArgs e)
        {
            //LoadAssetMovementGrid();
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            //txtName.Text = string.Empty;
            //txtPsid.Text = string.Empty;
            //LoadAssetMovementGrid();
            
        }

        protected void btnprint_Click(object sender, EventArgs e)
        {
            //Response.Redirect("PrintMovementForm.aspx");
            
        }

        protected void btnMove_Click1(object sender, EventArgs e)
        {
          
        }

        //public static List<string> GetCompletionList(string prefixText, int count)
        //{
        //    //return AutoFillProducts(prefixText);

        //}

        //private static List<string> AutoFillProducts(string prefixText)
        //{
        //    //using (SqlConnection con = new SqlConnection())
        //    //{
        //    //    con.ConnectionString = ConfigurationManager.ConnectionStrings["AvaluetConnectionString"].ConnectionString;
        //    //    using (SqlCommand com = new SqlCommand())
        //    //    {
        //    //        com.CommandText = "select PSID from EmployeePSID where " + "PSID like @Search + '%'";
        //    //        com.Parameters.AddWithValue("@Search", prefixText);
        //    //        com.Connection = con;
        //    //        con.Open();
        //    //        List<string> countryNames = new List<string>();
        //    //        using (SqlDataReader sdr = com.ExecuteReader())
        //    //        {
        //    //            while (sdr.Read())
        //    //            {
        //    //                countryNames.Add(sdr["PSID"].ToString());
        //    //            }
        //    //        }
        //    //        con.Close();
        //    //        return countryNames;
        //    //    }
        //    //}
        //}  

    }
}
