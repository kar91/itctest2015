﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace AssetManagement.Tasks
{
    public partial class XtraReports : DevExpress.XtraReports.UI.XtraReport
    {
        public XtraReports()
        {
            InitializeComponent();
        }

    }
}
