﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using DevExpress.Web;
using DevExpress.Web.Data;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Utils;
using DevExpress.XtraPrinting;
using DevExpress.Export;

namespace AssetManagement.Tasks
{
    public partial class ItemMaster : AssetTrackerBasePage
    {
        #region 

        private DataSet _dsassetstatus;
        private DataSet _dsassettype;
        private DataSet _dsCubicleLocation;
        private DataSet _dsSMGTeam;
        private string _errorMessage = "";
        private DBResult _dbResult = new DBResult();

        #endregion


        protected void Page_Load(object sender, EventArgs e)
        {
            LoadItemMasterGrid();
        }

        protected void grdItemMaster_OnRowInserting(object sender, ASPxDataInsertingEventArgs e)
        {
            _dbResult = QueryHelper.InsertItemMaster(GetGriditems(e));
            if (!_dbResult.Result)
                _errorMessage = _dbResult.Message;
            else
            {
                e.Cancel = true;
                grdItemMaster.CancelEdit();
                LoadItemMasterGrid();
            }
        }

        private void LoadItemMasterGrid()
        {
            grdItemMaster.DataSource = QueryHelper.GetItemMaster();
            grdItemMaster.DataBind();
            _dsassetstatus = QueryHelper.GetAssetStatus();
            _dsassettype = QueryHelper.GetAssetType();
            _dsSMGTeam = QueryHelper.getSMGTeam();
            _dsCubicleLocation = CacheHelper.GetInstance.GetValue<DataSet>("Cubiclelocation", QueryHelper.GetCubicleLocation, 0, true, null);
        }

        protected void grdItemMaster_OnCellEditorInitialize(object sender, ASPxGridViewEditorEventArgs e)
        {
            if (e.Column.FieldName.Equals("AssetStatus"))
            {
                ASPxComboBox cmb = e.Editor as ASPxComboBox;
                if (cmb != null)
                {
                    cmb.DataSource = _dsassetstatus;
                    cmb.ValueField = "SysAssetStatusID";
                    cmb.ValueType = typeof(int);
                    cmb.TextField = "AssetStatus";
                    cmb.DataBindItems();
                }
            }
            if (e.Column.FieldName.Equals("CubicleID"))
            {
               var cmb = e.Editor as ASPxComboBox;
               if (cmb != null)
               {
                   cmb.TextFormatString = "{0} | {1} | {2}";
                   cmb.IncrementalFilteringMode = IncrementalFilteringMode.Contains;
                   cmb.NullText = "Type Building Floor or Cubicle";
                   cmb.Columns.Add("Building");
                   cmb.Columns.Add("FloorNo");
                   cmb.Columns.Add("CubicleNo");
                   cmb.EnableViewState = false;
                   cmb.DropDownStyle = DropDownStyle.DropDown;
                   cmb.EncodeHtml = false;
                   cmb.ItemStyle.Wrap = DefaultBoolean.True;
                   cmb.DataSource = QueryHelper.GetCubicleLocation();
                   cmb.ValueField = "CubicleID";
                   cmb.ValueType = typeof(string);
                   cmb.TextField = "CubicleNo";
                   cmb.CallbackPageSize = 10;
                   cmb.EnableCallbackMode = true;
                   cmb.DataBind();
               }
            }
            if (e.Column.FieldName.Equals("SMGTeam"))
            {
                ASPxComboBox cmb = e.Editor as ASPxComboBox;
                if (cmb != null)
                {
                    cmb.DataSource = _dsSMGTeam;
                    cmb.ValueField = "SMGTeamID";
                    cmb.ValueType = typeof(string);
                    cmb.TextField = "SMGTeam";
                    cmb.DataBindItems();
                }
            }

            if (!e.Column.FieldName.Equals("AssetType")) return;
            {
                ASPxComboBox cmb = e.Editor as ASPxComboBox;
                if (cmb != null)
                {
                    cmb.DataSource = _dsassettype;
                    cmb.ValueField = "SysAssetTypeID";
                    cmb.ValueType = typeof(int);
                    cmb.TextField = "AssetType";
                    cmb.DataBindItems();
                }
            }
        }

        protected void grdItemMaster_OnRowUpdating(object sender, ASPxDataUpdatingEventArgs e)
        {
            _dbResult = QueryHelper.UpdateItemMaster(GetGriditems(e));

            if (!_dbResult.Result)
                _errorMessage = _dbResult.Message;
            else
            {
                e.Cancel = true;
                grdItemMaster.CancelEdit();
                LoadItemMasterGrid();
            }
        }

        protected void grdItemMaster_OnCustomErrorText(object sender, ASPxGridViewCustomErrorTextEventArgs e)
        {
            if (!string.IsNullOrEmpty(_errorMessage))
                e.ErrorText = _errorMessage;
        }

        private static int GetIdfromText<T>(T e, DataSet dataSet, string fieldName, string columnName, string columnId)
        {
            var assetId = 0;
            dynamic asPxDataEventArgs = e;
            if (asPxDataEventArgs != null)
                if (asPxDataEventArgs.NewValues[fieldName] != null)
                {
                    int value;
                    assetId = int.TryParse(asPxDataEventArgs.NewValues[fieldName].ToString(), out value)
                        ? Convert.ToInt32(asPxDataEventArgs.NewValues[fieldName])
                        : dataSet.Tables[0].AsEnumerable()
                            .Where(r => r.Field<string>(columnName) == asPxDataEventArgs.NewValues[fieldName].ToString())
                            .Select(r => r.Field<int>(columnId))
                            .First();
                }
                else
                {
                    assetId = 0;
                }

            return assetId;
        }

        private List<InputParameters> GetGriditems<T>(T e) where T : new()
        {
            List<InputParameters> ipItemMaster = null;
            dynamic asPxDataEventArgs = e;

            if (asPxDataEventArgs != null)
            {
                var serialnumber = Convert.ToString(asPxDataEventArgs.NewValues["SerialNumber"]);
                var farNumber = Convert.ToString(asPxDataEventArgs.NewValues["FARNumber"]);
                var qrCode = Convert.ToString(asPxDataEventArgs.NewValues["QRCode"]);
                var sysAssetTypeId = GetIdfromText(asPxDataEventArgs, _dsassettype, "AssetType", "AssetType", "SysAssetTypeID").ToString();
                var sysAssetStatusId = GetIdfromText(asPxDataEventArgs, _dsassetstatus, "AssetStatus", "AssetStatus", "SysAssetStatusID").ToString();
                var userPsid = Convert.ToString(asPxDataEventArgs.NewValues["UserPSID"]);
                var cubicleId = GetIdfromText(asPxDataEventArgs, _dsCubicleLocation, "CubicleID", "CubicleNo", "CubicleID").ToString();
                var amRequestid = Convert.ToString(asPxDataEventArgs.NewValues["AMRequestID"]);
                var modBy = Convert.ToString(Session["PSID"]);
                var assetCat = Convert.ToString(asPxDataEventArgs.NewValues["AssetCategory"]);
                var AssetInfoType = Convert.ToString(asPxDataEventArgs.NewValues["TypeInformationAsset"]); 
                var smgTeam = Convert.ToString(asPxDataEventArgs.NewValues["SMGTeam"]);
                var ownership = Convert.ToString(asPxDataEventArgs.NewValues["Ownership"]);



                ipItemMaster = new List<InputParameters>
                {
                new InputParameters {SqlParam = "SerialNumber", ParamValue = serialnumber?? string.Empty},
                new InputParameters {SqlParam = "FARNumber", ParamValue = farNumber?? string.Empty},
                new InputParameters {SqlParam = "QRCode", ParamValue = qrCode?? string.Empty},
                new InputParameters {SqlParam = "SysAssetTypeID", ParamValue = sysAssetTypeId?? string.Empty},
                new InputParameters {SqlParam = "SysAssetStatusID", ParamValue = sysAssetStatusId?? string.Empty},
                new InputParameters {SqlParam = "UserPSID", ParamValue = userPsid ?? string.Empty},
                new InputParameters {SqlParam = "CubicleID", ParamValue = cubicleId ?? string.Empty},
                new InputParameters {SqlParam = "AMRequestID", ParamValue = amRequestid?? string.Empty},
                new InputParameters {SqlParam = "ModifiedBy", ParamValue = modBy},
                new InputParameters {SqlParam = "AssetCategory", ParamValue = assetCat?? string.Empty},
                new InputParameters {SqlParam = "TypeInformationAsset", ParamValue = AssetInfoType?? string.Empty},
                new InputParameters {SqlParam = "SMGTeam", ParamValue = smgTeam?? string.Empty},
                new InputParameters {SqlParam = "Ownership", ParamValue = ownership?? string.Empty}

                };

                if (typeof(T) == typeof(ASPxDataUpdatingEventArgs))
                {
                    var key = grdItemMaster.GetRowValuesByKeyValue(asPxDataEventArgs.Keys[0], "SysAssetID").ToString();
                    ipItemMaster.Add(new InputParameters { SqlParam = "SysAssetID", ParamValue = key });
                }
            }
            return ipItemMaster;
        }
        protected void grdItemMaster_OnCommandButtonInitialize(object sender, ASPxGridViewCommandButtonEventArgs e)
        {
            if (Convert.ToInt32(Session["IsAuthorized"]) != 1)
            {
                if (e.ButtonType == ColumnCommandButtonType.Edit)
                {
                    e.Visible = false;
                }
            }
        }

        protected void btnexcel_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            gridExport.WriteXlsxToResponse(new XlsxExportOptionsEx() { ExportType = ExportType.WYSIWYG });
        }
    }
}