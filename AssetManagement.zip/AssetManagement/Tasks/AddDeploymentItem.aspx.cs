﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web.UI;
using DevExpress.Web;
using System.Net.Mail;
using System.IO;

namespace AssetManagement.Tasks
{
    static class SeatingData
    {
        public static string FloorId { get; set; }
        public static string CubicleId { get; set; }
    }

    public partial class AddDeploymentItem : AssetTrackerBasePage
    {
        private DBResult _dbResult = new DBResult();
        private DataSet _dataSetEmp;
        private DataSet _keySet;
        private DataSet _employeePsidName;
        private DataSet _loadBuilding;
        private DataSet _mailerDetails;


        protected void Page_Load(object sender, EventArgs e)
        {
            System.Web.UI.WebControls.Button myObject;
            myObject = (System.Web.UI.WebControls.Button)Master.FindControl("AsseInventory");
            myObject.Attributes.Add("class", "flatdivonselect");
            myObject = (System.Web.UI.WebControls.Button)Master.FindControl("AssetSearch");
            myObject.Attributes.Add("class", "flatdivonselect");
            myObject = (System.Web.UI.WebControls.Button)Master.FindControl("AssetDailyReview");
            myObject.Attributes.Add("class", "flatdivonselect");

            cmbSelectAssetType.DataSource = QueryHelper.GetAssetType();
            cmbSelectAssetType.DataBind();

            _loadBuilding = LoadBuilding();
            cmbFrmBuilding.DataSource = _loadBuilding;
            cmbFrmBuilding.DataBind();
            cmbBuilding.DataSource = _loadBuilding;
            cmbBuilding.DataBind();

            _employeePsidName = QueryHelper.GetEmpDataSet();
            cmbToUserPsid.DataSource = _employeePsidName;
            cmbToUserPsid.DataBind();
            cmbEngPsid.DataSource = _employeePsidName;
            cmbEngPsid.DataBind();
            cmbFromUserPSID.DataSource = _employeePsidName;
            cmbFromUserPSID.DataBind();

            cmbAssetStatus.DataSource = QueryHelper.GetAssetStatus();
            cmbAssetStatus.DataBind();

            if (!string.IsNullOrEmpty((string)Application["assetid"]) && IsPostBack)
            {
                cmbAsset.DataSource = QueryHelper.GetAssetItem((string)Application["assetid"]);
                cmbAsset.DataBind();
            }

            if (cmbReviewStatus.SelectedIndex == -1)
                cmbReviewStatus.SelectedIndex = 0;


            string keyValue = Request.QueryString["keyValue"];
            if (!IsPostBack)
            {
                if (!string.IsNullOrEmpty(keyValue) && IsValidKey(keyValue))
                {
                    btnUpdate.Visible = true;
                    btnCancel.Visible = true;
                    btnAdd.Visible = false;

                    dtDeploydate.ReadOnly = true;
                    dtDeploydate.ForeColor = Color.Black;
                    dtDeploydate.BackColor = Color.FromArgb(241, 241, 241);

                    txtHpsm.ReadOnly = true;
                    txtHpsm.ForeColor = Color.Black;
                    txtHpsm.BackColor = Color.FromArgb(241, 241, 241);

                    cmbAsset.ReadOnly = true;
                    cmbAsset.ForeColor = Color.Black;
                    cmbAsset.BackColor = Color.FromArgb(241, 241, 241);

                    cmbSelectAssetType.ReadOnly = true;
                    cmbSelectAssetType.ForeColor = Color.Black;
                    cmbSelectAssetType.BackColor = Color.FromArgb(241, 241, 241);
                }
                else
                {
                    btnUpdate.Visible = false;
                    btnCancel.Visible = false;
                    btnAdd.Visible = true;
                }
            }
        }

        private DataSet LoadBuilding()
        {
            var ipbuildingonlocation = new List<InputParameters>
                    {
                        new InputParameters {SqlParam = "LocationID", ParamValue = "2"},
                        new InputParameters {SqlParam = "PSID", ParamValue = Session["PSID"].ToString()},
                        new InputParameters {SqlParam = "ApplicationID", ParamValue = Convert.ToInt16(ConfigurationManager.AppSettings["ApplicationID"]).ToString()}
                    };
            return QueryHelper.GetBlockBasedOnLocation(ipbuildingonlocation);
        }

        private void LoadFromFloor(int blockId)
        {
            var ipareabasedonblock = new List<InputParameters>
            {
                new InputParameters {SqlParam = "BuildingID", ParamValue = blockId.ToString()},
                new InputParameters {SqlParam = "PSID", ParamValue = Session["PSID"].ToString()},
                new InputParameters {SqlParam = "ApplicationID", ParamValue = Convert.ToInt16(ConfigurationManager.AppSettings["ApplicationID"]).ToString()}
            };

            cmbFrmFloor.DataSource = QueryHelper.GetAreaBasedOnBlock(ipareabasedonblock);
            cmbFrmFloor.DataBind();
        }

        private void LoadFromCubicle(int buildingFloorId)
        {
            var ipcubiclebasedonarea = new List<InputParameters>
                {
                    new InputParameters {SqlParam = "BuildingFloorID", ParamValue = buildingFloorId.ToString()}
                };

            cmbFromCubicle.DataSource = QueryHelper.GetCubicleBasedOnArea(ipcubiclebasedonarea);
            cmbFromCubicle.DataBind();
        }

        private void LoadToFloor(int blockId)
        {
            var ipareabasedonblock = new List<InputParameters>
            {
                new InputParameters {SqlParam = "BuildingID", ParamValue = blockId.ToString()},
                new InputParameters {SqlParam = "PSID", ParamValue = Session["PSID"].ToString()},
                new InputParameters {SqlParam = "ApplicationID", ParamValue = Convert.ToInt16(ConfigurationManager.AppSettings["ApplicationID"]).ToString()}
            };

            cmbFloor.DataSource = QueryHelper.GetAreaBasedOnBlock(ipareabasedonblock);
            cmbFloor.DataBind();
        }

        private void LoadToCubicle(int buildingFloorId)
        {
            var ipcubiclebasedonarea = new List<InputParameters>
                {
                    new InputParameters {SqlParam = "BuildingFloorID", ParamValue = buildingFloorId.ToString()}
                };

            cmbCubicle.DataSource = QueryHelper.GetCubicleBasedOnArea(ipcubiclebasedonarea);
            cmbCubicle.DataBind();
        }

        private bool IsValidKey(string keyValue)
        {
            bool result;
            var ipGetKeyValues = new List<InputParameters> { new InputParameters { SqlParam = "KeyValue", ParamValue = keyValue } };
            _keySet = QueryHelper.GetKeyValuesDepRegister(ipGetKeyValues);
            if (_keySet.Tables[0].Rows.Count > 0 && _keySet != null)
            {
                var datKeySetRow = _keySet.Tables[0].Rows[0];
                txtHpsm.Text = datKeySetRow["HPSMNumber"].ToString();
                cmbTransactionType.SelectedIndex = cmbTransactionType.Items.FindByValue(datKeySetRow["TransactionTypeID"].ToString()).Index;
                if (cmbFromUserPSID.Items.FindByValue(Convert.ToInt32(datKeySetRow["FromPSID"])) != null)
                {
                    cmbFromUserPSID.SelectedIndex =
                        cmbFromUserPSID.Items.FindByValue(Convert.ToInt32(datKeySetRow["FromPSID"])).Index;
                }
                cmbFrmBuilding.SelectedIndex = cmbFrmBuilding.Items.FindByValue(datKeySetRow["FromBuilding"].ToString()).Index;
                if (cmbFrmBuilding.Value != null)
                {
                    LoadFromFloor(Convert.ToInt32(cmbFrmBuilding.Value));
                    cmbFrmFloor.SelectedIndex =
                        cmbFrmFloor.Items.FindByValue(datKeySetRow["FromFloor"].ToString()).Index;
                }
                if (cmbFrmFloor.Value != null)
                {
                    LoadFromCubicle(Convert.ToInt32(cmbFrmFloor.Value));
                    cmbFromCubicle.SelectedIndex =
                        cmbFromCubicle.Items.FindByValue(datKeySetRow["FromCubicleID"].ToString()).Index;
                }
                if (!string.IsNullOrEmpty(datKeySetRow["SysAssetTypeID"].ToString()))
                {
                    cmbSelectAssetType.SelectedIndex =
                        cmbSelectAssetType.Items.FindByValue(datKeySetRow["SysAssetTypeID"].ToString()).Index;

                    if (cmbSelectAssetType.SelectedItem.Value != null)
                    {

                        var assetid = cmbSelectAssetType.SelectedItem.Value.ToString();
                        Application["assetid"] = assetid;
                        var getAssetItem = QueryHelper.GetAssetItem(assetid);
                        cmbAsset.DataSource = getAssetItem;
                        cmbAsset.DataBind();
                        cmbAsset.SelectedIndex = cmbAsset.Items.FindByValue(datKeySetRow["AssetID"].ToString()).Index;
                        var dtgetassetTable = getAssetItem.Tables[0];
                        var details =
                            dtgetassetTable.AsEnumerable()
                                .Where(r => r.Field<int>("SysAssetID") == Convert.ToInt32(cmbAsset.Value))
                                .Select(
                                    r =>
                                        new
                                        {
                                            Serial = r.Field<string>("SerialNumber"),
                                            Far = r.Field<string>("FARNumber"),
                                            Qr = r.Field<string>("QRCode")
                                        });

                        foreach (var x in details)
                        {
                            txtSerialNumber.Text = x.Serial;
                            txtFarNumber.Text = x.Far;
                            txtQrCode.Text = x.Qr;
                        }
                        //cmbAsset.ClientSideEvents.SelectedIndexChanged = "function(s, e) { OnSelectedAssetChanged(s); }";
                    }
                }
                cmbBuilding.SelectedIndex = cmbBuilding.Items.FindByValue(datKeySetRow["ToBuilding"].ToString()).Index;
                if (cmbBuilding.Value != null)
                {
                    LoadToFloor(Convert.ToInt32(cmbBuilding.Value));
                    cmbFloor.SelectedIndex = cmbFloor.Items.FindByValue(datKeySetRow["ToFloor"].ToString()).Index;
                }
                if (cmbFloor.Value != null)
                {
                    LoadToCubicle(Convert.ToInt32(cmbFloor.Value));
                    cmbCubicle.SelectedIndex = cmbCubicle.Items.FindByValue(datKeySetRow["ToCubicleID"].ToString()).Index;
                }
                if (cmbToUserPsid.Items.FindByValue(Convert.ToInt32(datKeySetRow["ToUserPSID"])) != null)
                {
                    cmbToUserPsid.SelectedIndex =
                        cmbToUserPsid.Items.FindByValue(Convert.ToInt32(datKeySetRow["ToUserPSID"])).Index;
                }
                if (cmbEngPsid.Items.FindByValue(Convert.ToInt32(datKeySetRow["EngineerPSID"])) != null)
                {
                    cmbEngPsid.SelectedIndex =
                        cmbEngPsid.Items.FindByValue(Convert.ToInt32(datKeySetRow["EngineerPSID"])).Index;
                }
                cmbReviewStatus.SelectedIndex = cmbReviewStatus.Items.FindByValue(datKeySetRow["ReviewStatus"].ToString()).Index;
                cmbAssetStatus.SelectedIndex = cmbAssetStatus.Items.FindByValue(datKeySetRow["SysAssetStatusID"].ToString()).Index;
                dtDeploydate.Date = Convert.ToDateTime(datKeySetRow["DeployDate"]);
                txtRemarks.Text = datKeySetRow["Remarks"].ToString();
                result = true;
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "alert('" + _dbResult.Message + "');window.location='DeploymentRegister.aspx';", true);
                result = false;
            }
            return result;
        }

        protected void dtDeploydate_OnLoad(object sender, EventArgs e)
        {

            if (dtDeploydate.Value == null)
                dtDeploydate.Date = DateTime.Today;
        }

        protected void OnClick(object sender, EventArgs e)
        {

            string assetId = (cmbAsset.Value ?? "").ToString();
            string userPsid = (cmbToUserPsid.Value ?? "").ToString();
            string cubicleId = (cmbCubicle.Value ?? "").ToString();
            string depDate = (dtDeploydate.Value ?? "").ToString();
            string review = (cmbReviewStatus.Value ?? "").ToString();
            string fromcubicleId = (cmbFromCubicle.Value ?? "").ToString();
            string transactype = (cmbTransactionType.Value ?? "").ToString();
            string assetstatusId = (cmbAssetStatus.Value ?? "").ToString();
            string engPSid = (cmbEngPsid.Value ?? "").ToString();
            string frmUSerId = (cmbFromUserPSID.Value ?? "").ToString();
            var hpsmno = txtHpsm.Text ?? string.Empty;
            var remarks = txtRemarks.Text ?? string.Empty;
            var modBy = Session["PSID"].ToString();

            var ipInsertDeployReg = new List<InputParameters>
                {
                    new InputParameters {SqlParam = "AssetID", ParamValue = assetId},
                    new InputParameters {SqlParam = "UserPSID", ParamValue = userPsid},
                    new InputParameters {SqlParam = "CubicleID", ParamValue = cubicleId},
                    new InputParameters {SqlParam = "EngineerPSID", ParamValue = engPSid},
                    new InputParameters {SqlParam = "DeploymentDate", ParamValue = depDate},
                    new InputParameters {SqlParam = "ReviewStatus", ParamValue = review},
                    new InputParameters {SqlParam = "Remarks", ParamValue = remarks},
                    new InputParameters {SqlParam = "ModifiedBy", ParamValue = modBy},
                    new InputParameters {SqlParam = "HPSMNo", ParamValue = hpsmno},
                    new InputParameters {SqlParam = "TransactionTypeID", ParamValue = transactype},
                    new InputParameters {SqlParam = "FromCubicleID", ParamValue = fromcubicleId},
                    new InputParameters {SqlParam = "FromUserID", ParamValue = frmUSerId},
                    new InputParameters {SqlParam = "AssetStatusID", ParamValue = assetstatusId}
                };
            _dbResult = QueryHelper.InsertDeployRegister(ipInsertDeployReg);

            if (_dbResult.Result)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "alert('Record saved successfully.');window.location='AddDeploymentItem.aspx';", true);
                txtSerialNumber.Text = "";
                txtFarNumber.Text = "";
                txtQrCode.Text = "";
                txtRemarks.Text = "";
                txtHpsm.Text = "";
                cmbTransactionType.SelectedIndex = -1;
                cmbFrmBuilding.SelectedIndex = -1;
                cmbFrmFloor.SelectedIndex = -1;
                cmbFromCubicle.SelectedIndex = -1;
                cmbAssetStatus.SelectedIndex = -1;
                cmbSelectAssetType.SelectedIndex = -1;
                cmbAsset.SelectedIndex = -1;
                cmbBuilding.SelectedIndex = -1;
                cmbFloor.SelectedIndex = -1;
                cmbCubicle.SelectedIndex = -1;
                cmbFromUserPSID.SelectedIndex = -1;
                cmbToUserPsid.SelectedIndex = -1;
                cmbEngPsid.SelectedIndex = -1;
                cmbReviewStatus.SelectedIndex = -1;
                dtDeploydate.Text = "";

                //Code for Automatic Mailer when the record is Inserted
                //var mailerDetailsParam = new List<InputParameters>
                //{
                //    new InputParameters {SqlParam = "PSID", ParamValue = userPsid}
                //};

                //string toMailID = "";
                //string toUserName = "";
                //string fromMailID = "";

                //_mailerDetails = QueryHelper.GetMailerDetails(mailerDetailsParam);
                //if (_mailerDetails.Tables[0].Rows.Count > 0 && _mailerDetails != null)
                //{
                //    var dataMailRow = _mailerDetails.Tables[0].Rows[0];
                //    toMailID = dataMailRow["ToMailID"].ToString();
                //    toUserName = dataMailRow["ToUserName"].ToString();
                //    fromMailID = dataMailRow["FromMailID"].ToString();
                //}

                //MailMessage mailMessage = new MailMessage();
                //mailMessage.To.Add(toMailID);
                //mailMessage.From = new MailAddress(fromMailID);
                //mailMessage.Subject = "Asset Declartion";

                ////mailMessage.Body = @" ";
                //string body = string.Empty;
                //using (StreamReader reader = new StreamReader(Server.MapPath("~/Templates/DeployemntRegisterEmailTemplate.html")))
                //{
                //    mailMessage.Body = reader.ReadToEnd();
                //}
                //body = body.Replace("{User}", toUserName);
                //body = body.Replace("{HPSMNumber}", hpsmno);

                //mailMessage.IsBodyHtml = true;
                //SmtpClient smtpClient = new SmtpClient("10.6.12.229");

                //try
                //{
                //   // smtpClient.Send(mailMessage);
                //    ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "alert('An email is sent to '" + toUserName + "' for declaring the Assets ');window.location='AddDeploymentItem.aspx';", true);
                //}
                //catch (Exception ex)
                //{
                //    ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "alert('failed to send email with the following error:'" + ex.Message +");window.location='AddDeploymentItem.aspx';", true);
                //}

            }
            else
            {
                lblMsg.Text = _dbResult.Message;
                lblMsg.ForeColor = Color.Red;
            }

        }

        protected void cmbFrmFloor_OnCallback(object sender, CallbackEventArgsBase e)
        {
            if (IsCallback)
            {
                int blockId = Convert.ToInt32(cmbFrmBuilding.SelectedItem.Value);
                LoadFromFloor(blockId);
                if (SeatingData.FloorId != null)
                {
                    cmbFrmFloor.SelectedIndex = cmbFrmFloor.Items.FindByValue(SeatingData.FloorId).Index;
                }
                else
                {
                    cmbFrmFloor.SelectedIndex = -1;
                }
                cmbFromCubicle.SelectedIndex = -1;
            }
        }

        protected void cmbFromCubicle_OnCallback(object sender, CallbackEventArgsBase e)
        {
            if (IsCallback)
            {
                if (cmbFrmFloor.Value != null)
                {
                    int buildingFloorId = Convert.ToInt32(cmbFrmFloor.Value);
                    LoadFromCubicle(buildingFloorId);
                }
                if (SeatingData.CubicleId != null)
                {
                    cmbFromCubicle.SelectedIndex =
                        cmbFromCubicle.Items.FindByValue(SeatingData.CubicleId).Index;
                }
                else
                    cmbFromCubicle.SelectedIndex = -1;
            }

            SeatingData.FloorId = null;
            SeatingData.CubicleId = null;
        }

        protected void cmbAsset_OnCallback(object sender, CallbackEventArgsBase e)
        {
            if (cmbSelectAssetType.SelectedItem.Value != null)
            {
                var assetid = cmbSelectAssetType.SelectedItem.Value.ToString();
                Application["assetid"] = assetid;
                cmbAsset.DataSource = QueryHelper.GetAssetItem(assetid);
                cmbAsset.DataBind();
                cmbAsset.SelectedIndex = -1;
            }
        }

        protected void cmbFloor_OnCallback(object sender, CallbackEventArgsBase e)
        {
            if (IsCallback)
            {
                int blockId = Convert.ToInt32(cmbBuilding.SelectedItem.Value);
                LoadToFloor(blockId);
                if (SeatingData.FloorId != null)
                {
                    cmbFloor.SelectedIndex = cmbFloor.Items.FindByValue(SeatingData.FloorId).Index;
                }
                else
                {
                    cmbFloor.SelectedIndex = -1;
                }
                cmbCubicle.SelectedIndex = -1;
            }
        }

        protected void cmbCubicle_OnCallback(object sender, CallbackEventArgsBase e)
        {
            if (IsCallback)
            {
                if (cmbFloor.Value != null)
                {
                    int buildingFloorId = Convert.ToInt32(cmbFloor.Value);
                    LoadToCubicle(buildingFloorId);
                }

                if (SeatingData.CubicleId != null)
                {
                    cmbCubicle.SelectedIndex =
                        cmbCubicle.Items.FindByValue(SeatingData.CubicleId).Index;
                }
                else
                    cmbCubicle.SelectedIndex = -1;
            }

            SeatingData.FloorId = null;
            SeatingData.CubicleId = null;
        }

        protected void cmbFrmBuilding_OnCallback(object sender, CallbackEventArgsBase e)
        {

            if (cmbFromUserPSID.Value != null)
            {
                var psid = cmbFromUserPSID.Value;

                var ipEmployeeSeat = new List<InputParameters>
                    {
                        new InputParameters {SqlParam = "PSID", ParamValue = psid.ToString()},
                    };
                _dataSetEmp = QueryHelper.GetEmpSeatonPsid(ipEmployeeSeat);
            }

            if (_dataSetEmp != null && _dataSetEmp.Tables[0].Rows.Count > 0)
            {
                cmbFrmBuilding.DataSource = LoadBuilding();
                cmbFrmBuilding.DataBind();
                cmbFrmBuilding.SelectedIndex =
                    cmbFrmBuilding.Items.FindByValue(_dataSetEmp.Tables[0].Rows[0]["BuildingID"].ToString()).Index;

                SeatingData.FloorId = Convert.ToInt32(_dataSetEmp.Tables[0].Rows[0]["BuildingFloorID"]).ToString();
                SeatingData.CubicleId = Convert.ToInt32(_dataSetEmp.Tables[0].Rows[0]["CubicleNumber"]).ToString();

                LoadFromFloor(Convert.ToInt32(cmbFrmBuilding.SelectedItem.Value));
                cmbFrmFloor.SelectedIndex =
                    cmbFrmFloor.Items.FindByValue(_dataSetEmp.Tables[0].Rows[0]["BuildingFloorID"].ToString()).Index;

                LoadFromCubicle(Convert.ToInt32(cmbFrmFloor.SelectedItem.Value));
                cmbFromCubicle.SelectedIndex = cmbFromCubicle.Items.FindByValue(_dataSetEmp.Tables[0].Rows[0]["CubicleNumber"].ToString()).Index;
            }

        }

        protected void btnUpdate_OnClick(object sender, EventArgs e)
        {
            var keyValue = !string.IsNullOrEmpty(Request.QueryString["keyValue"]) ? Request.QueryString["keyValue"] : "";
            var assetId = (cmbAsset.Value ?? "").ToString();
            var userPsid = (cmbToUserPsid.Value ?? "").ToString();
            var cubicleId = (cmbCubicle.Value ?? "").ToString();
            var depDate = (dtDeploydate.Value ?? "").ToString();
            var review = (cmbReviewStatus.Value ?? "").ToString();
            var fromcubicleId = (cmbFromCubicle.Value ?? "").ToString();
            var transactype = (cmbTransactionType.Value ?? "").ToString();
            var assetstatusId = (cmbAssetStatus.Value ?? "").ToString();
            var engPSid = (cmbEngPsid.Value ?? "").ToString();
            var frmUSerId = (cmbFromUserPSID.Value ?? "").ToString();
            var hpsmno = txtHpsm.Text ?? string.Empty;
            var remarks = txtRemarks.Text ?? string.Empty;
            var modBy = Session["PSID"].ToString();

            var ipDeployreg = new List<InputParameters>
                {
                    new InputParameters {SqlParam = "DepRegisterID", ParamValue = keyValue},
                    new InputParameters {SqlParam = "AssetID", ParamValue = assetId},
                    new InputParameters {SqlParam = "UserPSID", ParamValue = userPsid},
                    new InputParameters {SqlParam = "CubicleID", ParamValue = cubicleId},
                    new InputParameters {SqlParam = "EngineerPSID", ParamValue = engPSid},
                    new InputParameters {SqlParam = "DeploymentDate", ParamValue = depDate},
                    new InputParameters {SqlParam = "ReviewStatus", ParamValue = review},
                    new InputParameters {SqlParam = "Remarks", ParamValue = remarks},
                    new InputParameters {SqlParam = "ModifiedBy", ParamValue = modBy},
                    new InputParameters {SqlParam = "HPSMNo", ParamValue = hpsmno},
                    new InputParameters {SqlParam = "TransactionTypeID", ParamValue = transactype},
                    new InputParameters {SqlParam = "FromCubicleID", ParamValue = fromcubicleId},
                    new InputParameters {SqlParam = "FromUserID", ParamValue = frmUSerId},
                    new InputParameters {SqlParam = "AssetStatusID", ParamValue = assetstatusId}
                };
            _dbResult = QueryHelper.UpdateDeployRegister(ipDeployreg);

            if (_dbResult.Result)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "alert('Record Updated successfully.');window.location='DeploymentRegister.aspx';", true);
            }
            else
            {
                lblMsg.Text = _dbResult.Message;
                lblMsg.ForeColor = Color.Red;
            }
        }

        protected void btnCancel_OnClick(object sender, EventArgs e)
        {
            Response.Redirect("DeploymentRegister.aspx");
        }

        protected void cmbBuilding_Callback(object sender, CallbackEventArgsBase e)
        {
            if (cmbToUserPsid.Value != null)
            {
                var psid = cmbToUserPsid.Value;

                var ipEmployeeSeat = new List<InputParameters>
                    {
                        new InputParameters {SqlParam = "PSID", ParamValue = psid.ToString()},
                    };
                _dataSetEmp = QueryHelper.GetEmpSeatonPsid(ipEmployeeSeat);
            }

            if (_dataSetEmp != null && _dataSetEmp.Tables[0].Rows.Count > 0)
            {
                cmbBuilding.DataSource = LoadBuilding();
                cmbBuilding.DataBind();
                cmbBuilding.SelectedIndex =
                    cmbFrmBuilding.Items.FindByValue(_dataSetEmp.Tables[0].Rows[0]["BuildingID"].ToString()).Index;

                SeatingData.FloorId = Convert.ToInt32(_dataSetEmp.Tables[0].Rows[0]["BuildingFloorID"]).ToString();
                SeatingData.CubicleId = Convert.ToInt32(_dataSetEmp.Tables[0].Rows[0]["CubicleNumber"]).ToString();

                LoadToFloor(Convert.ToInt32(cmbBuilding.SelectedItem.Value));
                cmbFloor.SelectedIndex =
                    cmbFloor.Items.FindByValue(SeatingData.FloorId).Index;

                LoadToCubicle(Convert.ToInt32(cmbFloor.SelectedItem.Value));
                cmbCubicle.SelectedIndex = cmbCubicle.Items.FindByValue(SeatingData.CubicleId).Index;

            }
        }
    }
}