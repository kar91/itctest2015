﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using DevExpress.Web;
using DevExpress.Web.Data;
using DevExpress.XtraPrinting;
using DevExpress.Export;

namespace AssetManagement.Tasks
{
    public partial class DeploymentRegister : AssetTrackerBasePage
    {
        private string _errorMessage = "";
        private DBResult _dbResult = new DBResult();

        protected void Page_Load(object sender, EventArgs e)
        {
           
            LoadDeployRegisterGrid();
           
        }

        protected void grdDeploymentRegister_OnCellEditorInitialize(object sender, ASPxGridViewEditorEventArgs e)
        {
        }


        protected void grdDeploymentRegister_OnRowInserting(object sender, ASPxDataInsertingEventArgs e)
        {
            //_dbResult = QueryHelper.InsertDeployRegister(GetGriditems(e));
            //if (!_dbResult.Result)
            //    _errorMessage = _dbResult.Message;
            //else
            //{
            //    e.Cancel = true;
            //    grdDeploymentRegister.CancelEdit();
            //    LoadDeployRegisterGrid();
            //}
        }

        protected void grdDeploymentRegister_OnRowUpdating(object sender, ASPxDataUpdatingEventArgs e)
        {
        }

        protected void grdDeploymentRegister_OnCustomErrorText(object sender, ASPxGridViewCustomErrorTextEventArgs e)
        {
            if (!string.IsNullOrEmpty(_errorMessage))
                e.ErrorText = _errorMessage;
        }

        private void LoadDeployRegisterGrid()
        {
            grdDeploymentRegister.DataSource = QueryHelper.GetDeploymentRegister();
            grdDeploymentRegister.DataBind();
        }
       
        protected void btnexcel_Click(object sender, ImageClickEventArgs e)
        {
            gridExport.WriteXlsxToResponse(new XlsxExportOptionsEx() { ExportType = ExportType.WYSIWYG });

        }

        protected void grdDeploymentRegister_OnRowDeleting(object sender, ASPxDataDeletingEventArgs e)
        {
            var key = grdDeploymentRegister.GetRowValuesByKeyValue(e.Keys[0], "DepRegisterID").ToString();
            var ipDeployregdel = new List<InputParameters>
                {
                new InputParameters {SqlParam = "DepRegisterID", ParamValue = key }
                };
            _dbResult = QueryHelper.DeleteDeployRegister(ipDeployregdel);

            if (!_dbResult.Result)
                _errorMessage = _dbResult.Message;
            else
            {
                e.Cancel = true;
                grdDeploymentRegister.CancelEdit();
                LoadDeployRegisterGrid();
            }
        }

        protected void grdDeploymentRegister_OnCommandButtonInitialize(object sender, ASPxGridViewCommandButtonEventArgs e)
        {
            if (Convert.ToInt32(Session["IsAuthorized"]) != 1)
            {
                if (e.ButtonType == ColumnCommandButtonType.Delete)
                {
                    e.Visible = false;
                }
            }
        }
    }
}