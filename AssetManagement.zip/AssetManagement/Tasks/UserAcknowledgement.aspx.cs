﻿using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Tasks
{
    public partial class UserAcknowledgement : AssetTrackerBasePage
    {

        private bool _status = false;

        protected void Page_Load(object sender, EventArgs e)
        {
            Loaddata();
        }
        private void Loaddata()
        {
            var ipacknowledge = new List<InputParameters>();
            ipacknowledge.Add(new InputParameters { SqlParam = "PSID", ParamValue = Session["PSID"].ToString() });
            DataSet dt = QueryHelper.GetDatatoAcknowledge(ipacknowledge);
            grdAcknowledgement.DataSource = dt;
            grdAcknowledgement.DataBind();
        }

        protected void grdAcknowledgement_CustomCallback(object sender, DevExpress.Web.ASPxGridViewCustomCallbackEventArgs e)
        {
            string acknowledged = "0";
            string comment = "";
            string  call = e.Parameters;
            if (call == "1010")
                acknowledged = "1";
            else
                comment = call;

            List<object> fieldValues = grdAcknowledgement.GetSelectedFieldValues(new string[] { "ItemID" });
            var ipsearchassetgridupdate = new List<InputParameters>();
            
            foreach (var t in fieldValues)
            {
                ipsearchassetgridupdate.Add(new InputParameters { SqlParam = "PSID", ParamValue = Session["PSID"].ToString() });
                ipsearchassetgridupdate.Add(new InputParameters { SqlParam = "ItemID", ParamValue = t.ToString() });
                ipsearchassetgridupdate.Add(new InputParameters { SqlParam = "IsAcknowleged", ParamValue = acknowledged });
                ipsearchassetgridupdate.Add(new InputParameters { SqlParam = "Comments", ParamValue = comment });
                _status = QueryHelper.UserAcceptance(ipsearchassetgridupdate);
            }

            Loaddata();
        }

        protected void grdAcknowledgement_CustomColumnDisplayText(object sender, DevExpress.Web.ASPxGridViewColumnDisplayTextEventArgs e)
        {
            if (e.Column.FieldName == "UserAcceptance")
            {
                if (e.Value.ToString() == "0")
                    e.DisplayText = "Rejected";
                else if (e.Value.ToString() == "1")
                    e.DisplayText = "Acknowledged";
                else
                    e.DisplayText = "Acknowledgement Pending";
            }
        }

        protected void grdAcknowledgement_CommandButtonInitialize(object sender, DevExpress.Web.ASPxGridViewCommandButtonEventArgs e)
        {
            ASPxGridView grid = (sender as ASPxGridView);
            if (e.ButtonType == ColumnCommandButtonType.SelectCheckbox)
            {
                if (Convert.ToString(grdAcknowledgement.GetRowValues(e.VisibleIndex, "UserAcceptance")) == "1")
                    e.Enabled = false;
            }
        }

        protected void grdAcknowledgement_HtmlRowPrepared(object sender, ASPxGridViewTableRowEventArgs e)
        {
            if (e.RowType != GridViewRowType.Data) return;
            string price = Convert.ToString(e.GetValue("UserAcceptance"));
            if (price == "0")
                e.Row.BackColor = System.Drawing.Color.FromArgb(255, 242, 204);
        }
    }
}