﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Web.UI.WebControls;


namespace AssetManagement.Tasks
{
    public partial class PrintTemplate : AssetTrackerBasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           // List<commonHelper.inputParameters> param = new List<commonHelper.inputParameters>();

            if(!IsPostBack)
            { 
            Load();
            }
            var floorName = ddlfloor.SelectedValue;

            //  param.Add(new commonHelper.inputParameters { sqlParam = "FloorID", paramValue = c.ToString() });


            //  commonHelper.fetchData("Usp_PrintData", param);
            if (floorName != null && floorName!= "")
            {
                XtraReports report = new XtraReports();
                report.Parameters[0].Value = floorName;
                report.Parameters[0].Visible = false;
                ReportViewer1.Report = report;

            }

           
        }


        protected void Load()
        {
            DataTable dt = new DataTable();
            dt = QueryHelper.GetLocations().Tables[0];
            ddllocation.DataSource = dt;
            ddllocation.DataTextField = "LocationName";
            ddllocation.DataValueField = "LocationID";
            ddllocation.DataBind();
            int LocationID =2;

            var ipbuildingonlocation = new List<InputParameters>
                    {
                        new InputParameters {SqlParam = "LocationID", ParamValue = LocationID.ToString()},
                        new InputParameters {SqlParam = "PSID", ParamValue = Session["PSID"].ToString()},
                        new InputParameters {SqlParam = "ApplicationID", ParamValue = Convert.ToInt16(ConfigurationManager.AppSettings["ApplicationID"]).ToString()}
                    };

            ddlbuilding.DataSource = QueryHelper.GetBlockBasedOnLocation(ipbuildingonlocation);
            ddlbuilding.DataTextField = "BuildingName";
            ddlbuilding.DataValueField = "BuildingID";
            ddlbuilding.DataBind();
            ddlbuilding.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        protected void ddllocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            int LocationID = Convert.ToInt32(ddllocation.SelectedItem.Value);

            var ipbuildingonlocation = new List<InputParameters>
                    {
                        new InputParameters {SqlParam = "LocationID", ParamValue = LocationID.ToString()},
                        new InputParameters {SqlParam = "PSID", ParamValue = Session["PSID"].ToString()},
                        new InputParameters {SqlParam = "ApplicationID", ParamValue = Convert.ToInt16(ConfigurationManager.AppSettings["ApplicationID"]).ToString()}
                    };

            ddlbuilding.DataSource = QueryHelper.GetBlockBasedOnLocation(ipbuildingonlocation);
            ddlbuilding.DataTextField = "BuildingName";
            ddlbuilding.DataValueField = "BuildingID";
            ddlbuilding.DataBind();
            ddlbuilding.Items.Insert(0, new ListItem("--Select--", "0"));

        }

        protected void ddlbuilding_SelectedIndexChanged(object sender, EventArgs e)
        {
            int BlockID = Convert.ToInt32(ddlbuilding.SelectedItem.Value);

            var ipareabasedonblock = new List<InputParameters>
            {
                new InputParameters {SqlParam = "BuildingID", ParamValue = BlockID.ToString()},
                new InputParameters {SqlParam = "PSID", ParamValue = Session["PSID"].ToString()},
                new InputParameters {SqlParam = "ApplicationID", ParamValue = Convert.ToInt16(ConfigurationManager.AppSettings["ApplicationID"]).ToString()}
            };

            ddlfloor.DataSource = QueryHelper.GetAreaBasedOnBlock(ipareabasedonblock);
            ddlfloor.DataTextField = "FloorNo";
            ddlfloor.DataValueField = "BuildingFloorID";
            ddlfloor.DataBind();
            ddlfloor.Items.Insert(0, new ListItem("--Select--", "0"));
        }

        protected void ddlfloor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}