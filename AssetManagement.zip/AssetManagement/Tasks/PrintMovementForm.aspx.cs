﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace AssetManagement
{
    public partial class PrintMovementForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Control ctrl = (Control)Session["ctrl"];
            //PrintHelper.PrintWebControl(ctrl);
        }

        protected void btnprint_Click(object sender, EventArgs e)
        {
            
            Session["ctrl"] = printpanel;
            Control ctrl = (Control)Session["ctrl"];
            PrintWebControl(ctrl);
            btnprint.Visible = true;
        }

        public static void PrintWebControl(Control ControlToPrint)
        {
            StringWriter stringWrite = new StringWriter();
            System.Web.UI.HtmlTextWriter htmlWrite = new System.Web.UI.HtmlTextWriter(stringWrite);
            if (ControlToPrint is WebControl)
            {
                Unit w = new Unit(100, UnitType.Percentage);
                ((WebControl)ControlToPrint).Width = w;
            }
            Page pg = new Page();
            pg.EnableEventValidation = false;
            HtmlForm frm = new HtmlForm();
            pg.Controls.Add(frm);
            frm.Attributes.Add("runat", "server");
            frm.Controls.Add(ControlToPrint);
            pg.DesignerInitialize();
            pg.RenderControl(htmlWrite);
            string strHTML = stringWrite.ToString();
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Write(strHTML);
            HttpContext.Current.Response.Write("<script>window.print();</script>");
            HttpContext.Current.Response.End();
        }
        
    }
}