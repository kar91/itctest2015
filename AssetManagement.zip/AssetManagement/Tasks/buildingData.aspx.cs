﻿using DevExpress.Export;
using DevExpress.XtraPrinting;
using System;
using System.Collections.Generic;
using System.Web.UI;

namespace AssetManagement.Tasks
{
    public partial class BuildingData : AssetTrackerBasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Loadgrid();
        }

        private void Loadgrid()
        {
            var ippsid = new List<InputParameters>();
            ippsid.Add(new InputParameters { SqlParam = "PSID", ParamValue = Session["PSID"].ToString() });

            buildinggrid.DataSource = QueryHelper.GetPvReport(ippsid);
            buildinggrid.DataBind();
        }

        protected void btnexcel_Click(object sender, ImageClickEventArgs e)
        {
            buildinggridExport.WriteXlsxToResponse(new XlsxExportOptionsEx() { ExportType = ExportType.WYSIWYG });

        }
    }
}