﻿using AssetManagementLibrary;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.Entities.Movement;
using AssetManagementLibrary.OtherHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using AssetManagement.UIHelper;
using DevExpress.Web;

namespace AssetManagement.Tasks
{
    public class AssetTrackerBasePage : System.Web.UI.Page
    {
        /// <summary>
        /// Variable holds the access groups list. By default added Admin group
        /// </summary>
        private List<string> _accessGroups = new List<string>() { "Admin" };
        public AssetManagementLibrary.Queries QueryHelper
        {
            get
            {
                return new AssetManagementLibrary.Queries();
            }
        }

        protected T GetSessionValue<T>(string key)
        {
            return (T)Session[key];
        }

        /// <summary>
        /// sets the range to the accessGroups list.
        /// </summary>
        protected List<string> AccessGroups
        {
            private get
            {
                return _accessGroups;
            }
            set
            {
                _accessGroups.AddRange(value);
            }
        }

        protected string GetPSID
        {
            get
            {

                var userprofile = GetSessionValue<UserProfile>("UserProfile");
                if (userprofile != null)
                    return userprofile.PSID;

                return null;
            }
        }
        protected string GetName
        {
            get
            {

                var userprofile = GetSessionValue<UserProfile>("UserProfile");
                if (userprofile != null)
                    return userprofile.Name;

                return null;
            }
        }
        protected int? GetGroupID
        {
            get
            {

                var userprofile = GetSessionValue<UserProfile>("UserProfile");
                if (userprofile != null)
                    return userprofile.UserGroups.FirstOrDefault().GroupID;

                return null;
            }
        }
        protected int? GetFloorID
        {
            get
            {

                var userprofile = GetSessionValue<UserProfile>("UserProfile");
                if (userprofile != null)
                    return userprofile.FloorID;

                return null;
            }
        }


        protected string GetUserLocation
        {
            get
            {
                var userprofile = GetSessionValue<UserProfile>("UserProfile");
                if (userprofile != null)
                    return userprofile.Location;

                return string.Empty;
            }
        }

        protected string GetUserWorkLocation
        {
            get
            {
                var userprofile = GetSessionValue<UserProfile>("UserProfile");
                if (userprofile != null)
                    return userprofile.Worklocation;

                return string.Empty;
            }
        }

        /// <summary>
        /// Gets the Pruposes by value
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        protected int GetPurposeID(string value)
        {
            return CacheHelper.GetInstance.GetValue("Purposes", new Queries().GetPurposeDictionary, 100, true, null)
                .FirstOrDefault(x => x.Value.ToLower().Trim() == value.Trim().ToLower()).Key;
        }

        /// <summary>
        /// Gets the Pruposes by ID
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        protected string GetPurposeName(int key)
        {
            return CacheHelper.GetInstance.GetValue("Purposes", new Queries().GetPurposeDictionary, 100, true, null)
               .GetValueOrDefault(key, null);
        }

        /// <summary>
        /// Get list of purpose 
        /// </summary>
        protected Dictionary<int, string> GetPurposes
        {
            get
            {
                return CacheHelper.GetInstance.GetValue("Purposes", new Queries().GetPurposeDictionary, 100, true, null);
            }
        }

        public bool UpdateStatus(int assetTransID, int sysPurposeStageID, string modBy)
        {
            AssetManagementLibrary.Queries qryHelper = new AssetManagementLibrary.Queries();
            var ipUpdateAssetStatus = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AssetTranID", ParamValue = assetTransID},
                new InputParameters {SqlParam = "SysPurposeStageID", ParamValue = sysPurposeStageID},
                new InputParameters {SqlParam = "ModBy", ParamValue = modBy}

            };
            qryHelper.UpdateAssetStatus(ipUpdateAssetStatus);
            return true;
        }

        /// <summary>
        /// Checks weather the user authorized to view the page based on the AccessGroups.
        /// </summary>
        protected void IsInGroup()
        {
            var userProfile = GetSessionValue<UserProfile>("UserProfile");
            if (userProfile != null)
            {
                var result = userProfile.UserGroups.Any(grp => AccessGroups.Any(x => x == grp.GroupName));
                if (!result)
                {
                    Response.Redirect("NotAuthorized.aspx");
                    //Server.Transfer("~/Error/User404.html");
                }
            }
        }

        /// <summary>
        /// Gets the enginner specific to building
        /// </summary>
        /// <param name="buildingId">building Id</param>
        /// <returns>engineer type</returns>
        protected Engineer GetBuildingEnginner(int buildingId)
        {
            return CacheHelper.GetInstance.GetValue("Engineers", new Queries().GetEnginnersDetail, 100, true, null)
                .Where(w => w.BuildingInfo.Any(b => b.BuildingId == buildingId)).FirstOrDefault();
        }

        /// <summary>
        /// Gets all the building enginners 
        /// </summary>
        protected List<Engineer> GetBuildingEngineers
        {
            get
            {
                return CacheHelper.GetInstance.GetValue("Engineers", new Queries().GetEnginnersDetail, 100, true, null)
                .Where(w => w.Type == "BE").ToList();
            }
        }

        /// <summary>
        /// Gets all the movement engineers
        /// </summary>
        protected List<Engineer> GetMovementEngineers
        {
            get
            {
                return CacheHelper.GetInstance.GetValue("Engineers", new Queries().GetEnginnersDetail, 100, true, null)
                .Where(w => w.Type == "M").ToList();
            }
        }

        /// <summary>
        /// Gets all the AssetLeads
        /// </summary>
        protected List<Engineer> GetAssetLeads
        {
            get
            {
                return CacheHelper.GetInstance.GetValue("Engineers", new Queries().GetEnginnersDetail, 100, true, null)
                .Where(w => w.Type == "AL").ToList();
            }
        }

        [System.Web.Services.WebMethod]
        public static string GetCurrentTime(string name)
        {
            return "Hello " + name + Environment.NewLine + "The Current Time is: "
                + DateTime.Now.ToString();
        }

        public void SetComboxValueInSession(string sessionKey, string key, List<FilterValues> values)
        {
            if (Session[sessionKey] != null)
            {
                var result = (List<Filter>)Session[sessionKey];
                if (result.Any(x => x.Key == key))
                {
                    result.Where(x => x.Key == key).FirstOrDefault().Value = values;
                }
                else
                {
                    result.Add(new Filter { Key = key, Value = values });
                }
                Session[sessionKey] = result;
            }
            else
                Session[sessionKey] = new List<Filter> { new Filter { Key = key, Value = values } };


        }

        public void BindComboxFromSession(string sessionKey, string key, ASPxComboBox combo)
        {
            if (Session[sessionKey] != null)
            {
                var result = GetSessionValue<List<Filter>>(sessionKey).Where(x => x.Key == key).FirstOrDefault().Value;
                combo.DataSource = result;
                combo.ValueField = "Value";
                combo.TextField = "Name";
                combo.DataBind();
            }
        }

    }

}