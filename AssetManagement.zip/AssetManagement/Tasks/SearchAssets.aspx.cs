﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web.UI;
using DevExpress.Web;
using System.Web;

namespace AssetManagement.Tasks
{
    public partial class SearchAssets : AssetTrackerBasePage
    {
        #region Private Variables

        string _errorMessage = "";
        private DataSet _dsassetstatus = null;
        private DataSet _dsassettype = null;
        private DataSet _dsscanengineer = null;
        private DataSet _dssearchassetgrid = null;
        private bool _updatestatus = false;
        private DBResult _updateDbResult = new DBResult();
        private bool enablefilter = false;
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            System.Web.UI.WebControls.Button myObject;
            myObject = (System.Web.UI.WebControls.Button)Master.FindControl("DeployItem");
            myObject.Attributes.Add("class", "flatdivonselect");
            myObject = (System.Web.UI.WebControls.Button)Master.FindControl("AsseInventory");
            myObject.Attributes.Add("class", "flatdivonselect");
            myObject = (System.Web.UI.WebControls.Button)Master.FindControl("AssetDailyReview");
            myObject.Attributes.Add("class", "flatdivonselect");

            LoadAssetTypeStatus();
            loadsecondfilter();
            grdAssetTracker.JSProperties["cpIsErrorMsg"] = "";
            LoadData();
            if (IsPostBack)
            {
                SetState();
                int user = 0;
                DateTime? strt = null;
                DateTime? end = null;
                DateTime fdt = dtfrom.Date;
                DateTime edt = dtto.Date;




                if (int.Parse(Session["filter"].ToString()) == 1)
                {
                    if (cmbUser.Value == null || cmbUser.Value.ToString() == "-1")
                    {

                        cmbUser.SelectedIndex = 0;
                        user = (int)cmbUser.Value;
                    }
                    else
                        user = (int)cmbUser.Value;

                    if (fdt.Year < DateTime.Now.Year)
                        strt = null;
                    else
                        strt = fdt;

                    if (fdt.Year < DateTime.Now.Year)
                        end = null;
                    else
                        end = edt;
                    LoadGridView(null, strt, end, user);
                }
                else
                {
                    int? cubicle = null;
                    if (cmbarea.Value == null)
                    {
                        cubicle = null;
                    }

                    else
                    {
                        cubicle = int.Parse(cmbarea.Value.ToString());
                    }
                    LoadGridView(cubicle, null, null, null);

                }
            }
            if (Page.IsPostBack) return;
            dtfrom.Date = DateTime.Now.Date;
            dtto.Date = DateTime.Now.Date;
        }

        private void LoadAssetTypeStatus()
        {
            _dsassetstatus = QueryHelper.GetAssetStatus();
            _dsassettype = QueryHelper.GetAssetType();
        }



        private void loadsecondfilter()
        {


            var ipbuildingonlocation = new List<InputParameters>
                    {
                        new InputParameters {SqlParam = "LocationID", ParamValue = "2"},
                        new InputParameters {SqlParam = "PSID", ParamValue = Session["PSID"].ToString()},
                        new InputParameters {SqlParam = "ApplicationID", ParamValue = Convert.ToInt16(ConfigurationManager.AppSettings["ApplicationID"]).ToString()}
                    };
            cmbbuilding.DataSource = QueryHelper.GetBlockBasedOnLocation(ipbuildingonlocation);
            cmbbuilding.TextField = "BuildingName";
            cmbbuilding.ValueField = "BuildingID";
            cmbbuilding.DataBind();
            //cmbbuilding.Items.Insert(0, new ListItem("--Select Building--", "0"));
        }
        private void LoadData()
        {
            LoadAssetTypeStatus();

            var ipsacnengineer = new List<InputParameters>();
            ipsacnengineer.Add(new InputParameters { SqlParam = "PSID", ParamValue = Session["PSID"].ToString() });
            ipsacnengineer.Add(new InputParameters { SqlParam = "ApplicationID", ParamValue = ConfigurationManager.AppSettings["ApplicationID"] });
            ipsacnengineer.Add(new InputParameters { SqlParam = "AssetSearch", ParamValue = "1" });
            _dsscanengineer = QueryHelper.GetScanUser(ipsacnengineer);

            cmbUser.DataSource = _dsscanengineer;
            cmbUser.ValueType = typeof(Int32);
            cmbUser.TextField = "Name";
            cmbUser.ValueField = "ScanUser";
            cmbUser.DataBind();
        }


        private void LoadGridView(int? loc, DateTime? st, DateTime? et, int? uid)
        {

            var ipsearchassetgrid = new List<InputParameters>
            {
                new InputParameters {SqlParam = "Name", ParamValue = loc.ToString()},
                new InputParameters {SqlParam = "StartDate", ParamValue = st.ToString()},
                new InputParameters {SqlParam = "EndDate", ParamValue = et.ToString()},
                new InputParameters {SqlParam = "ScanUserID", ParamValue = uid.ToString()}
            };
            _dssearchassetgrid = QueryHelper.LoadGrid(ipsearchassetgrid);
            grdAssetTracker.DataSource = _dssearchassetgrid;
            grdAssetTracker.DataBind();
        }

        protected void btnexcel_Click(object sender, ImageClickEventArgs e)
        {
            grdAssetTreackerExport.WriteXlsToResponse();
        }

        protected void grdAssetTracker_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            DateTime? strt = null;
            DateTime? end = null;
            DateTime fdt = dtfrom.Date;
            DateTime edt = dtto.Date;
            int user = (int)cmbUser.Value;

            if (fdt.Year < DateTime.Now.Year)
                strt = null;
            else
                strt = fdt;

            if (fdt.Year < DateTime.Now.Year)
                end = null;
            else
                end = edt;

            #region btnUpdateYes_Click
            try
            {
                string key = grdAssetTracker.GetRowValuesByKeyValue(e.Keys[0], "ItemID").ToString();
                string modifiedby = Convert.ToString(Session["PSID"]);
                var cubestat = "";
                if (e.NewValues["CubicleStatus"].ToString() == e.OldValues["CubicleStatus"].ToString())
                {
                    cubestat = Convert.ToString(e.OldValues["CubicleStatus"]);
                }
                else
                    cubestat = Convert.ToString(e.NewValues["CubicleStatus"]);

                string psid = Convert.ToString(e.NewValues["PSID"]);
                string serialnum = Convert.ToString(e.NewValues["SerialNumber"]);
                string qrcode = Convert.ToString(e.NewValues["QRCode"]);
                string farnumb = Convert.ToString(e.NewValues["FARNumber"]);
                int present = Convert.ToInt32(e.NewValues["UserPresence"]);
                // to get Asset Type ID
                int value;
                var assettypeId = 0;
                if (int.TryParse(e.NewValues["AssetType"].ToString(), out value))
                {
                    assettypeId = Convert.ToInt32(e.NewValues["AssetType"]);
                }
                else
                {
                    string assettype = e.NewValues["AssetType"].ToString();
                    var rowCol = _dsassettype.Tables[0].AsEnumerable();
                    assettypeId = (from r in rowCol
                                   where r.Field<string>("AssetType") == assettype
                                   select r.Field<int>("SysAssetTypeID")).First<int>();
                }
                // to get Asset Status ID
                var assetstatusId = 0;
                if (int.TryParse(e.NewValues["AssetStatus"].ToString(), out value))
                {
                    assetstatusId = Convert.ToInt32(e.NewValues["AssetStatus"]);

                }
                else
                {
                    string assetStatus = e.NewValues["AssetStatus"].ToString();
                    var rowCol = _dsassetstatus.Tables[0].AsEnumerable();
                    assetstatusId = (from r in rowCol
                                     where r.Field<string>("AssetStatus") == assetStatus
                                     select r.Field<int>("SysAssetStatusID")).First<int>();
                }

                var ipsearchassetgridupdate = new List<InputParameters>
                {
                    new InputParameters {SqlParam = "AssetTrackerID", ParamValue = key},
                    new InputParameters {SqlParam = "CubicleStatus", ParamValue = cubestat},
                    new InputParameters {SqlParam = "PSID", ParamValue = psid},
                    new InputParameters {SqlParam = "AssetStatusID", ParamValue = assetstatusId.ToString()},
                    new InputParameters {SqlParam = "AssetTypeID", ParamValue = assettypeId.ToString()},
                    new InputParameters {SqlParam = "SerialNumber", ParamValue = serialnum},
                    new InputParameters {SqlParam = "QRCode", ParamValue = qrcode},
                    new InputParameters {SqlParam = "FARNumber", ParamValue = farnumb},
                    new InputParameters {SqlParam = "Present", ParamValue = present.ToString()},
                    new InputParameters {SqlParam = "ModifiedBy", ParamValue = modifiedby}
                };

                _updateDbResult = QueryHelper.AssetTrackerUpdate(ipsearchassetgridupdate);

                if (_updateDbResult.Result == false)
                {
                    _errorMessage = _updateDbResult.Message;
                }
                else
                {
                    e.Cancel = true;
                    grdAssetTracker.CancelEdit();
                    LoadGridView(null, strt, end, user);
                }

            }
            catch (Exception ex)
            {
                // ignored
            }

            #endregion

        }



        protected void grdAssetTracker_CellEditorInitialize(object sender, DevExpress.Web.ASPxGridViewEditorEventArgs e)
        {
            if (!e.Column.FieldName.Equals("ModifiedBy") && !e.Column.FieldName.Equals("Name") &&
                !e.Column.FieldName.Equals("CubicleNumber") && !e.Column.FieldName.Equals("ReviewStatus") &&
                !e.Column.FieldName.Equals("ReviewedBy") && !e.Column.FieldName.Equals("ReviewDate") &&
                !e.Column.FieldName.Equals("ScanDate") && !e.Column.FieldName.Equals("ItemID") &&
                !e.Column.FieldName.Equals("LocationName") && !e.Column.FieldName.Equals("BuildingName") &&
                !e.Column.FieldName.Equals("FloorNo") && !e.Column.FieldName.Equals("ScannedBy") &&
                !e.Column.FieldName.Equals("CubicleType"))
            {
            }
            else
            {
                e.Editor.BackColor = Color.LightGray;
            }
            if (!e.Column.FieldName.Equals("AssetType"))
            {
            }
            else
            {
                ASPxComboBox cmb = e.Editor as ASPxComboBox;
                cmb.DataSource = _dsassettype;
                cmb.ValueField = "SysAssetTypeID";
                cmb.ValueType = typeof(Int32);
                cmb.TextField = "AssetType";
                cmb.DataBindItems();
            }


            if (!e.Column.FieldName.Equals("AssetStatus")) return;
            {
                ASPxComboBox cmb = e.Editor as ASPxComboBox;
                cmb.DataSource = _dsassetstatus;
                cmb.ValueField = "SysAssetStatusID";
                cmb.ValueType = typeof(Int32);
                cmb.TextField = "AssetStatus";
                cmb.DataBindItems();
            }
        }

        protected void cbPage_Init(object sender, EventArgs e)
        {
            ASPxCheckBox chk = sender as ASPxCheckBox;

            ASPxGridView grid = (chk.NamingContainer as GridViewHeaderTemplateContainer).Grid;

            Boolean cbChecked = true;

            Int32 start = grid.VisibleStartIndex;

            Int32 end = grid.VisibleStartIndex + grid.SettingsPager.PageSize;

            end = (end > grid.VisibleRowCount ? grid.VisibleRowCount : end);

            for (int i = start; i < end; i++)

                if (!grid.Selection.IsRowSelected(i))
                {
                    cbChecked = false;
                    break;
                }

            chk.Checked = cbChecked;
        }

        protected void lnkSelectAllRows_Load(object sender, EventArgs e)
        {

        }

        protected void lnkSelectAllRows_Load1(object sender, EventArgs e)
        {

        }

        protected void lnkClearSelection_Load(object sender, EventArgs e)
        {

        }

        protected void grdAssetTracker_HtmlDataCellPrepared(object sender, ASPxGridViewTableDataCellEventArgs e)
        {
            //    if (e.DataColumn.FieldName == "ReviewStatus")
            //    {

            //        if (e.CellValue.ToString() == "Not Reviewed")
            //            e.Cell.BackColor = System.Drawing.Color.FromArgb(255, 242, 204);
            //        else
            //            e.Cell.BackColor = System.Drawing.Color.FromArgb(226, 239, 218);

            //    }
        }

        protected void grdAssetTracker_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            hdnchk["myValue"] = "success";
            string type = e.Parameters;
            string revby = Convert.ToString(Session["PSID"].ToString());
            List<object> fieldValues = grdAssetTracker.GetSelectedFieldValues(new string[] { "ItemID" });
            grdAssetTracker.Selection.UnselectAll();
            var ipsearchassetgridupdate = new List<InputParameters>();
            if (fieldValues.Count <= 0) return;
            if (type == "commitclick")
            {
                try
                {
                    foreach (var t in fieldValues)
                    {
                        ipsearchassetgridupdate.Add(new InputParameters { SqlParam = "AssetID", ParamValue = t.ToString() });
                        ipsearchassetgridupdate.Add(new InputParameters { SqlParam = "PSID", ParamValue = revby });
                        _updatestatus = QueryHelper.AssetInsertReview(ipsearchassetgridupdate);

                        if (_updatestatus != false) continue;
                        _errorMessage = "error occured";
                        ((ASPxGridView)sender).JSProperties["cpIsErrorMsg"] = _errorMessage;
                    }
                    reload();
                }

                catch (Exception ex)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Records can not be saved at the moment ,contact local admin" + "');", true);

                }
            }
            else
            {
                try
                {
                    foreach (var t in fieldValues)
                    {
                        ipsearchassetgridupdate.Add(new InputParameters { SqlParam = "PSID", ParamValue = Session["PSID"].ToString() });
                        ipsearchassetgridupdate.Add(new InputParameters { SqlParam = "ItemID", ParamValue = t.ToString() });
                        ipsearchassetgridupdate.Add(new InputParameters { SqlParam = "IsAcknowleged", ParamValue = "1" });
                        ipsearchassetgridupdate.Add(new InputParameters { SqlParam = "Comments", ParamValue = "" });
                        _updatestatus = QueryHelper.UserAcceptance(ipsearchassetgridupdate);
                    }

                    reload();
                }
                catch (Exception ex)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Records can not be marked reviewed at the moment ,contact local admin" + "');", true);

                }
            }
        }

        private void reload()
        {
            if (int.Parse(Session["filter"].ToString()) == 1)
            {
                int user = 0;
                DateTime? strt = null;
                DateTime? end = null;
                DateTime fdt = dtfrom.Date;
                DateTime edt = dtto.Date;

                if (cmbUser.Value == null)
                {
                    cmbUser.SelectedIndex = 0;
                    user = (int)cmbUser.Value;
                }
                else
                    user = (int)cmbUser.Value;

                if (fdt.Year < DateTime.Now.Year)
                    strt = null;
                else
                    strt = fdt;
                if (fdt.Year < DateTime.Now.Year)
                    end = null;
                else
                    end = edt;
                LoadGridView(null, strt, end, user);
            }
            else
            {
                int? cubicle = null;
                if (cmbarea.Value == null)
                {
                    cubicle = null;
                }

                else
                {
                    cubicle = int.Parse(cmbarea.Value.ToString());
                }
                LoadGridView(cubicle, null, null, null);
            }
        }
        private string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["AvaluetConnectionString"].ConnectionString;

        }

        protected void grdAssetTracker_HtmlCommandCellPrepared(object sender, ASPxGridViewTableCommandCellEventArgs e)
        {

        }

        protected void grdAssetTracker_CommandButtonInitialize(object sender, ASPxGridViewCommandButtonEventArgs e)
        {
            ASPxGridView grid = (sender as ASPxGridView);
            if (e.ButtonType == ColumnCommandButtonType.SelectCheckbox)
            {

                if (Convert.ToString(grdAssetTracker.GetRowValues(e.VisibleIndex, "UserAcceptance")) == "1")
                    if (Convert.ToString(grdAssetTracker.GetRowValues(e.VisibleIndex, "ReviewStatus")) == "Reviewed")
                        e.Enabled = false;
            }

            if (e.ButtonType == ColumnCommandButtonType.Edit)
            {
                if (Convert.ToString(grdAssetTracker.GetRowValues(e.VisibleIndex, "UserAcceptance")) != "1")
                    e.Enabled = true;
                else
                    e.Enabled = false;
            }
        }

        protected void grdAssetTracker_HtmlRowPrepared(object sender, ASPxGridViewTableRowEventArgs e)
        {
            if (e.RowType != GridViewRowType.Data) return;
            string ustat = Convert.ToString(e.GetValue("UserAcceptance"));

            string price = Convert.ToString(e.GetValue("ReviewStatus"));
            if (price == "Not Reviewed")
            {
                e.Row.BackColor = System.Drawing.Color.FromArgb(255, 242, 204);


            }
            else if (ustat == "1")
                e.Row.BackColor = System.Drawing.Color.FromArgb(198, 224, 180);
            else if (ustat == "0")
            {
                e.Row.BackColor = System.Drawing.Color.FromArgb(248, 203, 173);

            }
            else
            {
                e.Row.BackColor = System.Drawing.Color.FromArgb(226, 239, 218);

            }
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("~/Tasks/PrintTemplate.aspx");
        }

        protected void ddlLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        protected void ddlBuilding_SelectedIndexChanged(object sender, EventArgs e)
        {


            ImageButton1.Enabled = true;
        }

        protected void btnloadgrid_Click(object sender, EventArgs e)
        {
            if (int.Parse(Session["filter"].ToString()) == 1)
            {

                int user = 0;
                DateTime? strt = null;
                DateTime? end = null;
                DateTime fdt = dtfrom.Date;
                DateTime edt = dtto.Date;

                if (cmbUser.Value == null)
                {
                    cmbUser.SelectedIndex = 0;
                    user = (int)cmbUser.Value;
                }
                else
                    user = (int)cmbUser.Value;

                if (fdt.Year < DateTime.Now.Year)
                    strt = null;
                else
                    strt = fdt;
                if (fdt.Year < DateTime.Now.Year)
                    end = null;
                else
                    end = edt;
                LoadGridView(null, strt, end, user);
            }
            else
            {
                int? cubicle = null;
                if (cmbarea.Value == null)
                {
                    cubicle = null;
                }

                else
                {
                    cubicle = int.Parse(cmbarea.Value.ToString());
                }
                LoadGridView(cubicle, null, null, null);
            }
        }

        protected void grdAssetTracker_CustomErrorText(object sender, ASPxGridViewCustomErrorTextEventArgs e)
        {
            if (!string.IsNullOrEmpty(_errorMessage))
                e.ErrorText = _errorMessage;
        }

        protected void grdAssetTracker_CustomColumnDisplayText(object sender, ASPxGridViewColumnDisplayTextEventArgs e)
        {
            if (e.Column.FieldName == "UserAcceptance")
            {
                if (e.Value.ToString() == "0")
                    e.DisplayText = "Rejected";
                else if (e.Value.ToString() == "1")
                    e.DisplayText = "Acknowledged";
                else
                    e.DisplayText = "Acknowledgement Pending";

            }
        }

        protected void btnBuilding_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("~/Tasks/buildingData.aspx");

        }

        protected void btnBuildingReport_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("~/Tasks/buildingReportData.aspx");
        }

        protected void cmbbuilding_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            int blockId = Convert.ToInt32(cmbbuilding.SelectedItem.Value);
            var ipareabasedonblock = new List<InputParameters>
            {
                new InputParameters {SqlParam = "BuildingID", ParamValue = blockId.ToString()},
                new InputParameters {SqlParam = "PSID", ParamValue = Session["PSID"].ToString()},
                new InputParameters {SqlParam = "ApplicationID", ParamValue = Convert.ToInt16(ConfigurationManager.AppSettings["ApplicationID"]).ToString()}
            };
            cmbarweea.Columns.Clear();
            cmbarweea.DataSource = QueryHelper.GetAreaBasedOnBlock(ipareabasedonblock);
            cmbarweea.TextField = "FloorNo";
            cmbarweea.ValueField = "BuildingFloorID";
            cmbarweea.DataBind();
            grdAssetTracker.FilterExpression = "[BuildingName]='" + cmbbuilding.SelectedItem.Text + "'";

            cmbarweea.SelectedIndex = -1;
            cmbarea.SelectedIndex = -1;

        }

        protected void cmbarweea_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            int buildingFloorId = Convert.ToInt32(cmbarweea.SelectedItem.Value);
            var ipcubiclebasedonarea = new List<InputParameters>
            {
                new InputParameters {SqlParam = "BuildingFloorID", ParamValue = buildingFloorId.ToString()}
            };



            cmbarea.Columns.Clear();
            cmbarea.DataSource = QueryHelper.GetCubicleBasedOnArea(ipcubiclebasedonarea);


            cmbarea.TextField = "CubicleNo";
            cmbarea.ValueField = "CubicleID";
            cmbarea.DataBind();
            cmbarea.SelectedIndex = -1;
            grdAssetTracker.FilterExpression = "[BuildingName]='" + cmbbuilding.SelectedItem.Text + "' AND [FloorNo]='" + cmbarweea.SelectedItem.Text + "'";

        }

        protected void ImageButton3_OnClick(object sender, ImageClickEventArgs e)
        {
            enablefilter = false;
            Session["filter"] = 0;
            SetState();
            secfil.Attributes.Add("class", "card_display_small_custom_active");
            mainfil.Attributes.Add("class", "card_display_small_custom");
        }

        protected void ImageButton2_OnClick(object sender, ImageClickEventArgs e)
        {
            grdAssetTracker.FilterExpression = "";
            Session["filter"] = 1;
            enablefilter = true;
            SetState();
            secfil.Attributes.Add("class", "card_display_small_custom");
            mainfil.Attributes.Add("class", "card_display_small_custom_active");
        }

        private void SetState()
        {

            if (HttpContext.Current.Session["filter"] == null)
            {
                Session["filter"] = 1;
            }

            else
            {


                if (int.Parse(Session["filter"].ToString()) == 0)
                {
                    cmbbuilding.Enabled = true;
                    cmbarea.Enabled = true;
                    cmbarweea.Enabled = true;
                    dtfrom.Enabled = false;
                    dtto.Enabled = false;
                    cmbUser.Enabled = false;
                }
                else
                {
                    cmbbuilding.Enabled = false;
                    cmbarea.Enabled = false;
                    cmbarweea.Enabled = false;
                    dtfrom.Enabled = true;
                    dtto.Enabled = true;
                    cmbUser.Enabled = true;
                }

            }

        }
    }
}
