﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using AssetManagementLibrary;
using AssetManagementLibrary.OtherHelpers;

namespace AssetManagement.Tasks
{
    public partial class MainForm : AssetTrackerBasePage
    {

        #region Private Variables

        UserEntityClass user = null;
        DateTime scandate;
        DataTable dt;
        #endregion

        int k = 0;
        bool isAvailable = false;
        bool ispresent = false;
        List<toAdd> add = new List<toAdd>();


        protected void Page_Load(object sender, EventArgs e)
        {
            System.Web.UI.WebControls.Button myObject;
            myObject = (System.Web.UI.WebControls.Button)Master.FindControl("DeployItem");
            myObject.Attributes.Add("class", "flatdivonselect");
            myObject = (System.Web.UI.WebControls.Button)Master.FindControl("AssetSearch");
            myObject.Attributes.Add("class", "flatdivonselect");
            myObject = (System.Web.UI.WebControls.Button)Master.FindControl("AssetDailyReview");
            myObject.Attributes.Add("class", "flatdivonselect");


            if (!Page.IsPostBack)
            {
                if (Convert.ToInt32(Session["PendingReview"]) == 0)
                {
                    ddlLocation.DataSource = CacheHelper.GetInstance.GetValue<DataSet>("location", QueryHelper.GetLocations, 0, true, null);
                    ddlLocation.DataTextField = "LocationName";
                    ddlLocation.DataValueField = "LocationID";
                    ddlLocation.DataBind();
                    ddlLocation.Items.Insert(0, new ListItem("--Select Location--", "0"));
                    ddlLocation.SelectedIndex = 1;

                    SetInitialRow();

                    var ipbuildingonlocation = new List<InputParameters>
                    {
                        new InputParameters {SqlParam = "LocationID", ParamValue = "2"},
                        new InputParameters {SqlParam = "PSID", ParamValue = Session["PSID"].ToString()},
                        new InputParameters {SqlParam = "ApplicationID", ParamValue = Convert.ToInt16(ConfigurationManager.AppSettings["ApplicationID"]).ToString()}
                    };

                    ddlBuilding.DataSource = QueryHelper.GetBlockBasedOnLocation(ipbuildingonlocation);
                    ddlBuilding.DataTextField = "BuildingName";
                    ddlBuilding.DataValueField = "BuildingID";
                    ddlBuilding.DataBind();
                    ddlBuilding.Items.Insert(0, new ListItem("--Select Building--", "0"));
                }
                else
                {
                    btnSave.Enabled = false;
                    btnReset.Enabled = false;
                    ddlLocation.Enabled = false;
                    ddlBuilding.Enabled = false;
                    ddlArea.Enabled = false;
                    ddlCubiclebnumber.Enabled = false;
                    ddlCubiclestatus.Enabled = false;
                    txtPsid.Enabled = false;
                    txtName.Enabled = false;
                    chk.Enabled = false;
                    lblMessage.Text = "Your scanned items are pending for review ,Please inform your reviewer to complete the review of all pending items before proceeding with the scan.";
                }
            }
        }
        private void SetInitialRow()
        {

            dt = new DataTable();
            DataRow dr = null;

            dt.Columns.Add(new DataColumn("Column1", typeof(string)));//for TextBox value 
            dt.Columns.Add(new DataColumn("Column2", typeof(string)));//for TextBox value 
            dt.Columns.Add(new DataColumn("Column3", typeof(string)));//for DropDownList selected item 
            dt.Columns.Add(new DataColumn("Column4", typeof(string)));//for DropDownList selected item 
            dt.Columns.Add(new DataColumn("Column5", typeof(string)));//for DropDownList selected item 

            dr = dt.NewRow();

            dr["Column1"] = string.Empty;
            dr["Column2"] = string.Empty;
            dr["Column3"] = string.Empty;
            dt.Rows.Add(dr);

            ViewState["CurrentTable"] = dt;

            //Bind the Gridview 
            Gridview1.DataSource = dt;
            Gridview1.DataBind();


            DropDownList ddl2 = (DropDownList)Gridview1.Rows[0].Cells[2].FindControl("ddlAssettype");
            DropDownList ddl3 = (DropDownList)Gridview1.Rows[0].Cells[3].FindControl("ddlstatus");
            System.Web.UI.WebControls.Button btnadd = Gridview1.FooterRow.FindControl("ButtonAdd") as System.Web.UI.WebControls.Button;


            ddl2.DataSource = QueryHelper.GetAssetType();
            ddl2.DataTextField = "AssetType";
            ddl2.DataValueField = "SysAssetTypeID";
            if (k == 1)
            {
                ddl2.SelectedValue = "44";

            }
            ddl2.DataBind();


            ddl3.DataSource = QueryHelper.GetAssetStatus();
            ddl3.DataTextField = "AssetStatus";
            ddl3.DataValueField = "SysAssetStatusID";
            if (k == 1)
            {

                ddl3.SelectedValue = "10";
            }
            ddl3.DataBind();

            if (k == 1)
            {
                btnadd.Enabled = false;
            }
            else
            {
                btnadd.Enabled = true;
            }
        }



        public bool IsAlphaNumeric(String strToCheck)
        {

            Regex r = new Regex("^(?=.*[a-zA-Z])(?=.*[0-9])");
            if (r.IsMatch(strToCheck))


                return true;
            else
                return false;
        }

        private void AddNewRowToGrid()
        {

            bool isvalid = true;
            if (ViewState["CurrentTable"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                DataRow drCurrentRow = null;

                if (dtCurrentTable.Rows.Count > 0)
                {
                    List<string> contains = new List<string>();
                    List<string> qcontains = new List<string>();
                    List<string> noasset = new List<string>();
                    for (int i = 0; i < dtCurrentTable.Rows.Count; i++)
                    {

                        System.Web.UI.WebControls.TextBox box2 = (System.Web.UI.WebControls.TextBox)Gridview1.Rows[i].Cells[1].FindControl("txtSerialnumber");
                        System.Web.UI.WebControls.TextBox box3 = (System.Web.UI.WebControls.TextBox)Gridview1.Rows[i].Cells[2].FindControl("txtqrcode");
                        DropDownList ddl2 = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlAssettype");

                        var ipserialnumber = new List<InputParameters>
                        {
                            new InputParameters {SqlParam = "SearialNumber", ParamValue = box2.Text},
                        };

                        int dtlog = Convert.ToInt32(QueryHelper.GetSerialNumber(ipserialnumber).Tables[0].Rows[0][0]);
                        if (ddl2.SelectedItem.Text == "No Asset")
                        {

                            if (i != 0)
                            {
                                dtlog = 123456;
                            }
                        }
                        if (ddl2.SelectedItem.Text != "No Asset")
                        {

                            if (dtlog == 0)
                            {
                                if (box2.Text.Length != 0)
                                {
                                    bool isalpha = true;
                                    if (!isalpha)
                                    {
                                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Serial number is not valid');", true);
                                        isvalid = false;
                                        break;
                                    }
                                    else
                                    {


                                    }


                                    if (contains.Contains(box2.Text))
                                    {
                                        contains.Add(box2.Text);
                                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Serial number cannot be repeated');", true);
                                        isvalid = false;
                                        break;
                                    }

                                    else
                                    {
                                        contains.Add(box2.Text);
                                        qcontains.Add(box3.Text);
                                    }


                                }

                                else
                                {
                                    if (dtlog != 123456)
                                    {
                                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Serial number can not be empty');", true);
                                    }
                                    else
                                    {
                                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('A user can have only one non asset ');", true);
                                    }
                                    isvalid = false;
                                    break;
                                }
                            }
                            else
                            {
                                if (dtlog != 123456)
                                {
                                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Serial number :" + box2.Text + " is a potential duplicate ');", true);
                                }
                                else
                                {
                                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('A user can have only one non asset ');", true);

                                }
                                isvalid = false;
                                break;
                            }
                        }

                        else if (ddl2.SelectedItem.Text == "No Asset" && dtlog == 123456)
                        {
                            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('A user can have only one non asset ');", true);
                            isvalid = false;
                            break;
                        }
                    }

                    if (isvalid == true)
                    {
                        drCurrentRow = dtCurrentTable.NewRow();

                        dtCurrentTable.Rows.Add(drCurrentRow);


                        ViewState["CurrentTable"] = dtCurrentTable;


                        for (int i = 0; i < dtCurrentTable.Rows.Count - 1; i++)
                        {
                            System.Web.UI.WebControls.TextBox box1 = (System.Web.UI.WebControls.TextBox)Gridview1.Rows[i].Cells[1].FindControl("txtSerialnumber");
                            System.Web.UI.WebControls.TextBox box2 = (System.Web.UI.WebControls.TextBox)Gridview1.Rows[i].Cells[2].FindControl("txtqrcode");
                            System.Web.UI.WebControls.TextBox box3 = (System.Web.UI.WebControls.TextBox)Gridview1.Rows[i].Cells[3].FindControl("txtFarNumber");

                            dtCurrentTable.Rows[i]["Column1"] = box1.Text;
                            dtCurrentTable.Rows[i]["Column2"] = box2.Text;
                            dtCurrentTable.Rows[i]["Column3"] = box3.Text;

                            DropDownList ddl2 = (DropDownList)Gridview1.Rows[i].Cells[2].FindControl("ddlAssettype");
                            DropDownList ddl3 = (DropDownList)Gridview1.Rows[i].Cells[3].FindControl("ddlstatus");
                            dtCurrentTable.Rows[i]["Column4"] = ddl2.SelectedItem.Text;
                            dtCurrentTable.Rows[i]["Column5"] = ddl3.SelectedItem.Text;
                        }
                        Gridview1.DataSource = dtCurrentTable;
                        Gridview1.DataBind();
                    }
                }
            }
            else
            {
                Response.Write("ViewState is null");

            }

            SetPreviousData();
        }

        private void SetPreviousData()
        {

            int rowIndex = 0;
            if (ViewState["CurrentTable"] != null)
            {

                DataTable dt = (DataTable)ViewState["CurrentTable"];
                if (dt.Rows.Count > 0)
                {

                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        System.Web.UI.WebControls.TextBox box1 = (System.Web.UI.WebControls.TextBox)Gridview1.Rows[i].Cells[1].FindControl("txtSerialnumber");
                        System.Web.UI.WebControls.TextBox box2 = (System.Web.UI.WebControls.TextBox)Gridview1.Rows[i].Cells[2].FindControl("txtqrcode");
                        System.Web.UI.WebControls.TextBox box3 = (System.Web.UI.WebControls.TextBox)Gridview1.Rows[i].Cells[2].FindControl("txtFarNumber");


                        DropDownList ddl2 = (DropDownList)Gridview1.Rows[rowIndex].Cells[2].FindControl("ddlAssettype");
                        DropDownList ddl3 = (DropDownList)Gridview1.Rows[rowIndex].Cells[3].FindControl("ddlstatus");


                        ddl2.DataSource = QueryHelper.GetAssetType();
                        ddl2.DataTextField = "AssetType";
                        ddl2.DataValueField = "SysAssetTypeID";
                        ddl2.DataBind();

                        ddl3.DataSource = QueryHelper.GetAssetStatus();
                        ddl3.DataTextField = "AssetStatus";
                        ddl3.DataValueField = "SysAssetStatusID";
                        ddl3.DataBind();
                        if (IsPostBack)
                        {
                            box1.Text = dt.Rows[i]["Column1"].ToString();
                            box2.Text = dt.Rows[i]["Column2"].ToString();
                            box3.Text = dt.Rows[i]["Column3"].ToString();


                            ddl2.ClearSelection();
                            if (dt.Rows[i]["Column4"].ToString() != "")
                                ddl2.Items.FindByText(dt.Rows[i]["Column4"].ToString()).Selected = true;

                            ddl3.ClearSelection();
                            if (dt.Rows[i]["Column5"].ToString() != "")

                                ddl3.Items.FindByText(dt.Rows[i]["Column5"].ToString()).Selected = true;


                        }

                        rowIndex++;
                    }
                }
            }
        }

        private string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["AvaluetConnectionString"].ConnectionString;
        }



        public class toAdd
        {
            public string serialnum { get; set; }
            public string qrnum { get; set; }
            public string frnum { get; set; }
            public int assettypeID { get; set; }
            public int assetstatID { get; set; }
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            bool isvalid = true;
            bool isoccupied = false;
            bool hasduplicate = false;
            int rowIndex = 0;

            if (chk.Checked == true)
            {
                if (txtName.Text == "" || txtPsid.Text == "")
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "When presence is checked PSID and Name are mandatory" + "');", true);

                }
            }

            if (ddlLocation.SelectedIndex == 0 || ddlBuilding.SelectedIndex == 0 || ddlArea.SelectedIndex == 0 || ddlCubiclebnumber.SelectedIndex == 0)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "All Fields are Required . . ." + "');", true);
            }
            else
            {
                if (chk.Checked == true)
                {


                    int a = 0;
                    DropDownList ddl2 = (DropDownList)Gridview1.Rows[a].Cells[4].FindControl("ddlAssettype");
                    if (ddl2.SelectedItem.Text != "No Asset")
                    {
                        if (txtPsid.Text.Length == 0 || txtName.Text.Length == 0)
                        {
                            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Please enter PSID and Name ');", true);
                            isoccupied = true;
                            a++;
                        }
                    }
                }

                if (isoccupied == false)
                {
                    StringCollection sc = new StringCollection();
                    if (ViewState["CurrentTable"] != null)
                    {
                        DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                        if (dtCurrentTable.Rows.Count > 0)
                        {
                            List<string> code = new System.Collections.Generic.List<string>();
                            List<string> qcode = new System.Collections.Generic.List<string>();

                            for (int i = 0; i < dtCurrentTable.Rows.Count; i++)
                            {
                                System.Web.UI.WebControls.TextBox box2 = (System.Web.UI.WebControls.TextBox)Gridview1.Rows[i].Cells[1].FindControl("txtSerialnumber");
                                System.Web.UI.WebControls.TextBox box3 = (System.Web.UI.WebControls.TextBox)Gridview1.Rows[i].Cells[2].FindControl("txtqrcode");
                                DropDownList ddl2 = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlAssettype");

                                bool isalpha = true;


                                if (ddl2.SelectedItem.Text != "No Asset")
                                {
                                    if (box2.Text.Length != 0)
                                    {

                                        if (!isalpha)
                                        {
                                            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Serial number is not valid');", true);
                                            isvalid = false;
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Serial number can not be empty');", true);
                                        isvalid = false;
                                        break;
                                    }

                                    if (isvalid)
                                    {
                                        string c = box2.Text;

                                        if (i == 0)
                                        {
                                            code.Add(c);
                                            qcode.Add(box3.Text);
                                        }

                                        else if (code.Contains(c))
                                        {

                                            if (c != "")
                                            {
                                                ClientScript.RegisterStartupScript(GetType(), "hwa", "alert('Serial Number must be unique');", true);
                                                hasduplicate = true;
                                            }

                                        }

                                        else if (qcode.Contains(box3.Text))
                                        {
                                            if (box3.Text != "")
                                            {
                                                ClientScript.RegisterStartupScript(GetType(), "hwa", "alert('QR code must be unique');", true);
                                                hasduplicate = true;

                                            }
                                        }
                                    }
                                }

                            }
                            if (hasduplicate == false && isvalid == true)
                            {
                                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                                {

                                    System.Web.UI.WebControls.TextBox box1 = (System.Web.UI.WebControls.TextBox)Gridview1.Rows[rowIndex].Cells[1].FindControl("txtSerialnumber");
                                    System.Web.UI.WebControls.TextBox box2 = (System.Web.UI.WebControls.TextBox)Gridview1.Rows[rowIndex].Cells[2].FindControl("txtqrcode");
                                    System.Web.UI.WebControls.TextBox box3 = (System.Web.UI.WebControls.TextBox)Gridview1.Rows[rowIndex].Cells[2].FindControl("txtFarNumber");
                                    DropDownList ddl2 = (DropDownList)Gridview1.Rows[rowIndex].Cells[4].FindControl("ddlAssettype");
                                    DropDownList ddl3 = (DropDownList)Gridview1.Rows[rowIndex].Cells[5].FindControl("ddlstatus");


                                    add.Add(new toAdd { serialnum = box1.Text.ToString(), qrnum = box2.Text.ToString(), frnum = box3.Text.ToString(), assettypeID = int.Parse(ddl2.SelectedItem.Value.ToString()), assetstatID = int.Parse(ddl3.SelectedItem.Value.ToString()) });

                                    rowIndex++;

                                }

                                InsertRecords();
                                SetInitialRow();

                                txtPsid.Text = string.Empty;
                                txtName.Text = string.Empty;
                                ddlCubiclebnumber.SelectedIndex = -1;
                                ddlCubiclebnumber.SelectedIndex = 0;

                            }

                            else
                            {
                                ClientScript.RegisterStartupScript(GetType(), "hwa", "alert('Records unaffected');", true);


                            }
                        }
                    }
                }

            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtPsid.Text = string.Empty;
            txtName.Text = string.Empty;
            ddlCubiclebnumber.SelectedIndex = -1;
            ddlCubiclebnumber.SelectedIndex = 0;
            SetInitialRow();
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.RemoveAll();
            Session.Abandon();
            Response.Redirect("HomePage.aspx");
        }

        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            AddNewRowToGrid();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            LinkButton lb = (LinkButton)sender;
            GridViewRow gvRow = (GridViewRow)lb.NamingContainer;
            int rowID = gvRow.RowIndex;
            if (ViewState["CurrentTable"] != null)
            {

                DataTable dt = (DataTable)ViewState["CurrentTable"];
                if (dt.Rows.Count > 1)
                {
                    //Remove the Selected Row data and reset row number  
                    dt.Rows.Remove(dt.Rows[rowID]);
                    //ResetRowID(dt);

                }

                //Store the current data in ViewState for future reference  
                ViewState["CurrentTable"] = dt;

                //Re bind the GridView for the updated data  
                Gridview1.DataSource = dt;
                Gridview1.DataBind();
            }

            //Set Previous Data on Postbacks  
            SetPreviousData();
        }

        protected void Gridview1_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataTable dt = (DataTable)ViewState["CurrentTable"];
                LinkButton lb = (LinkButton)e.Row.FindControl("LinkButton1");

            }
        }
        List<ItemEntityClass> obj1 = new List<ItemEntityClass>();
        ItemEntityClass Serialnumber = new ItemEntityClass();
        private void InsertRecords()
        {

            int chkstat = 0;
            if (chk.Checked == true)
                chkstat = 1;
            else
                chkstat = 0;
            bool haserror = false;

            string ScanedBy = Convert.ToString(Session["PSID"].ToString());

            int i = 0;
            foreach (var item in add)
            {

                var ipserialnumber = new List<InputParameters>
                        {
                            new InputParameters {SqlParam = "SearialNumber", ParamValue = item.serialnum},
                        };

                int dtlog = Convert.ToInt32(QueryHelper.GetSerialNumber(ipserialnumber).Tables[0].Rows[0][0]);
                if (item.serialnum == "")
                {
                    if (i == 0)
                    {
                        dtlog = 0;
                        i++;
                    }

                    else
                    {
                        dtlog = 123456;
                    }
                }
                if (dtlog == 0)
                {
                    try
                    {
                        var ipinsertasset = new List<InputParameters>
                            {
                                new InputParameters {SqlParam = "SearialNumber", ParamValue = item.serialnum},
                                new InputParameters {SqlParam = "QRCodeNumber", ParamValue = item.qrnum },
                                new InputParameters {SqlParam = "FARNumber", ParamValue = item.frnum },
                                new InputParameters {SqlParam = "AssetTypeID", ParamValue = item.assettypeID.ToString() },
                                new InputParameters {SqlParam = "AssetStatusID", ParamValue = item.assetstatID.ToString()},
                                new InputParameters {SqlParam = "BuildingID", ParamValue = ddlBuilding.SelectedItem.Value},
                                new InputParameters {SqlParam = "FloorID", ParamValue = ddlArea.SelectedItem.Value},
                                new InputParameters {SqlParam = "LocationID", ParamValue = ddlLocation.SelectedItem.Value},
                                new InputParameters {SqlParam = "CubicleStatus", ParamValue = ddlCubiclestatus.SelectedItem.Value},
                                new InputParameters {SqlParam = "CubicleNumber", ParamValue = ddlCubiclebnumber.SelectedItem.Value },
                                new InputParameters {SqlParam = "PSID", ParamValue = txtPsid.Text},
                                new InputParameters {SqlParam = "Name", ParamValue = txtName.Text},
                                new InputParameters {SqlParam = "Modby", ParamValue = ScanedBy},
                                new InputParameters {SqlParam = "UserPresence", ParamValue = chkstat.ToString()}
                            };

                        bool result = QueryHelper.InsertAsset(ipinsertasset);
                    }

                    catch (Exception ex)
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Records can not be saved at the moment ,contact local admin" + "');", true);
                        haserror = true;
                    }
                }

                else
                {
                    if (dtlog != 123456)
                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "the serial number " + item.serialnum + " exists; the data will be skipped" + "');", true);
                    else
                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "the user already has a non asset under his/her name ; the data will be skipped" + "');", true);

                }

            }

            if (haserror == false)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Records saved succesfully" + "');", true);

            }





        }

        protected void txtPsid_TextChanged(object sender, EventArgs e)
        {
            SetInitialRow();

            try
            {
                string emplid = txtPsid.Text;
                var ipempid = new List<InputParameters>
                 {
                     new InputParameters {SqlParam = "EMPLID", ParamValue = emplid}
                 };

                DataTable dtLoginInfo = QueryHelper.GetUserName(ipempid).Tables[0];
                if (dtLoginInfo.Rows.Count > 0)
                {
                    txtName.Text = dtLoginInfo.Rows[0]["NAME_DISPLAY"].ToString();
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Please enter a valid PSID');", true);

                    txtName.Text = string.Empty;
                }
            }
            catch
            {
                txtName.Text = string.Empty;
            }
        }



        protected void ddlBuilding_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetInitialRow();

            int blockId = Convert.ToInt32(ddlBuilding.SelectedItem.Value);
            var ipareabasedonblock = new List<InputParameters>
            {
                new InputParameters {SqlParam = "BuildingID", ParamValue = blockId.ToString()},
                new InputParameters {SqlParam = "PSID", ParamValue = Session["PSID"].ToString()},
                new InputParameters {SqlParam = "ApplicationID", ParamValue = Convert.ToInt16(ConfigurationManager.AppSettings["ApplicationID"]).ToString()}
            };

            ddlArea.DataSource = QueryHelper.GetAreaBasedOnBlock(ipareabasedonblock);
            ddlArea.DataTextField = "FloorNo";
            ddlArea.DataValueField = "BuildingFloorID";
            ddlArea.DataBind();
            ddlArea.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlCubiclestatus.SelectedIndex = 0;
            txtPsid.Text = string.Empty;
            txtName.Text = string.Empty;
            txtPsid.Enabled = true;
            txtName.Enabled = true;
            chk.Enabled = true;
        }

        protected void ddlLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetInitialRow();

            int locationId = Convert.ToInt32(ddlLocation.SelectedItem.Value);

            var ipbuildingonlocation = new List<InputParameters>
            {
                new InputParameters {SqlParam = "LocationID", ParamValue = locationId.ToString()},
                new InputParameters {SqlParam = "PSID", ParamValue = Session["PSID"].ToString()},
                new InputParameters {SqlParam = "ApplicationID", ParamValue = Convert.ToInt16(ConfigurationManager.AppSettings["ApplicationID"]).ToString()}
            };

            ddlBuilding.DataSource = QueryHelper.GetBlockBasedOnLocation(ipbuildingonlocation);
            ddlBuilding.DataTextField = "BuildingName";
            ddlBuilding.DataValueField = "BuildingID";
            ddlBuilding.DataBind();
            ddlBuilding.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlCubiclestatus.SelectedIndex = 0;
            txtPsid.Text = string.Empty;
            txtName.Text = string.Empty;
            txtPsid.Enabled = true;
            txtName.Enabled = true;
            chk.Enabled = true;
        }

        protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetInitialRow();

            int buildingFloorId = Convert.ToInt32(ddlArea.SelectedValue);
            var ipcubiclebasedonarea = new List<InputParameters>
            {
                new InputParameters {SqlParam = "BuildingFloorID", ParamValue = buildingFloorId.ToString()}
            };

            ddlCubiclebnumber.DataSource = QueryHelper.GetCubicleBasedOnArea(ipcubiclebasedonarea);
            ddlCubiclebnumber.DataTextField = "CubicleNo";
            ddlCubiclebnumber.DataValueField = "CubicleID";
            ddlCubiclebnumber.DataBind();
            ddlCubiclebnumber.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlCubiclestatus.SelectedIndex = 0;
            txtPsid.Text = string.Empty;
            txtName.Text = string.Empty;
            txtPsid.Enabled = true;
            txtName.Enabled = true;
            chk.Enabled = true;
        }

        protected void ddlCubiclebnumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetInitialRow();

            try
            {
                string cubicleId = ddlCubiclebnumber.SelectedValue;
                var ipcubicleid = new List<InputParameters>
                {
                    new InputParameters {SqlParam = "CubicleID", ParamValue = cubicleId}
                };
                DataTable dtLoginInfo = QueryHelper.GetPSID(ipcubicleid).Tables[0];
                if (dtLoginInfo.Rows.Count > 0)
                {
                    txtPsid.Text = dtLoginInfo.Rows[0]["PSID"].ToString();
                    txtName.Text = dtLoginInfo.Rows[0]["Name"].ToString();
                }
                else
                {
                    txtPsid.Text = string.Empty;
                    txtName.Text = string.Empty;
                }
            }
            catch
            {
                txtPsid.Text = string.Empty;
                txtName.Text = string.Empty;
            }

            ddlCubiclestatus.SelectedIndex = 0;
            chk.Checked = false;
            txtPsid.Enabled = true;
            txtName.Enabled = true;
            chk.Enabled = true;
        }

        protected void ddlCubiclestatus_SelectedIndexChanged(object sender, EventArgs e)
        {

            SetInitialRow();
            if (ddlCubiclestatus.SelectedIndex == 1)
            {
                lblPsid.Text = "PSID *";
                lblName.Text = "Name *";
                k = 1;
                txtPsid.Enabled = false;
                txtName.Enabled = false;
                chk.Checked = false;
                chk.Enabled = false;

            }
            else
            {
                lblPsid.Text = "PSID ";
                lblName.Text = "Name ";
                txtPsid.Enabled = true;
                txtName.Enabled = true;
                chk.Enabled = true;


            }
            SetInitialRow();
        }



        protected void chk_CheckedChanged(object sender, EventArgs e)
        {
            if (chk.Checked == true)
                ispresent = true;
            else
                ispresent = false;
        }
    }
}