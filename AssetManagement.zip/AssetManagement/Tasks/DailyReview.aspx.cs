﻿using DevExpress.Export;
using DevExpress.Web;
using DevExpress.XtraPrinting;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;

namespace AssetManagement.Tasks
{
    public partial class DailyReview : AssetTrackerBasePage
    {
        private DataSet _dsscanengineer = null;
        private bool _status = false;

        protected void Page_Load(object sender, EventArgs e)
        {
            System.Web.UI.WebControls.Button myObject;
            myObject = (System.Web.UI.WebControls.Button)Master.FindControl("DeployItem");
            myObject.Attributes.Add("class", "flatdivonselect");
            myObject = (System.Web.UI.WebControls.Button)Master.FindControl("AsseInventory");
            myObject.Attributes.Add("class", "flatdivonselect");
            myObject = (System.Web.UI.WebControls.Button)Master.FindControl("AssetSearch");
            myObject.Attributes.Add("class", "flatdivonselect");

            LoadData();

            if (IsPostBack)
            {
                int user = 0;
                DateTime? strt = null;
                DateTime? end = null;
                DateTime fdt = dtfrom.Date;
                DateTime edt = dtto.Date;

                if (cmbUser.Value == null)
                {
                    cmbUser.SelectedIndex = 0;
                    user = (int)cmbUser.Value;
                }
                else
                    user = (int)cmbUser.Value;

                if (fdt.Year < DateTime.Now.Year)
                    strt = null;
                else
                    strt = fdt;
                if (fdt.Year < DateTime.Now.Year)
                    end = null;
                else
                    end = edt;
                LoadGrid(strt, end, user);
            }

            if (!IsPostBack)
            {
                dtfrom.Date = DateTime.Now.Date;
                dtto.Date = DateTime.Now.Date;
            }

        }


        public void LoadData()
        {
            var ipsacnengineer = new List<InputParameters>();
            ipsacnengineer.Add(new InputParameters { SqlParam = "PSID", ParamValue = Session["PSID"].ToString() });
            ipsacnengineer.Add(new InputParameters { SqlParam = "ApplicationID", ParamValue = System.Configuration.ConfigurationManager.AppSettings["ApplicationID"] });
            ipsacnengineer.Add(new InputParameters { SqlParam = "AssetSearch", ParamValue = "1" });
            _dsscanengineer = QueryHelper.GetScanUser(ipsacnengineer);

            cmbUser.DataSource = _dsscanengineer;
            cmbUser.ValueType = typeof(Int32);
            cmbUser.TextField = "Name";
            cmbUser.ValueField = "ScanUser";
            cmbUser.DataBind();
        }
        private void LoadGrid(DateTime? st, DateTime? et, int uid)
        {
            var ipreviewgrid = new List<InputParameters>
            {
                new InputParameters {SqlParam = "StartDate", ParamValue = st.ToString()},
                new InputParameters {SqlParam = "EndDate", ParamValue = et.ToString()},
                new InputParameters {SqlParam = "ScanUserID", ParamValue = uid.ToString()}
            };

            grdDailyReview.DataSource = QueryHelper.LoadReviewGrid(ipreviewgrid);
            grdDailyReview.DataBind();
        }

        protected void btnloadgrid_Click(object sender, EventArgs e)
        {
            int user = 0;
            DateTime? strt = null;
            DateTime? end = null;
            DateTime fdt = dtfrom.Date;
            DateTime edt = dtto.Date;

            if (cmbUser.Value == null)
            {
                cmbUser.SelectedIndex = 0;
                user = (int)cmbUser.Value;
            }
            else
                user = (int)cmbUser.Value;

            if (fdt.Year < DateTime.Now.Year)
                strt = null;
            else
                strt = fdt;
            if (fdt.Year < DateTime.Now.Year)
                end = null;
            else
                end = edt;
            LoadGrid(strt, end, user);
        }
        private void Reload()
        {
            int user = 0;
            DateTime? strt = null;
            DateTime? end = null;
            DateTime fdt = dtfrom.Date;
            DateTime edt = dtto.Date;

            if (cmbUser.Value == null)
            {
                cmbUser.SelectedIndex = 0;
                user = (int)cmbUser.Value;
            }
            else
                user = (int)cmbUser.Value;

            if (fdt.Year < DateTime.Now.Year)
                strt = null;
            else
                strt = fdt;
            if (fdt.Year < DateTime.Now.Year)
                end = null;
            else
                end = edt;
            LoadGrid(strt, end, user);
        }

        protected void grdDailyReview_CustomCallback(object sender, DevExpress.Web.ASPxGridViewCustomCallbackEventArgs e)
        {
            string revby = Convert.ToString(Session["PSID"].ToString());
            List<object> fieldValues = grdDailyReview.GetSelectedFieldValues(new string[] { "SYSASSETDAILYREVIEWID" });
            if (fieldValues.Count > 0)
            {

                try
                {
                    foreach (object t in fieldValues)
                    {
                        var ipreviewasset = new List<InputParameters>
                        {
                            new InputParameters {SqlParam = "SysAssetDailyReviewID", ParamValue = t.ToString()},
                            new InputParameters {SqlParam = "ReviewedBy", ParamValue = revby},
                            new InputParameters {SqlParam = "ApplicationID", ParamValue = Convert.ToInt16(System.Configuration.ConfigurationManager.AppSettings["ApplicationID"]).ToString()}
                        };
                        _status = QueryHelper.Reviewpageasset(ipreviewasset);
                    }
                    Reload();
                }

                catch (Exception ex)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Records can not be saved at the moment ,contact local admin" + "');", true);

                }
            }
        }

        protected void grdDailyReview_HtmlRowPrepared(object sender, DevExpress.Web.ASPxGridViewTableRowEventArgs e)
        {
            if (e.RowType != GridViewRowType.Data) return;
            string price = Convert.ToString(e.GetValue("ReviewStatus"));
            if (price == "NOT REVIEWED")
                e.Row.BackColor = System.Drawing.Color.FromArgb(255, 242, 204);
            else
                e.Row.BackColor = System.Drawing.Color.FromArgb(226, 239, 218);

        }

        protected void grdDailyReview_CommandButtonInitialize(object sender, ASPxGridViewCommandButtonEventArgs e)
        {
            ASPxGridView grid = (sender as ASPxGridView);
            if (e.ButtonType == ColumnCommandButtonType.SelectCheckbox)
            {

                if (Convert.ToInt64(grdDailyReview.GetRowValues(e.VisibleIndex, "Review_Achieved")) >= Convert.ToInt64(grdDailyReview.GetRowValues(e.VisibleIndex, "Review_Target")))
                {
                    e.Enabled = true;
                }

                if (Convert.ToString(grdDailyReview.GetRowValues(e.VisibleIndex, "ReviewStatus")) == "REVIEWED")
                    e.Enabled = false;

                if (Session["IsAuthorized"] != null && Convert.ToInt32(Session["IsAuthorized"]) != 1)
                {
                    if (Convert.ToString(grdDailyReview.GetRowValues(e.VisibleIndex, "PSID")) == Convert.ToString(Session["PSID"]))
                    {
                        e.Enabled = false;
                        e.Visible = false;
                    }
                }
            }
        }

        protected void btnexcel_Click(object sender, ImageClickEventArgs e)
        {
            grdDailyreviewexport.WriteXlsxToResponse(new XlsxExportOptionsEx() { ExportType = ExportType.WYSIWYG });

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

        }
    }
}