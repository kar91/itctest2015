﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagement
{
    public class Validator : System.Web.UI.Page
    {       
        DataSet ds = new DataSet();
        string connectionString = ConfigurationManager.ConnectionStrings["AvaluetConnectionString"].ConnectionString;
        string isvalid = "";       

        public void GetValidation()
        {

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlDataAdapter sda = new SqlDataAdapter("Exec GS_ValidateUserAccess " + Session["EMPID"].ToString(), connection);
                sda.Fill(ds);
                connection.Close();

            }

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                isvalid = row["IsValidUser"].ToString();
            }
            if (isvalid == "1")
                redirect(true);
            else
                redirect(false);


        }


        public void redirect(bool condition)
        {

            if (condition == true)
            {
                if (int.Parse(Session["IsAuthorized"].ToString()) >= 0)
                {

                }
                else
                {
                    Response.Redirect("~/Tasks/Default.aspx");
                }
            }
            else
            {
                Response.Redirect("~/Tasks/Default.aspx");
            }


        }
   
    }
}