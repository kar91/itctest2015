﻿/// <reference path="../scripts/jquery.d.ts" />

//objects which are avaiable in other JS files 
declare var txtHpsmnumber: any;
declare var cmbAreafrom: any;
declare var cmbarea: any;
declare var cmbbuilding: any;
declare var cmbengineer: any;
declare var cmbfloor: any;
declare var cmbcubicle: any;
declare var spnPsid: any;
declare var cmblocfrom: any;
declare var cmbtype: any;
declare var grdAssetList: any;
declare var ASPxClientEdit: any;


//Declaration for the purpose statergy
interface IPurposeStatergy {
    Disable(): void;

    Validate(): boolean;

    Submit(): void;

}

//Declaration for the string object
interface String {
    format(...replacements: string[]): string;
}


// Extension method for string object 
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined'
                ? args[number]
                : match
                ;
        });
    };
}

//Concrete implementation of IpurposeStatergy
class Purpose implements IPurposeStatergy {

    arry = new Array<[any, string]>([txtHpsmnumber, 'Hpsmerror'], [cmbAreafrom, 'areaerror'],
        [cmbarea, 'toareaerror'], [cmbbuilding, 'tobuildingerror'], [cmbengineer, 'engineererror'], [cmbfloor, 'tofloorerror'], [cmbcubicle, 'tocubicle'], [spnPsid, 'txtcallback_toPSIDerror']);

    public Validate(): boolean {
        let haserror: boolean = false;

        var contentplaceholder = "#ctl00_ContentPlaceHolder1_pcLogin_Panel1_";

        this.arry.forEach(function (item) {
            if (item[0].GetText() == '') {
                $(contentplaceholder + item[1]).show();
                haserror = true;
                return true;
            }

            $(contentplaceholder + item[1]).hide();
        });

        return haserror;
    }

    ///Submits the request to the server
    public Submit() {

        let str: string = '{0}/{1}/{2}/{3}/{4}/{5}/{6}/{7}/{8}/{9}/{10}/{11}/{12}/{13}/isforadding';
        let CheckNull = this.IfNullRtnEmpty;
        str = str.format(CheckNull(cmbAreafrom.GetText()), CheckNull(cmbarea.GetValue()),
            CheckNull(cmbarea.GetText()), CheckNull(cmbbuilding.GetValue()), CheckNull(cmbbuilding.GetText()), CheckNull(cmbfloor.GetValue()), CheckNull(cmbfloor.GetText()), CheckNull(cmbcubicle.GetValue()), CheckNull(cmbcubicle.GetText()),
            CheckNull(cmbengineer.GetValue()), CheckNull(cmblocfrom.GetText()), CheckNull(txtHpsmnumber.GetText()), CheckNull(spnPsid.GetText()), CheckNull(cmbtype.GetValue()), '/isforadding');
        grdAssetList.PerformCallback(str);

    }

    public Disable(): void {

    }

    //Gets index of 2 dimention array
    public GetIndexOf2Dimention(num: number, param: string[]): number[] {

        let nums = new Array<number>();
        let arry = this.arry;
        param.forEach(function (value) {

            let result = arry.map(function (element) { return element[num]; }).indexOf(value);
            if (result != -1)
                nums.push(result);
        });

        return nums;
    }

    //Returns empty if the value is null
    public IfNullRtnEmpty(value): any {
        return (value == null ? '' : value);
    }
}


//Concrete implementation of Stage to building of IpurposeStatergy
class STAGE2BLD extends Purpose implements IPurposeStatergy {

    public Disable(): void {

        //
    }

    public Validate(): boolean {

        let nums = super.GetIndexOf2Dimention(1, ['engineererror']);
        let arry = this.arry;
        nums.forEach(function (value) {
            arry.splice(value, 1);
        });

        return super.Validate();
    }

    public Submit(): void {

        super.Submit();
    }

}

//Concrete implementation of buidling to building of IpurposeStatergy
class BLD2BLD extends Purpose implements IPurposeStatergy {

    public Disable(): void {
    }

    public Validate(): boolean {
        let nums = super.GetIndexOf2Dimention(1, ['engineererror']);
        let arry = this.arry;

        nums.forEach(function (value) {
            arry.splice(value, 1); //Removes element from array
        });

        return super.Validate();
    }

    public Submit(): void {

        super.Submit();

        grdAssetList.PerformCallback('clear');
        grdAssetList.UnselectRows()

    
        ASPxClientEdit.ClearEditorsInContainerById('contentDiv');
        grdAssetList.UnselectRows()
    }

}


/// Factory to get the right IPurposeStatergy 
class Factory {

    ///Gets the IpurposeStatergy based on the purposeid
    public GetObject(purposeId: string) {
        switch (purposeId) {
            case "5": return new STAGE2BLD();
            case "6": return new BLD2BLD();
            default: return new Purpose();
        }
    }
}
