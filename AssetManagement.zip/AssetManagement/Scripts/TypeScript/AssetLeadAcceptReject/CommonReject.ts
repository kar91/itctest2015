﻿declare var _customcomboboxdisable: any[];
declare var _customcomboboxvisible: any[];
declare var _cmbenable: any;
declare var _commentlist: any[];
declare var _contentlist: any[];
declare var _commentsplit: any[];
var cmbengineer: any;
var cmbassetstat: any;
var grdrject: any;

//base interface, exposes Disable(), Visible(), Validate() methods
interface IRejectStrategy {

    Disable(cmb: Array<any>): void;

    Visible(cmb: any[]): void;

    Validate(purpose: number, assetType: string, comboxs: any[], isEndUserAck: boolean);
}

//base class, implements IRejectStrategy methods, extra methods exposed - Template(), SubmitComments()
class Reject implements IRejectStrategy {
va
    //disable psased array of combobox
    public Disable(combobox: Array<any>): void {
        $.each(combobox, function (index, value) {
            value.SetEnabled(false)
        });
    }

    //hide psased array of combobox
    public Visible(combobox: any[]): void {
        $.each(combobox, function (index, value) {
            value.SetVisible(false)
        });
    }

    //create comments popup template and fill with comments and contents passed
    public Template(comments: string, contents: string): void {
        $("#parentbody").empty();
        let str: string = '<tr><td  style="vertical-align: top;width:1%;"><div style="width: 50px; height: 50px; border-radius: 50%; background-color: #009688; text-align: center;padding-top: 0.8em;">\
                           <span style="margin-top: 0.4em;color:white;text-shadow: 0.1em 0.1em 0.2em black">{0}</span></div></td><td><div class="talk-bubble tri-right left-top"><div class="talktext">  \
                           <table style="width:100%"> <tr><td><div class="talktext"><p>{1}</p></div></td> </tr><tr><td style="float: right"><p style="margin: 0px; font-size: 0.9em; color: #bbdefb">{2}</p>\
                           </td></tr></table> </div></div></td></tr> ';

        _commentsplit = [];

        _contentlist = contents.split("|");
        document.getElementById("hpsmno").innerHTML = _contentlist[0];
        document.getElementById("serial").innerHTML = 'Serial No: ' + _contentlist[1];
        document.getElementById("type").innerHTML = 'Asset Type: ' + _contentlist[2];

        if (comments != "null") {
            _commentlist = comments.split("|");
            
            //push new comments to array
            $.each(_commentlist, function (key, value) {
                if (value !== "") {
                    _commentsplit.push(value.split(":"));
                }
            });

            //inject comments from _commentsplit array into template
            $.each(_commentsplit, function (key, value) {
                if (value !== "") {
                    $("#parentbody").append(str.format(value[1], value[2], value[0]))
                }
            });
        }

    }

    //pass grid clientInstanceName, comments, engineer to be assigned, asset status
    public SubmitComments(grid: any, performcallbackparams: string, comments: string, engineer?: string, status?: string): void {

        var helper = new SubmitHelper();
        var cansubmit = helper.Cansubmit(comments);

        if (cansubmit === true) {
            grid.PerformCallback(performcallbackparams + '|' + comments + '|' + engineer + '|' + status);
        }
    }

    //
    public Validate(purpose: number, assetType: string, comboxs: any[], isEndUserAck: boolean) {
        if (isEndUserAck) {
            this.Disable(comboxs);
        }
    }
}

//Helper class, cross check comments, engineer and asset status selection
class SubmitHelper {

    public Cansubmit(comments: string): boolean {
        var haserror = false;
        var x = document.getElementById("snackbar")
        if (comments == "") {
            x.innerHTML = 'Please enter suitable comments for the reject';
            haserror = true;
        }
        else {
            haserror = false;
        }
        if (cmbengineer !== undefined) {
            if (cmbengineer.GetEnabled() === true) {
                if (cmbengineer.GetValue() === null) {
                    x.innerHTML = 'Please select an engineer';
                    haserror = true;
                }
            }
        }
        else {
            haserror = false;
        }
        if (cmbassetstat !== undefined) {
            if (cmbassetstat.GetEnabled() === true) {

                if (cmbassetstat.GetValue() === null) {
                    x.innerHTML = 'Please select a purpose for reject';

                    haserror = true;
                }
            }
        }
        else {
            haserror = false;
        }

        if (haserror === false) {
            return true;
        }
        else {
            x.className = "show";
            setTimeout(function () { x.className = x.className.replace("show", ""); }, 10000);
            return false;
        }
    }
}

//for AssetLeadReject page, extra condition for Handover flow, when asset type desktops
class AssetLeadReject extends Reject implements IRejectStrategy {

    public Validate(purpose: number, assetType: string, comboxs: Array<any>[], isEndUserAck: boolean) {
        if (purpose == 11 && assetType.toLowerCase() == 'desktops') {
            super.Disable(comboxs);
        }
        else
            super.Validate(purpose, assetType, comboxs, isEndUserAck);
    }
}

//
class DefaultReject extends Reject implements IRejectStrategy {
    public Disable(combobox: Array<any>): void {
        super.Disable(_customcomboboxdisable);
    }

    public Visible(combobox: Array<any>): void {
        super.Visible(_customcomboboxvisible);
    }
}

//CommonReject flow for Configuration, BuildingEngineer, Receive page
class CommonReject extends Reject implements IRejectStrategy {

    //disable engineer and asset status dropdown
    public Disable(combobox: Array<any>): void {
        super.Disable(combobox);
    }

    //hide engineer and asset status dropdown
    public Visible(combobox: Array<any>): void {
        super.Visible(combobox);
    }

    //override SubmitComments method, engineer and asset status not required
    public SubmitComments(grid: any, performcallbackparams: string, comments: string, tempStatus: string): void {
        grid.PerformCallback(performcallbackparams + '|' + comments + '|' + tempStatus);
    }
}


class RejectFactory {
    public GetReject(type: string) {
        switch (type) {
            case "AssetLeadeRejectAccept":
                return new AssetLeadReject();
            case "Tier1leadReject":
                return new DefaultReject();
            case "BuildingEnggreject":
                return new DefaultReject();
            case "CommonReject":
                return new CommonReject();
            default: return new Reject();
        }
    }

}