var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var cmbengineer;
var cmbassetstat;
var grdrject;
//base class, implements IRejectStrategy methods, extra methods exposed - Template(), SubmitComments()
var Reject = (function () {
    function Reject() {
    }
    //disable psased array of combobox
    Reject.prototype.Disable = function (combobox) {
        $.each(combobox, function (index, value) {
            value.SetEnabled(false);
        });
    };
    //hide psased array of combobox
    Reject.prototype.Visible = function (combobox) {
        $.each(combobox, function (index, value) {
            value.SetVisible(false);
        });
    };
    //create comments popup template and fill with comments and contents passed
    Reject.prototype.Template = function (comments, contents) {
        $("#parentbody").empty();
        var str = '<tr><td  style="vertical-align: top;width:1%;"><div style="width: 50px; height: 50px; border-radius: 50%; background-color: #009688; text-align: center;padding-top: 0.8em;">\
                           <span style="margin-top: 0.4em;color:white;text-shadow: 0.1em 0.1em 0.2em black">{0}</span></div></td><td><div class="talk-bubble tri-right left-top"><div class="talktext">  \
                           <table style="width:100%"> <tr><td><div class="talktext"><p>{1}</p></div></td> </tr><tr><td style="float: right"><p style="margin: 0px; font-size: 0.9em; color: #bbdefb">{2}</p>\
                           </td></tr></table> </div></div></td></tr> ';
        _commentsplit = [];
        _contentlist = contents.split("|");
        document.getElementById("hpsmno").innerHTML = _contentlist[0];
        document.getElementById("serial").innerHTML = 'Serial No: ' + _contentlist[1];
        document.getElementById("type").innerHTML = 'Asset Type: ' + _contentlist[2];
        if (comments != "null") {
            _commentlist = comments.split("|");
            //push new comments to array
            $.each(_commentlist, function (key, value) {
                if (value !== "") {
                    _commentsplit.push(value.split(":"));
                }
            });
            //inject comments from _commentsplit array into template
            $.each(_commentsplit, function (key, value) {
                if (value !== "") {
                    $("#parentbody").append(str.format(value[1], value[2], value[0]));
                }
            });
        }
    };
    //pass grid clientInstanceName, comments, engineer to be assigned, asset status
    Reject.prototype.SubmitComments = function (grid, performcallbackparams, comments, engineer, status) {
        var helper = new SubmitHelper();
        var cansubmit = helper.Cansubmit(comments);
        if (cansubmit === true) {
            grid.PerformCallback(performcallbackparams + '|' + comments + '|' + engineer + '|' + status);
        }
    };
    //
    Reject.prototype.Validate = function (purpose, assetType, comboxs, isEndUserAck) {
        if (isEndUserAck) {
            this.Disable(comboxs);
        }
    };
    return Reject;
}());
//Helper class, cross check comments, engineer and asset status selection
var SubmitHelper = (function () {
    function SubmitHelper() {
    }
    SubmitHelper.prototype.Cansubmit = function (comments) {
        var haserror = false;
        var x = document.getElementById("snackbar");
        if (comments == "") {
            x.innerHTML = 'Please enter suitable comments for the reject';
            haserror = true;
        }
        else {
            haserror = false;
        }
        if (cmbengineer !== undefined) {
            if (cmbengineer.GetEnabled() === true) {
                if (cmbengineer.GetValue() === null) {
                    x.innerHTML = 'Please select an engineer';
                    haserror = true;
                }
            }
        }
        else {
            haserror = false;
        }
        if (cmbassetstat !== undefined) {
            if (cmbassetstat.GetEnabled() === true) {
                if (cmbassetstat.GetValue() === null) {
                    x.innerHTML = 'Please select a purpose for reject';
                    haserror = true;
                }
            }
        }
        else {
            haserror = false;
        }
        if (haserror === false) {
            return true;
        }
        else {
            x.className = "show";
            setTimeout(function () { x.className = x.className.replace("show", ""); }, 10000);
            return false;
        }
    };
    return SubmitHelper;
}());
//for AssetLeadReject page, extra condition for Handover flow, when asset type desktops
var AssetLeadReject = (function (_super) {
    __extends(AssetLeadReject, _super);
    function AssetLeadReject() {
        _super.apply(this, arguments);
    }
    AssetLeadReject.prototype.Validate = function (purpose, assetType, comboxs, isEndUserAck) {
        if (purpose == 11 && assetType.toLowerCase() == 'desktops') {
            _super.prototype.Disable.call(this, comboxs);
        }
        else
            _super.prototype.Validate.call(this, purpose, assetType, comboxs, isEndUserAck);
    };
    return AssetLeadReject;
}(Reject));
//
var DefaultReject = (function (_super) {
    __extends(DefaultReject, _super);
    function DefaultReject() {
        _super.apply(this, arguments);
    }
    DefaultReject.prototype.Disable = function (combobox) {
        _super.prototype.Disable.call(this, _customcomboboxdisable);
    };
    DefaultReject.prototype.Visible = function (combobox) {
        _super.prototype.Visible.call(this, _customcomboboxvisible);
    };
    return DefaultReject;
}(Reject));
//CommonReject flow for Configuration, BuildingEngineer, Receive page
var CommonReject = (function (_super) {
    __extends(CommonReject, _super);
    function CommonReject() {
        _super.apply(this, arguments);
    }
    //disable engineer and asset status dropdown
    CommonReject.prototype.Disable = function (combobox) {
        _super.prototype.Disable.call(this, combobox);
    };
    //hide engineer and asset status dropdown
    CommonReject.prototype.Visible = function (combobox) {
        _super.prototype.Visible.call(this, combobox);
    };
    //override SubmitComments method, engineer and asset status not required
    CommonReject.prototype.SubmitComments = function (grid, performcallbackparams, comments, tempStatus) {
        grid.PerformCallback(performcallbackparams + '|' + comments + '|' + tempStatus);
    };
    return CommonReject;
}(Reject));
var RejectFactory = (function () {
    function RejectFactory() {
    }
    RejectFactory.prototype.GetReject = function (type) {
        switch (type) {
            case "AssetLeadeRejectAccept":
                return new AssetLeadReject();
            case "Tier1leadReject":
                return new DefaultReject();
            case "BuildingEnggreject":
                return new DefaultReject();
            case "CommonReject":
                return new CommonReject();
            default: return new Reject();
        }
    };
    return RejectFactory;
}());
//# sourceMappingURL=CommonReject.js.map