﻿
/// <reference path="../jquery.d.ts" />
/// <reference path="../Helper/Helper.ts" />

//objects which are avaiable in other JS files 
declare var txtHpsmnumber: any;
declare var cmbAreafrom: any;
declare var cmbarea: any;
declare var cmbbuilding: any;
declare var cmbengineer: any;
declare var cmbfloor: any;
declare var cmbcubicle: any;
declare var spnPsid: any;
declare var cmblocfrom: any;
declare var cmbtype: any;
declare var grdAssetList: any;
declare var ASPxClientEdit: any;
declare var cmbFromEngineer: any;
declare var cmbToEngineer: any;
declare var cmbenduserdetails: any;
declare var cmbendusercubicle: any;
declare var cmbfromfloor: any;
declare var cmbAssetType: any;
declare var IsReplacement: any;//not using
declare var ReplacementDate: any;
declare var loadtype: any;
declare var PopUpAssets: any;
declare var ConfigureRequired: any;
declare var cmbHandoverReason: any;
declare var cmbReplacement: any;
declare var cmbassetreplacement: any;
declare var chkDirect: any;//17/04/2017
declare var chkEditEndUser: any;//24/04/2017
declare var cmbReason: any;//24/04/2017

//Declaration for the purpose statergy
interface IPurposeStatergy {
    Disable(): void;

    Submit(): void;

    PerformCallBack(): void;

    Validatedisabledfields(): boolean;
}



//Concrete implementation of IpurposeStatergy
class Purpose implements IPurposeStatergy {

    arry = new Array<any>(txtHpsmnumber, cmbAreafrom, cmbarea, cmbbuilding, cmbengineer, cmbfloor, cmbcubicle, spnPsid, cmbFromEngineer, cmbToEngineer, cmbenduserdetails, cmbendusercubicle);

    helper = new Helper();




    public Validatedisabledfields(): boolean {
        let haserror: boolean = false;
        var helper = this.helper;

        //if (chkDirect.GetValue()) {
        //    cmbcubicle.SetEnabled(false);
        //}

        $.each(this.arry, function (index, value) {
            let element = '#' + value.name + '_error';

            var enduseridchk = false;

            if (value.GetEnabled()) {

                if (value.GetText() == '') {
                    $(element).show();
                    haserror = true;
                    return true;
                }
                else if (cmbenduserdetails.GetValue() == null || cmbendusercubicle.GetValue() == null) {
                    enduseridchk = true;
                }
                else if (enduseridchk) {
                    let element = '#' + cmbenduserdetails.name + '_error';
                    $(element).show();
                    let cubicleElement = '#' + cmbendusercubicle.name + '_error';
                    $(cubicleElement).show();
                    haserror = true;
                    return true;
                }
            }
            $(element).hide();
        });


        if ((cmbReplacement.GetValue() > 0) && (ReplacementDate.GetValue() == null)){// || helper.ConvertToDate(ReplacementDate.GetValue()) <= helper.ConvertToDate(new Date()))) {
            let element = '#' + ReplacementDate.name + '_error';
            $(element).show();
            haserror = true;

            if ((cmbReplacement.GetValue() == 1) && (cmbassetreplacement.GetValue() == null && cmbassetreplacement.GetEnabled())) {
                let element = '#' + cmbassetreplacement.name + '_error';
                $(element).show();
                haserror = true;
                return true;
            }
            else {
                let astelement = '#' + cmbassetreplacement.name + '_error';
                $(astelement).hide();
            }

            return true;
        }


        let repElement = '#' + ReplacementDate.name + '_error';
        $(repElement).hide();

        if ((cmbReplacement.GetValue() == 1) && (cmbassetreplacement.GetValue() == null && cmbassetreplacement.GetEnabled())) {
            let element = '#' + cmbassetreplacement.name + '_error';
            $(element).show();
            haserror = true;
            return true;
        }


        if (cmbHandoverReason.GetValue() == null && cmbHandoverReason.GetEnabled() == true) {
            let element = '#' + cmbHandoverReason.name + '_error';
            $(element).show();
            haserror = true;
            return true;
        }


        let astelement = '#' + cmbassetreplacement.name + '_error';
        $(astelement).hide();

        //edit user
        let reselement = '#' + cmbReason.name + '_error';
        if (chkEditEndUser.GetEnabled() == true && chkEditEndUser.GetValue() && (cmbReason.GetValue() == 0 || cmbReason.GetValue() == null)) {

            $(reselement).show();
            haserror = true;
            return true;
        }
        else
            $(reselement).hide();


        let cubelement = '#' + cmbendusercubicle.name + '_error';
        if (cmbenduserdetails.GetValue() != null && cmbendusercubicle.GetValue() == null) {

            $(cubelement).show();
            haserror = true;
            return true;
        }
        else
            $(cubelement).hide();

        return haserror;
    }


    ///Submits the request to the server
    public Submit() {

        let str: string = '{0}/{1}/{2}/{3}/{4}/{5}/{6}/{7}/{8}/{9}/{10}/{11}/{12}/{13}/{14}/{15}/{16}/{17}/{18}/{19}/{20}/{21}/{22}/{23}/{24}/{25}/isforadding';
        let CheckNull = this.helper.IfNullRtnEmpty;
        str = str.format(CheckNull(cmbAreafrom.GetText()), CheckNull(cmbarea.GetValue()),
            CheckNull(cmbarea.GetText()), CheckNull(cmbbuilding.GetValue()), CheckNull(cmbbuilding.GetText()), CheckNull(cmbfloor.GetValue()), CheckNull(cmbfloor.GetText()), CheckNull(cmbcubicle.GetValue()), CheckNull(cmbcubicle.GetText()),
            CheckNull(cmbengineer.GetValue()), CheckNull(cmblocfrom.GetText()), CheckNull(txtHpsmnumber.GetText()), CheckNull(spnPsid.GetText()), CheckNull(cmbtype.GetValue()), CheckNull(cmbToEngineer.GetValue()), CheckNull(cmbFromEngineer.GetValue()), CheckNull(cmbenduserdetails.GetValue()), CheckNull(cmbendusercubicle.GetValue()), (cmbReplacement.GetValue() == 1 ? "Replacement" : (cmbReplacement.GetValue() == 2 ? "Temprory" : "null")), this.helper.ConvertToDate(ReplacementDate.GetValue()), ConfigureRequired.GetValue(), CheckNull(cmbenduserdetails.GetText()), CheckNull(cmbHandoverReason.GetValue()), CheckNull(cmbassetreplacement.GetText()), chkDirect.GetValue(), chkEditEndUser.GetValue() ? cmbReason.GetText() : null + '/isforadding'); grdAssetList.PerformCallback(str);

    }

    public Disable(): void {
        grdAssetList.UnselectAllRowsOnPage();
        this.EnableCombobox();
    }


    public PerformCallBack(): void {
        this.CallBackCommon();

        loadtype = "default";
        cmblocfrom.PerformCallback(cmbtype.GetValue() + '|default');
        cmbarea.PerformCallback(cmbtype.GetValue() + '|default');
        cmbAssetType.PerformCallback();
        cmbengineer.PerformCallback();

        PopUpAssets.Show();

        cmbtype.GetText()
    }

    //common callback for all process flows
    public CallBackCommon() {
        this.Reset();
        ConfigureRequired.SetValue(true);
        ConfigureRequired.SetEnabled(false);
        cmbFromEngineer.PerformCallback();
        cmbToEngineer.PerformCallback();
        cmbenduserdetails.PerformCallback();
        cmbendusercubicle.PerformCallback();
    }

    public Reset() {
        cmbFromEngineer.SetValue(null);
        cmbToEngineer.SetValue(null);
        cmbenduserdetails.SetValue(null);
        cmbendusercubicle.SetValue(null);
        cmbAreafrom.SetValue(null);
        cmbfromfloor.SetValue(null);
        cmbarea.SetValue(null);
        cmbcubicle.SetValue(null);
        spnPsid.SetValue(null);
        cmblocfrom.SetValue(null);
        txtHpsmnumber.SetValue(null);
        cmbbuilding.SetValue(null);
        cmbfloor.SetValue(null);
        chkDirect.SetValue(false);

    }

    public EnableCombobox() {
        cmbFromEngineer.SetEnabled(true);
        cmbToEngineer.SetEnabled(true);
        cmbengineer.SetEnabled(true);
        cmbendusercubicle.SetEnabled(true);
        cmbAreafrom.SetEnabled(true)
        cmbfromfloor.SetEnabled(true)
        cmblocfrom.SetEnabled(true)
        cmbengineer.SetEnabled(true);
    }

}


//Concrete implementation of Stage to building of IpurposeStatergy
class STAGE2BLD extends Purpose implements IPurposeStatergy {

    public Disable(): void {
        super.Disable();
        cmbengineer.SetEnabled(false);
        cmbFromEngineer.SetEnabled(false);
        cmbToEngineer.SetEnabled(false);
        spnPsid.SetEnabled(false);
    }

    public Validatedisabledfields(): boolean {
        return super.Validatedisabledfields();
    }

    public Submit(): void {
        super.Submit();
    }

    public PrformCallBack(): void {
        super.PerformCallBack();
    }

}

//Concrete implementation of buidling to building of IpurposeStatergy
class BLD2BLD extends Purpose implements IPurposeStatergy {

    public Disable(): void {
        super.Disable();
        //if (chkDirect.GetValue())
        //    cmbcubicle.SetEnabled(false);
        //else
        cmbcubicle.SetEnabled(true);
        cmbenduserdetails.SetEnabled(false);
        cmbendusercubicle.SetEnabled(false);
        cmbarea.SetEnabled(false);
        cmbfloor.SetEnabled(false);
        cmbbuilding.SetEnabled(false);
        spnPsid.SetEnabled(false);
    }

    public Validatedisabledfields(): boolean {
        return super.Validatedisabledfields();
    }

    public Submit(): void {
        super.Submit();
        grdAssetList.PerformCallback('clear');
        ASPxClientEdit.ClearEditorsInContainerById('contentDiv');
        grdAssetList.UnselectRows()
    }


    //disabled function, not being called
    public PrformCallBack(): void {
        super.CallBackCommon();
        ConfigureRequired.SetEnabled(true);
        grdAssetList.PerformCallback('clear');
        cmblocfrom.PerformCallback();
        PopUpAssets.Show();
    }

}

class HandOver extends Purpose implements IPurposeStatergy {
    public Disable(): void {
        super.Disable();
        cmbengineer.SetEnabled(false);
        cmbFromEngineer.SetEnabled(false);
        cmbToEngineer.SetEnabled(false);
        cmbcubicle.SetEnabled(false);
        cmbarea.SetEnabled(false);
        cmbfloor.SetEnabled(false);
        cmbbuilding.SetEnabled(false);
        spnPsid.SetEnabled(false);
    }

    public Validatedisabledfields(): boolean {
        return super.Validatedisabledfields();
    }

    public Submit(): void {
        super.Submit();
        grdAssetList.PerformCallback('clear');
        ASPxClientEdit.ClearEditorsInContainerById('contentDiv');
        grdAssetList.UnselectRows()
    }

    public PrformCallBack(): void {
        super.CallBackCommon();
        grdAssetList.PerformCallback('clear');
        cmblocfrom.PerformCallback();
        PopUpAssets.Show();
    }
}

class ReDeployment extends Purpose implements IPurposeStatergy {
    public Disable(): void {
        super.Disable();
        cmbcubicle.SetEnabled(false);
        cmbarea.SetEnabled(false);
        cmbfloor.SetEnabled(false);
        cmbbuilding.SetEnabled(false);
        spnPsid.SetEnabled(false);
    }

    public Validatedisabledfields(): boolean {
        return super.Validatedisabledfields();
    }

    public Submit(): void {
        super.Submit();
        grdAssetList.PerformCallback('clear');
        ASPxClientEdit.ClearEditorsInContainerById('contentDiv');
        grdAssetList.UnselectRows()
    }

    public PrformCallBack(): void {
        super.CallBackCommon();
        grdAssetList.PerformCallback('clear');
        cmblocfrom.PerformCallback();
        PopUpAssets.Show();
    }
}


/// Factory to get the right IPurposeStatergy 
class Factory {

    ///Gets the IpurposeStatergy based on the purposeid
    public GetObject(purposeId: string) {
        switch (purposeId) {
            case "5": return new STAGE2BLD();
            case "6": return new BLD2BLD();
            case "10": return new HandOver();
            case "11": return new ReDeployment();
            case "12": return new BLD2BLD();
            default: return new Purpose();
        }
    }
}
