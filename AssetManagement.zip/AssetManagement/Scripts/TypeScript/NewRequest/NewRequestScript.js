/// <reference path="../jquery.d.ts" />
/// <reference path="../Helper/Helper.ts" />
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
//Concrete implementation of IpurposeStatergy
var Purpose = (function () {
    function Purpose() {
        this.arry = new Array(txtHpsmnumber, cmbAreafrom, cmbarea, cmbbuilding, cmbengineer, cmbfloor, cmbcubicle, spnPsid, cmbFromEngineer, cmbToEngineer, cmbenduserdetails, cmbendusercubicle);
        this.helper = new Helper();
    }
    Purpose.prototype.Validatedisabledfields = function () {
        var haserror = false;
        var helper = this.helper;
        //if (chkDirect.GetValue()) {
        //    cmbcubicle.SetEnabled(false);
        //}
        $.each(this.arry, function (index, value) {
            var element = '#' + value.name + '_error';
            var enduseridchk = false;
            if (value.GetEnabled()) {
                if (value.GetText() == '') {
                    $(element).show();
                    haserror = true;
                    return true;
                }
                else if (cmbenduserdetails.GetValue() == null || cmbendusercubicle.GetValue() == null) {
                    enduseridchk = true;
                }
                else if (enduseridchk) {
                    var element_1 = '#' + cmbenduserdetails.name + '_error';
                    $(element_1).show();
                    var cubicleElement = '#' + cmbendusercubicle.name + '_error';
                    $(cubicleElement).show();
                    haserror = true;
                    return true;
                }
            }
            $(element).hide();
        });
        if ((cmbReplacement.GetValue() > 0) && (ReplacementDate.GetValue() == null)) {
            var element = '#' + ReplacementDate.name + '_error';
            $(element).show();
            haserror = true;
            if ((cmbReplacement.GetValue() == 1) && (cmbassetreplacement.GetValue() == null && cmbassetreplacement.GetEnabled())) {
                var element_2 = '#' + cmbassetreplacement.name + '_error';
                $(element_2).show();
                haserror = true;
                return true;
            }
            else {
                var astelement_1 = '#' + cmbassetreplacement.name + '_error';
                $(astelement_1).hide();
            }
            return true;
        }
        var repElement = '#' + ReplacementDate.name + '_error';
        $(repElement).hide();
        if ((cmbReplacement.GetValue() == 1) && (cmbassetreplacement.GetValue() == null && cmbassetreplacement.GetEnabled())) {
            var element = '#' + cmbassetreplacement.name + '_error';
            $(element).show();
            haserror = true;
            return true;
        }
        if (cmbHandoverReason.GetValue() == null && cmbHandoverReason.GetEnabled() == true) {
            var element = '#' + cmbHandoverReason.name + '_error';
            $(element).show();
            haserror = true;
            return true;
        }
        var astelement = '#' + cmbassetreplacement.name + '_error';
        $(astelement).hide();
        //edit user
        var reselement = '#' + cmbReason.name + '_error';
        if (chkEditEndUser.GetEnabled() == true && chkEditEndUser.GetValue() && (cmbReason.GetValue() == 0 || cmbReason.GetValue() == null)) {
            $(reselement).show();
            haserror = true;
            return true;
        }
        else
            $(reselement).hide();
        var cubelement = '#' + cmbendusercubicle.name + '_error';
        if (cmbenduserdetails.GetValue() != null && cmbendusercubicle.GetValue() == null) {
            $(cubelement).show();
            haserror = true;
            return true;
        }
        else
            $(cubelement).hide();
        return haserror;
    };
    ///Submits the request to the server
    Purpose.prototype.Submit = function () {
        var str = '{0}/{1}/{2}/{3}/{4}/{5}/{6}/{7}/{8}/{9}/{10}/{11}/{12}/{13}/{14}/{15}/{16}/{17}/{18}/{19}/{20}/{21}/{22}/{23}/{24}/{25}/isforadding';
        var CheckNull = this.helper.IfNullRtnEmpty;
        str = str.format(CheckNull(cmbAreafrom.GetText()), CheckNull(cmbarea.GetValue()), CheckNull(cmbarea.GetText()), CheckNull(cmbbuilding.GetValue()), CheckNull(cmbbuilding.GetText()), CheckNull(cmbfloor.GetValue()), CheckNull(cmbfloor.GetText()), CheckNull(cmbcubicle.GetValue()), CheckNull(cmbcubicle.GetText()), CheckNull(cmbengineer.GetValue()), CheckNull(cmblocfrom.GetText()), CheckNull(txtHpsmnumber.GetText()), CheckNull(spnPsid.GetText()), CheckNull(cmbtype.GetValue()), CheckNull(cmbToEngineer.GetValue()), CheckNull(cmbFromEngineer.GetValue()), CheckNull(cmbenduserdetails.GetValue()), CheckNull(cmbendusercubicle.GetValue()), (cmbReplacement.GetValue() == 1 ? "Replacement" : (cmbReplacement.GetValue() == 2 ? "Temprory" : "null")), this.helper.ConvertToDate(ReplacementDate.GetValue()), ConfigureRequired.GetValue(), CheckNull(cmbenduserdetails.GetText()), CheckNull(cmbHandoverReason.GetValue()), CheckNull(cmbassetreplacement.GetText()), chkDirect.GetValue(), chkEditEndUser.GetValue() ? cmbReason.GetText() : null + '/isforadding');
        grdAssetList.PerformCallback(str);
    };
    Purpose.prototype.Disable = function () {
        grdAssetList.UnselectAllRowsOnPage();
        this.EnableCombobox();
    };
    Purpose.prototype.PerformCallBack = function () {
        this.CallBackCommon();
        loadtype = "default";
        cmblocfrom.PerformCallback(cmbtype.GetValue() + '|default');
        cmbarea.PerformCallback(cmbtype.GetValue() + '|default');
        cmbAssetType.PerformCallback();
        cmbengineer.PerformCallback();
        PopUpAssets.Show();
        cmbtype.GetText();
    };
    //common callback for all process flows
    Purpose.prototype.CallBackCommon = function () {
        this.Reset();
        ConfigureRequired.SetValue(true);
        ConfigureRequired.SetEnabled(false);
        cmbFromEngineer.PerformCallback();
        cmbToEngineer.PerformCallback();
        cmbenduserdetails.PerformCallback();
        cmbendusercubicle.PerformCallback();
    };
    Purpose.prototype.Reset = function () {
        cmbFromEngineer.SetValue(null);
        cmbToEngineer.SetValue(null);
        cmbenduserdetails.SetValue(null);
        cmbendusercubicle.SetValue(null);
        cmbAreafrom.SetValue(null);
        cmbfromfloor.SetValue(null);
        cmbarea.SetValue(null);
        cmbcubicle.SetValue(null);
        spnPsid.SetValue(null);
        cmblocfrom.SetValue(null);
        txtHpsmnumber.SetValue(null);
        cmbbuilding.SetValue(null);
        cmbfloor.SetValue(null);
        chkDirect.SetValue(false);
    };
    Purpose.prototype.EnableCombobox = function () {
        cmbFromEngineer.SetEnabled(true);
        cmbToEngineer.SetEnabled(true);
        cmbengineer.SetEnabled(true);
        cmbendusercubicle.SetEnabled(true);
        cmbAreafrom.SetEnabled(true);
        cmbfromfloor.SetEnabled(true);
        cmblocfrom.SetEnabled(true);
        cmbengineer.SetEnabled(true);
    };
    return Purpose;
}());
//Concrete implementation of Stage to building of IpurposeStatergy
var STAGE2BLD = (function (_super) {
    __extends(STAGE2BLD, _super);
    function STAGE2BLD() {
        _super.apply(this, arguments);
    }
    STAGE2BLD.prototype.Disable = function () {
        _super.prototype.Disable.call(this);
        cmbengineer.SetEnabled(false);
        cmbFromEngineer.SetEnabled(false);
        cmbToEngineer.SetEnabled(false);
        spnPsid.SetEnabled(false);
    };
    STAGE2BLD.prototype.Validatedisabledfields = function () {
        return _super.prototype.Validatedisabledfields.call(this);
    };
    STAGE2BLD.prototype.Submit = function () {
        _super.prototype.Submit.call(this);
    };
    STAGE2BLD.prototype.PrformCallBack = function () {
        _super.prototype.PerformCallBack.call(this);
    };
    return STAGE2BLD;
}(Purpose));
//Concrete implementation of buidling to building of IpurposeStatergy
var BLD2BLD = (function (_super) {
    __extends(BLD2BLD, _super);
    function BLD2BLD() {
        _super.apply(this, arguments);
    }
    BLD2BLD.prototype.Disable = function () {
        _super.prototype.Disable.call(this);
        //if (chkDirect.GetValue())
        //    cmbcubicle.SetEnabled(false);
        //else
        cmbcubicle.SetEnabled(true);
        cmbenduserdetails.SetEnabled(false);
        cmbendusercubicle.SetEnabled(false);
        cmbarea.SetEnabled(false);
        cmbfloor.SetEnabled(false);
        cmbbuilding.SetEnabled(false);
        spnPsid.SetEnabled(false);
    };
    BLD2BLD.prototype.Validatedisabledfields = function () {
        return _super.prototype.Validatedisabledfields.call(this);
    };
    BLD2BLD.prototype.Submit = function () {
        _super.prototype.Submit.call(this);
        grdAssetList.PerformCallback('clear');
        ASPxClientEdit.ClearEditorsInContainerById('contentDiv');
        grdAssetList.UnselectRows();
    };
    //disabled function, not being called
    BLD2BLD.prototype.PrformCallBack = function () {
        _super.prototype.CallBackCommon.call(this);
        ConfigureRequired.SetEnabled(true);
        grdAssetList.PerformCallback('clear');
        cmblocfrom.PerformCallback();
        PopUpAssets.Show();
    };
    return BLD2BLD;
}(Purpose));
var HandOver = (function (_super) {
    __extends(HandOver, _super);
    function HandOver() {
        _super.apply(this, arguments);
    }
    HandOver.prototype.Disable = function () {
        _super.prototype.Disable.call(this);
        cmbengineer.SetEnabled(false);
        cmbFromEngineer.SetEnabled(false);
        cmbToEngineer.SetEnabled(false);
        cmbcubicle.SetEnabled(false);
        cmbarea.SetEnabled(false);
        cmbfloor.SetEnabled(false);
        cmbbuilding.SetEnabled(false);
        spnPsid.SetEnabled(false);
    };
    HandOver.prototype.Validatedisabledfields = function () {
        return _super.prototype.Validatedisabledfields.call(this);
    };
    HandOver.prototype.Submit = function () {
        _super.prototype.Submit.call(this);
        grdAssetList.PerformCallback('clear');
        ASPxClientEdit.ClearEditorsInContainerById('contentDiv');
        grdAssetList.UnselectRows();
    };
    HandOver.prototype.PrformCallBack = function () {
        _super.prototype.CallBackCommon.call(this);
        grdAssetList.PerformCallback('clear');
        cmblocfrom.PerformCallback();
        PopUpAssets.Show();
    };
    return HandOver;
}(Purpose));
var ReDeployment = (function (_super) {
    __extends(ReDeployment, _super);
    function ReDeployment() {
        _super.apply(this, arguments);
    }
    ReDeployment.prototype.Disable = function () {
        _super.prototype.Disable.call(this);
        cmbcubicle.SetEnabled(false);
        cmbarea.SetEnabled(false);
        cmbfloor.SetEnabled(false);
        cmbbuilding.SetEnabled(false);
        spnPsid.SetEnabled(false);
    };
    ReDeployment.prototype.Validatedisabledfields = function () {
        return _super.prototype.Validatedisabledfields.call(this);
    };
    ReDeployment.prototype.Submit = function () {
        _super.prototype.Submit.call(this);
        grdAssetList.PerformCallback('clear');
        ASPxClientEdit.ClearEditorsInContainerById('contentDiv');
        grdAssetList.UnselectRows();
    };
    ReDeployment.prototype.PrformCallBack = function () {
        _super.prototype.CallBackCommon.call(this);
        grdAssetList.PerformCallback('clear');
        cmblocfrom.PerformCallback();
        PopUpAssets.Show();
    };
    return ReDeployment;
}(Purpose));
/// Factory to get the right IPurposeStatergy 
var Factory = (function () {
    function Factory() {
    }
    ///Gets the IpurposeStatergy based on the purposeid
    Factory.prototype.GetObject = function (purposeId) {
        switch (purposeId) {
            case "5": return new STAGE2BLD();
            case "6": return new BLD2BLD();
            case "10": return new HandOver();
            case "11": return new ReDeployment();
            case "12": return new BLD2BLD();
            default: return new Purpose();
        }
    };
    return Factory;
}());
//# sourceMappingURL=NewRequestScript.js.map