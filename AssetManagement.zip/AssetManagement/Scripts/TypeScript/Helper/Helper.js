// Extension method for string object 
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined'
                ? args[number]
                : match;
        });
    };
}
var Helper = (function () {
    function Helper() {
    }
    //Gets index of 2 dimention array
    Helper.prototype.GetIndexOf = function (param, arry) {
        var nums = new Array();
        param.forEach(function (value) {
            var result = arry.indexOf(value);
            if (result != -1)
                nums.push(result);
        });
        return nums;
    };
    //Converts date format
    Helper.prototype.ConvertToDate = function (inputFormat) {
        function pad(s) { return (s < 10) ? '0' + s : s; }
        var d = new Date(inputFormat);
        return [pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('-');
    };
    //Returns empty if the value is null
    Helper.prototype.IfNullRtnEmpty = function (value) {
        return (value == null ? '' : value);
    };
    Helper.prototype.RemoveFrmArray = function (nums, arry) {
        var i = 0;
        nums.forEach(function (value) {
            arry.splice(value - i, 1);
            i++;
        });
    };
    return Helper;
}());
//# sourceMappingURL=Helper.js.map