﻿//Declaration for the string object
interface String {
    format(...replacements: string[]): string;
}


// Extension method for string object 
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined'
                ? args[number]
                : match
                ;
        });
    };
}

class Helper {
    //Gets index of 2 dimention array
    public GetIndexOf(param: string[], arry: Array<any>): number[] {
        let nums = new Array<number>();
        param.forEach(function (value) {

            let result = arry.indexOf(value);
            if (result != -1)
                nums.push(result);
        });
        return nums;
    }

    //Converts date format
    public ConvertToDate(inputFormat) {
        function pad(s) { return (s < 10) ? '0' + s : s; }
        var d = new Date(inputFormat);
        return [pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('-');
    }

    //Returns empty if the value is null
    public IfNullRtnEmpty(value): any {
        return (value == null ? '' : value);
    }

    public RemoveFrmArray(nums: number[], arry: Array<any>) {
        let i: number = 0;
        nums.forEach(function (value) {
            arry.splice(value - i, 1);
            i++;
        });
    }

}