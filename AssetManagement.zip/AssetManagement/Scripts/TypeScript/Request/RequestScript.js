/// <reference path="../jquery.d.ts" />
/// <reference path="../Helper/Helper.ts" />
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
//Concrete implementation of IpurposeStatergy
var Request_Purpose = (function () {
    function Request_Purpose() {
        this.arry = new Array(txtHpsmnumber, cmbAreafrom, cmbarea, cmbbuilding, cmbengineer, cmbfloor, cmbcubicle, spnPsid, cmbFromEngineer, cmbToEngineer, cmbenduserdetails);
        this.helper = new Helper();
    }
    Request_Purpose.prototype.Validate = function () {
        var haserror = false;
        var that = this;
        $.each(this.arry, function (index, value) {
            var element = '#' + value.name + '_error';
            if (value.GetText() == '') {
                $(element).show();
                haserror = true;
                return true;
            }
            else if ((IsReplacement.GetValue() == true) && (ReplacementDate.GetValue() == null || that.helper.ConvertToDate(ReplacementDate.GetValue()) <= that.helper.ConvertToDate(new Date()))) {
                var element_1 = '#' + ReplacementDate.name + '_error';
                $(element_1).show();
                haserror = true;
                return true;
            }
            $(element).hide();
            var repElement = '#' + ReplacementDate.name + '_error';
            $(repElement).hide();
        });
        return haserror;
    };
    ///Submits the request to the server
    Request_Purpose.prototype.Submit = function () {
        var str = '{0}/{1}/{2}/{3}/{4}/{5}/{6}/{7}/{8}/{9}/{10}/{11}/{12}/{13}/{14}/{15}/{16}/{17}/{18}/{19}/isforadding';
        var CheckNull = this.helper.IfNullRtnEmpty;
        str = str.format(CheckNull(cmbAreafrom.GetText()), CheckNull(cmbarea.GetValue()), CheckNull(cmbarea.GetText()), CheckNull(cmbbuilding.GetValue()), CheckNull(cmbbuilding.GetText()), CheckNull(cmbfloor.GetValue()), CheckNull(cmbfloor.GetText()), CheckNull(cmbcubicle.GetValue()), CheckNull(cmbcubicle.GetText()), CheckNull(cmbengineer.GetValue()), CheckNull(cmblocfrom.GetText()), CheckNull(txtHpsmnumber.GetText()), CheckNull(spnPsid.GetText()), CheckNull(cmbtype.GetValue()), CheckNull(cmbToEngineer.GetValue()), CheckNull(cmbFromEngineer.GetValue()), CheckNull(cmbenduserdetails.GetValue()), CheckNull(cmbenduserdetails.cpHiddenToCubicle[cmbenduserdetails.GetSelectedIndex()]), IsReplacement.GetValue(), this.helper.ConvertToDate(ReplacementDate.GetValue()), '/isforadding');
        grdAssetList.PerformCallback(str);
    };
    Request_Purpose.prototype.Disable = function () {
        grdAssetList.UnselectAllRowsOnPage();
        this.ResetCombobox();
    };
    Request_Purpose.prototype.PerformCallBack = function () {
        this.CallBackCommon();
        loadtype = "default";
        cmblocfrom.PerformCallback(cmbtype.GetValue() + '|default');
        cmbarea.PerformCallback(cmbtype.GetValue() + '|default');
        cmbAssetType.PerformCallback();
        cmbengineer.PerformCallback();
        cmbtype.GetText();
    };
    Request_Purpose.prototype.CallBackCommon = function () {
        this.Reset();
        cmbFromEngineer.PerformCallback();
        cmbToEngineer.PerformCallback();
        cmbenduserdetails.PerformCallback();
    };
    Request_Purpose.prototype.Reset = function () {
        cmbFromEngineer.SetValue(null);
        cmbToEngineer.SetValue(null);
        cmbenduserdetails.SetValue(null);
        cmbarea.SetValue(null);
        cmbcubicle.SetValue(null);
        spnPsid.SetValue(null);
        cmblocfrom.SetValue(null);
    };
    Request_Purpose.prototype.ResetCombobox = function () {
        cmbFromEngineer.SetEnabled(true);
        cmbToEngineer.SetEnabled(true);
        cmbengineer.SetEnabled(true);
        cmbenduserdetails.SetEnabled(true);
        cmbAreafrom.SetEnabled(true);
        cmbfromfloor.SetEnabled(true);
        cmblocfrom.SetEnabled(true);
        cmbengineer.SetEnabled(true);
    };
    return Request_Purpose;
}());
//Concrete implementation of Stage to building of IpurposeStatergy
var Request_STAGE2BLD = (function (_super) {
    __extends(Request_STAGE2BLD, _super);
    function Request_STAGE2BLD() {
        _super.apply(this, arguments);
    }
    Request_STAGE2BLD.prototype.Disable = function () {
        _super.prototype.Disable.call(this);
        cmbengineer.SetEnabled(false);
        cmbFromEngineer.SetEnabled(false);
        cmbToEngineer.SetEnabled(false);
    };
    Request_STAGE2BLD.prototype.Validate = function () {
        var nums = this.helper.GetIndexOf([cmbengineer, cmbFromEngineer, cmbToEngineer], this.arry);
        this.helper.RemoveFrmArray(nums, this.arry);
        return _super.prototype.Validate.call(this);
    };
    Request_STAGE2BLD.prototype.Submit = function () {
        _super.prototype.Submit.call(this);
    };
    Request_STAGE2BLD.prototype.PrformCallBack = function () {
        _super.prototype.PerformCallBack.call(this);
    };
    return Request_STAGE2BLD;
}(Request_Purpose));
//Concrete implementation of buidling to building of IpurposeStatergy
var Request_BLD2BLD = (function (_super) {
    __extends(Request_BLD2BLD, _super);
    function Request_BLD2BLD() {
        _super.apply(this, arguments);
    }
    Request_BLD2BLD.prototype.Disable = function () {
        _super.prototype.Disable.call(this);
        cmbcubicle.SetEnabled(false);
        cmbenduserdetails.SetEnabled(false);
        cmbarea.SetEnabled(false);
        cmbfloor.SetEnabled(false);
        cmbbuilding.SetEnabled(false);
        spnPsid.SetEnabled(false);
    };
    Request_BLD2BLD.prototype.Validate = function () {
        var nums = this.helper.GetIndexOf([cmbenduserdetails], this.arry);
        this.helper.RemoveFrmArray(nums, this.arry);
        return _super.prototype.Validate.call(this);
    };
    Request_BLD2BLD.prototype.Submit = function () {
        _super.prototype.Submit.call(this);
        grdAssetList.PerformCallback('clear');
        ASPxClientEdit.ClearEditorsInContainerById('contentDiv');
        grdAssetList.UnselectRows();
    };
    Request_BLD2BLD.prototype.PrformCallBack = function () {
        _super.prototype.CallBackCommon.call(this);
        grdAssetList.PerformCallback('clear');
        cmblocfrom.PerformCallback();
    };
    return Request_BLD2BLD;
}(Request_Purpose));
var Request_HandOver = (function (_super) {
    __extends(Request_HandOver, _super);
    function Request_HandOver() {
        _super.apply(this, arguments);
    }
    Request_HandOver.prototype.Disable = function () {
        _super.prototype.Disable.call(this);
        cmbengineer.SetEnabled(false);
        cmbFromEngineer.SetEnabled(false);
        cmbToEngineer.SetEnabled(false);
        cmbcubicle.SetEnabled(false);
        cmbarea.SetEnabled(false);
        cmbfloor.SetEnabled(false);
        cmbbuilding.SetEnabled(false);
        spnPsid.SetEnabled(false);
    };
    Request_HandOver.prototype.Validate = function () {
        var nums = this.helper.GetIndexOf([cmbarea, cmbbuilding, cmbengineer, cmbfloor, cmbcubicle, spnPsid, cmbFromEngineer, cmbToEngineer], this.arry);
        this.helper.RemoveFrmArray(nums, this.arry);
        return _super.prototype.Validate.call(this);
    };
    Request_HandOver.prototype.Submit = function () {
        _super.prototype.Submit.call(this);
        grdAssetList.PerformCallback('clear');
        ASPxClientEdit.ClearEditorsInContainerById('contentDiv');
        grdAssetList.UnselectRows();
    };
    Request_HandOver.prototype.PrformCallBack = function () {
        _super.prototype.CallBackCommon.call(this);
        grdAssetList.PerformCallback('clear');
        cmblocfrom.PerformCallback();
    };
    return Request_HandOver;
}(Request_Purpose));
var Request_ReDeployment = (function (_super) {
    __extends(Request_ReDeployment, _super);
    function Request_ReDeployment() {
        _super.apply(this, arguments);
    }
    Request_ReDeployment.prototype.Disable = function () {
        _super.prototype.Disable.call(this);
        cmbcubicle.SetEnabled(false);
        cmbarea.SetEnabled(false);
        cmbfloor.SetEnabled(false);
        cmbbuilding.SetEnabled(false);
        spnPsid.SetEnabled(false);
    };
    Request_ReDeployment.prototype.Validate = function () {
        var nums = this.helper.GetIndexOf([cmbarea, cmbbuilding, cmbfloor, cmbcubicle, spnPsid], this.arry);
        this.helper.RemoveFrmArray(nums, this.arry);
        return _super.prototype.Validate.call(this);
    };
    Request_ReDeployment.prototype.Submit = function () {
        _super.prototype.Submit.call(this);
        grdAssetList.PerformCallback('clear');
        ASPxClientEdit.ClearEditorsInContainerById('contentDiv');
        grdAssetList.UnselectRows();
    };
    Request_ReDeployment.prototype.PrformCallBack = function () {
        _super.prototype.CallBackCommon.call(this);
        grdAssetList.PerformCallback('clear');
        cmblocfrom.PerformCallback();
    };
    return Request_ReDeployment;
}(Request_Purpose));
/// Factory to get the right IPurposeStatergy 
var Request_Factory = (function () {
    function Request_Factory() {
    }
    ///Gets the IpurposeStatergy based on the purposeid
    Request_Factory.prototype.GetObject = function (purposeId) {
        switch (purposeId) {
            case "5": return new Request_STAGE2BLD();
            case "6": return new Request_BLD2BLD();
            case "10": return new Request_HandOver();
            case "11": return new Request_ReDeployment();
            case "12": return new Request_BLD2BLD();
            default: return new Request_Purpose();
        }
    };
    return Request_Factory;
}());
//# sourceMappingURL=RequestScript.js.map