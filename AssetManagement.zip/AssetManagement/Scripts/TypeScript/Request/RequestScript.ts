﻿
/// <reference path="../jquery.d.ts" />
/// <reference path="../Helper/Helper.ts" />

//objects which are avaiable in other JS files 
declare var txtHpsmnumber: any;
declare var cmbAreafrom: any;
declare var cmbarea: any;
declare var cmbbuilding: any;
declare var cmbengineer: any;
declare var cmbfloor: any;
declare var cmbcubicle: any;
declare var spnPsid: any;
declare var cmblocfrom: any;
declare var cmbtype: any;
declare var grdAssetList: any;
declare var ASPxClientEdit: any;
declare var cmbFromEngineer: any;
declare var cmbToEngineer: any;
declare var cmbenduserdetails: any;
declare var cmbfromfloor: any;
declare var cmbAssetType: any;
declare var IsReplacement: any;
declare var ReplacementDate: any;
declare var loadtype: any;
declare var PopUpAssets: any;


//Declaration for the purpose statergy
interface IRequest_PurposeStatergy {
    Disable(): void;
    Validate(): boolean;
    Submit(): void;
    PerformCallBack(): void;
}



//Concrete implementation of IpurposeStatergy
class Request_Purpose implements IRequest_PurposeStatergy {
    arry = new Array<any>(txtHpsmnumber, cmbAreafrom, cmbarea, cmbbuilding, cmbengineer, cmbfloor, cmbcubicle, spnPsid, cmbFromEngineer, cmbToEngineer, cmbenduserdetails);
    helper = new Helper();

    public Validate(): boolean {
        let haserror: boolean = false;
        var that = this;
        $.each(this.arry, function (index, value) {
            let element = '#' + value.name + '_error';
            if (value.GetText() == '') {
                $(element).show();
                haserror = true;
                return true;
            }
            else if ((IsReplacement.GetValue() == true) && (ReplacementDate.GetValue() == null || that.helper.ConvertToDate(ReplacementDate.GetValue()) <= that.helper.ConvertToDate(new Date()))) {
                let element = '#' + ReplacementDate.name + '_error';
                $(element).show();
                haserror = true;
                return true;
            }

            $(element).hide();
            let repElement = '#' + ReplacementDate.name + '_error';
            $(repElement).hide();
        });

        return haserror;
    }



    ///Submits the request to the server
    public Submit() {
        let str: string = '{0}/{1}/{2}/{3}/{4}/{5}/{6}/{7}/{8}/{9}/{10}/{11}/{12}/{13}/{14}/{15}/{16}/{17}/{18}/{19}/isforadding';
        let CheckNull = this.helper.IfNullRtnEmpty;
        str = str.format(CheckNull(cmbAreafrom.GetText()), CheckNull(cmbarea.GetValue()),
            CheckNull(cmbarea.GetText()), CheckNull(cmbbuilding.GetValue()), CheckNull(cmbbuilding.GetText()), CheckNull(cmbfloor.GetValue()), CheckNull(cmbfloor.GetText()), CheckNull(cmbcubicle.GetValue()), CheckNull(cmbcubicle.GetText()),
            CheckNull(cmbengineer.GetValue()), CheckNull(cmblocfrom.GetText()), CheckNull(txtHpsmnumber.GetText()), CheckNull(spnPsid.GetText()), CheckNull(cmbtype.GetValue()), CheckNull(cmbToEngineer.GetValue()),
            CheckNull(cmbFromEngineer.GetValue()), CheckNull(cmbenduserdetails.GetValue()), CheckNull(cmbenduserdetails.cpHiddenToCubicle[cmbenduserdetails.GetSelectedIndex()]), IsReplacement.GetValue(),
            this.helper.ConvertToDate(ReplacementDate.GetValue()), '/isforadding'); grdAssetList.PerformCallback(str);
    }

    public Disable(): void {
        grdAssetList.UnselectAllRowsOnPage();
        this.ResetCombobox();
    }

    public PerformCallBack(): void {
        this.CallBackCommon();
        loadtype = "default";
        cmblocfrom.PerformCallback(cmbtype.GetValue() + '|default');
        cmbarea.PerformCallback(cmbtype.GetValue() + '|default');
        cmbAssetType.PerformCallback();
        cmbengineer.PerformCallback();
        cmbtype.GetText()
    }

    public CallBackCommon() {
        this.Reset();
        cmbFromEngineer.PerformCallback();
        cmbToEngineer.PerformCallback();
        cmbenduserdetails.PerformCallback();
    }

    public Reset() {
        cmbFromEngineer.SetValue(null);
        cmbToEngineer.SetValue(null);
        cmbenduserdetails.SetValue(null);
        cmbarea.SetValue(null);
        cmbcubicle.SetValue(null);
        spnPsid.SetValue(null);
        cmblocfrom.SetValue(null);
    }

    public ResetCombobox() {
        cmbFromEngineer.SetEnabled(true);
        cmbToEngineer.SetEnabled(true);
        cmbengineer.SetEnabled(true);
        cmbenduserdetails.SetEnabled(true);
        cmbAreafrom.SetEnabled(true)
        cmbfromfloor.SetEnabled(true)
        cmblocfrom.SetEnabled(true)
        cmbengineer.SetEnabled(true);
    }

}


//Concrete implementation of Stage to building of IpurposeStatergy
class Request_STAGE2BLD extends Request_Purpose implements IRequest_PurposeStatergy {

    public Disable(): void {
        super.Disable();
        cmbengineer.SetEnabled(false);
        cmbFromEngineer.SetEnabled(false);
        cmbToEngineer.SetEnabled(false);
    }

    public Validate(): boolean {
        let nums = this.helper.GetIndexOf([cmbengineer, cmbFromEngineer, cmbToEngineer], this.arry);
        this.helper.RemoveFrmArray(nums, this.arry);
        return super.Validate();
    }

    public Submit(): void {
        super.Submit();
    }

    public PrformCallBack(): void {
        super.PerformCallBack();
    }

}

//Concrete implementation of buidling to building of IpurposeStatergy
class Request_BLD2BLD extends Request_Purpose implements IRequest_PurposeStatergy {

    public Disable(): void {
        super.Disable();
        cmbcubicle.SetEnabled(false);
        cmbenduserdetails.SetEnabled(false);
        cmbarea.SetEnabled(false);
        cmbfloor.SetEnabled(false);
        cmbbuilding.SetEnabled(false);
        spnPsid.SetEnabled(false);

    }

    public Validate(): boolean {
        let nums = this.helper.GetIndexOf([cmbenduserdetails], this.arry);
        this.helper.RemoveFrmArray(nums, this.arry);
        return super.Validate();
    }

    public Submit(): void {
        super.Submit();
        grdAssetList.PerformCallback('clear');
        ASPxClientEdit.ClearEditorsInContainerById('contentDiv');
        grdAssetList.UnselectRows()
    }

    public PrformCallBack(): void {
        super.CallBackCommon();
        grdAssetList.PerformCallback('clear');
        cmblocfrom.PerformCallback();
    }

}

class Request_HandOver extends Request_Purpose implements IRequest_PurposeStatergy {
    public Disable(): void {
        super.Disable();
        cmbengineer.SetEnabled(false);
        cmbFromEngineer.SetEnabled(false);
        cmbToEngineer.SetEnabled(false);
        cmbcubicle.SetEnabled(false);
        cmbarea.SetEnabled(false);
        cmbfloor.SetEnabled(false);
        cmbbuilding.SetEnabled(false);
        spnPsid.SetEnabled(false);
    }

    public Validate(): boolean {
        let nums = this.helper.GetIndexOf([cmbarea, cmbbuilding, cmbengineer, cmbfloor, cmbcubicle, spnPsid, cmbFromEngineer, cmbToEngineer], this.arry);
        this.helper.RemoveFrmArray(nums, this.arry);

        return super.Validate();
    }

    public Submit(): void {

        super.Submit();

        grdAssetList.PerformCallback('clear');
        ASPxClientEdit.ClearEditorsInContainerById('contentDiv');
        grdAssetList.UnselectRows()
    }

    public PrformCallBack(): void {
        super.CallBackCommon();
        grdAssetList.PerformCallback('clear');
        cmblocfrom.PerformCallback();
    }
}

class Request_ReDeployment extends Request_Purpose implements IRequest_PurposeStatergy {
    public Disable(): void {
        super.Disable();
        cmbcubicle.SetEnabled(false);
        cmbarea.SetEnabled(false);
        cmbfloor.SetEnabled(false);
        cmbbuilding.SetEnabled(false);
        spnPsid.SetEnabled(false);
    }

    public Validate(): boolean {
        let nums = this.helper.GetIndexOf([cmbarea, cmbbuilding, cmbfloor, cmbcubicle, spnPsid], this.arry);
        this.helper.RemoveFrmArray(nums, this.arry);
        return super.Validate();
    }

    public Submit(): void {
        super.Submit();
        grdAssetList.PerformCallback('clear');
        ASPxClientEdit.ClearEditorsInContainerById('contentDiv');
        grdAssetList.UnselectRows()
    }

    public PrformCallBack(): void {
        super.CallBackCommon();
        grdAssetList.PerformCallback('clear');
        cmblocfrom.PerformCallback();
    }
}


/// Factory to get the right IPurposeStatergy 
class Request_Factory {

    ///Gets the IpurposeStatergy based on the purposeid
    public GetObject(purposeId: string) {
        switch (purposeId) {
            case "5": return new Request_STAGE2BLD();
            case "6": return new Request_BLD2BLD();
            case "10": return new Request_HandOver();
            case "11": return new Request_ReDeployment();
            case "12": return new Request_BLD2BLD();
            default: return new Request_Purpose();
        }
    }
}
