/// <reference path="../scripts/jquery.d.ts" />
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
// Extension method for string object 
if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined'
                ? args[number]
                : match;
        });
    };
}
//Concrete implementation of IpurposeStatergy
var Purpose = (function () {
    function Purpose() {
        this.arry = new Array([txtHpsmnumber, 'Hpsmerror'], [cmbAreafrom, 'areaerror'], [cmbarea, 'toareaerror'], [cmbbuilding, 'tobuildingerror'], [cmbengineer, 'engineererror'], [cmbfloor, 'tofloorerror'], [cmbcubicle, 'tocubicle'], [spnPsid, 'txtcallback_toPSIDerror']);
    }
    Purpose.prototype.Validate = function () {
        var haserror = false;
        var contentplaceholder = "#ctl00_ContentPlaceHolder1_pcLogin_Panel1_";
        this.arry.forEach(function (item) {
            if (item[0].GetText() == '') {
                $(contentplaceholder + item[1]).show();
                haserror = true;
                return true;
            }
            $(contentplaceholder + item[1]).hide();
        });
        return haserror;
    };
    ///Submits the request to the server
    Purpose.prototype.Submit = function () {
        var str = '{0}/{1}/{2}/{3}/{4}/{5}/{6}/{7}/{8}/{9}/{10}/{11}/{12}/{13}/isforadding';
        var CheckNull = this.IfNullRtnEmpty;
        str = str.format(CheckNull(cmbAreafrom.GetText()), CheckNull(cmbarea.GetValue()), CheckNull(cmbarea.GetText()), CheckNull(cmbbuilding.GetValue()), CheckNull(cmbbuilding.GetText()), CheckNull(cmbfloor.GetValue()), CheckNull(cmbfloor.GetText()), CheckNull(cmbcubicle.GetValue()), CheckNull(cmbcubicle.GetText()), CheckNull(cmbengineer.GetValue()), CheckNull(cmblocfrom.GetText()), CheckNull(txtHpsmnumber.GetText()), CheckNull(spnPsid.GetText()), CheckNull(cmbtype.GetValue()), '/isforadding');
        grdAssetList.PerformCallback(str);
    };
    Purpose.prototype.Disable = function () {
    };
    //Gets index of 2 dimention array
    Purpose.prototype.GetIndexOf2Dimention = function (num, param) {
        var nums = new Array();
        var arry = this.arry;
        param.forEach(function (value) {
            var result = arry.map(function (element) { return element[num]; }).indexOf(value);
            if (result != -1)
                nums.push(result);
        });
        return nums;
    };
    //Returns empty if the value is null
    Purpose.prototype.IfNullRtnEmpty = function (value) {
        return (value == null ? '' : value);
    };
    return Purpose;
}());
//Concrete implementation of Stage to building of IpurposeStatergy
var STAGE2BLD = (function (_super) {
    __extends(STAGE2BLD, _super);
    function STAGE2BLD() {
        _super.apply(this, arguments);
    }
    STAGE2BLD.prototype.Disable = function () {
        //
    };
    STAGE2BLD.prototype.Validate = function () {
        var nums = _super.prototype.GetIndexOf2Dimention.call(this, 1, ['engineererror']);
        var arry = this.arry;
        nums.forEach(function (value) {
            arry.splice(value, 1);
        });
        return _super.prototype.Validate.call(this);
    };
    STAGE2BLD.prototype.Submit = function () {
        _super.prototype.Submit.call(this);
    };
    return STAGE2BLD;
}(Purpose));
//Concrete implementation of buidling to building of IpurposeStatergy
var BLD2BLD = (function (_super) {
    __extends(BLD2BLD, _super);
    function BLD2BLD() {
        _super.apply(this, arguments);
    }
    BLD2BLD.prototype.Disable = function () {
    };
    BLD2BLD.prototype.Validate = function () {
        var nums = _super.prototype.GetIndexOf2Dimention.call(this, 1, ['engineererror']);
        var arry = this.arry;
        nums.forEach(function (value) {
            arry.splice(value, 1); //Removes element from array
        });
        return _super.prototype.Validate.call(this);
    };
    BLD2BLD.prototype.Submit = function () {
        _super.prototype.Submit.call(this);
        grdAssetList.PerformCallback('clear');
        grdAssetList.UnselectRows();
        ASPxClientEdit.ClearEditorsInContainerById('contentDiv');
        grdAssetList.UnselectRows();
    };
    return BLD2BLD;
}(Purpose));
/// Factory to get the right IPurposeStatergy 
var Factory = (function () {
    function Factory() {
    }
    ///Gets the IpurposeStatergy based on the purposeid
    Factory.prototype.GetObject = function (purposeId) {
        switch (purposeId) {
            case "5": return new STAGE2BLD();
            case "6": return new BLD2BLD();
            default: return new Purpose();
        }
    };
    return Factory;
}());
//# sourceMappingURL=NewRequestScript.js.map