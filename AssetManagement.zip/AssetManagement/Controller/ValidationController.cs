﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AssetManagementLibrary.Entities.Movement;
using System.Web.Script.Serialization;

namespace AssetManagement.Controllers
{
    public class ValidationController : Controller
    {
        public AssetManagementLibrary.Queries QueryHelper
        {
            get
            {
                return new AssetManagementLibrary.Queries();
            }
        }

        [HttpGet]
        public ActionResult GetRelatedAssets(string hpsm, string psid)
        {
            var recordCount = 0;
            var ipGetDetails = new List<InputParameters>
            {
                new InputParameters {SqlParam = "HPSM", ParamValue = hpsm},
                new InputParameters {SqlParam = "PSID", ParamValue = psid}
            };
            var dt = QueryHelper.GetRelatedAssetsOnNewRequest(ipGetDetails);
            if (dt != null)
            {
                recordCount = dt.Count;
                var jsonSerialiser = new JavaScriptSerializer();

                var list = (List<AssetTranExtn>)Session["datatobind_grdAssetSplit"];
                if (list != null)
                {
                    var sessionCount = list.Where(x => x.HpsmNo == hpsm && x.EndUserId == psid).Count();
                    recordCount += sessionCount;
                }
            }
            //var data = jsonSerialiser.Serialize(new { count = recordCount, hpsmno = hpsm, userid = psid });

            return Json(new { count = recordCount, hpsmno = hpsm, userid = psid}, JsonRequestBehavior.AllowGet);
        }
    }
}