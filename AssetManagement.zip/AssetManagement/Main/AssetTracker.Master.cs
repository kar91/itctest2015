﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Main
{
    public partial class AssetTracker : System.Web.UI.MasterPage
    {
        Color colour = ColorTranslator.FromHtml("#E7EFF2");
        bool grade = false;
        DataTable dt = new DataTable();
        protected void Page_Load(object sender, EventArgs e)
        {
            Label lbl = (Label)FindControl("lblName");
            if (!IsPostBack)
            {
                    lbl.Text = "Welcome : " + Session["Username"].ToString();
            }

        }
        public void userCheck(string user = "")
        {


        }

        protected void create_Click(object sender, EventArgs e)
        {

        }
        protected void AsseInventory_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Tasks/MainForm.aspx");
        }

        protected void AssetSearch_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Tasks/SearchAssets.aspx");
        }

        protected void DeployItem_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Tasks/AddDeploymentItem.aspx");
        }

        protected void AssetDailyReview_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Tasks/DailyReview.aspx");
        }       
    }
}