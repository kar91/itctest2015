﻿using AssetManagementLibrary;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.Entities.Movement.Menu;
using AssetManagementLibrary.OtherHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web.UI.HtmlControls;

namespace AssetManagement.Main
{
    public partial class AssetMovement : System.Web.UI.MasterPage
    {
        /// <summary>
        /// Page load event handler, load menu items based on access group
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            var usrprofile = Session["UserProfile"] as UserProfile;
            if (usrprofile != null)
            {
                string imgSrc= "https://profiles.app.itcinfotech.com/USER%20PHOTOS/_w/AV" + usrprofile.PSID + "_jpg.JPG";
                string imgDefault = "../Images/defaultuser.png";
                profimg.ImageUrl = IsUrlExist(imgSrc) ? imgSrc : imgDefault;
                profimg.DataBind();
                userlbl.Text = Session["Username"] == null ? "" : Session["Username"].ToString();
                psidlbl.Text = usrprofile.PSID;
            }

            SessionTimeOutControl.TimeOutUrl = "~/Movement/TimeOutPage.html";

            if (Session["UserProfile"] != null)
            {
                var usrProfile = (UserProfile)Session["UserProfile"];
                var qryHelper = new AssetManagementLibrary.Queries();
                var MenuLst = CacheHelper.GetInstance.GetValue("MenuAccessItems", new Queries().GetMenuAccessItems, 100, true, null);
                var menuAccessItems = MenuLst.Where(mlst => mlst.AccessGroupID == usrProfile.UserGroups.LastOrDefault().GroupID).ToList();
                if(menuAccessItems.Count==0)
                    Server.Transfer("~/Error/User404.html");
                var orderedLst = menuAccessItems.FirstOrDefault().MenuGroup.OrderBy(o => o.MenuGroupID);
                foreach (var item in orderedLst)
	            {
                    createRow(item,item.Name);
	            }
            }
            else
                Server.Transfer("~/Error/User404.html");
        }


        /// <summary>
        /// to generate menu items in each row, 3 menu items allowed per row 
        /// </summary>
        /// <param name="page">MenuGroup object having list of menus</param>
        /// <param name="title">string text for menu group</param>
        public void createRow(MenuGroup page, string title)
        {
            if (page == null) return;

            int counter = 0;
            HtmlTableRow headertr = new HtmlTableRow();
            headertr.Style.Add("Padding", "0.1em");
            var headercell = new HtmlTableCell();
            var headerdiv = new HtmlGenericControl("Div");
            headerdiv.Attributes.Add("title", "A title for this div");
            headerdiv.InnerHtml = "<h5 style='color: #009688;'>" + title + "</h5>";
            headercell.Controls.Add(headerdiv);
            headertr.Cells.Add(headercell);
            menuTbl.Rows.Add(headertr);
            HtmlTableRow str = new HtmlTableRow();

            //for each page in the MenuGroup list, render menu items
            page.Menu.ForEach(r =>
            {
                if (counter > 2)
                {
                    counter = 0;
                    str = new HtmlTableRow();
                }
                str.Controls.Add(CreateCell(r));
                menuTbl.Rows.Add(str);
                counter++;
            });
        }


        /// <summary>
        /// create html table cell for passed item
        /// </summary>
        /// <param name="menu"></param>
        /// <returns></returns>
        private HtmlTableCell CreateCell(Menu menu)
        {
            var cell = new HtmlTableCell();
            cell.Controls.Add(GetDivForMenu(menu));
            return cell;
        }


        /// <summary>
        /// create div for menu item
        /// </summary>
        /// <param name="menu"></param>
        /// <returns></returns>
        private HtmlGenericControl GetDivForMenu(Menu menu)
        {
            HtmlGenericControl div = new HtmlGenericControl("Div") { ID = menu.Menu_Desc };
            div.Attributes.Add("class", "tile");
            div.Style.Add("background-color", menu.Background_Color);
            div.Style.Add("cursor", "pointer");
            div.Attributes.Add("onclick", "window.location.href = " + menu.Url);
            var innerDiv = new HtmlGenericControl("Div");
            innerDiv.Attributes.Add("class", "content_image");

            var img = new HtmlGenericControl("img");
            img.Attributes.Add("src", menu.ImgUrl);
            img.Attributes.Add("width", "35");
            img.Attributes.Add("height", "35");
            img.Style.Add("padding-right", "1px");
            img.Style.Add("color", "white");
            img.Style.Add("margin-bottom", "0.4em");

            innerDiv.Controls.Add(img);

            var contentDiv = new HtmlGenericControl("Div");
            contentDiv.Attributes.Add("class", "content");
            contentDiv.InnerText = menu.Menu_Desc;
            innerDiv.Controls.Add(contentDiv);

            div.Controls.Add(innerDiv);
            return div;
        }

        //10/04/2017
        public bool IsUrlExist(string url)
        {
            WebRequest webRequest = WebRequest.Create(url);
            webRequest.Method = "HEAD";
            webRequest.Timeout = 12000;

            try
            {
                var response = webRequest.GetResponse();
                /* response is `200 OK` */
                response.Close();
            }
            catch
            {
                /* Any other response */
                return false;
            }

            return true;
        }
    }

}