﻿using AssetManagementLibrary.Entities.Movement;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Script.Serialization;
using System.Linq;
using System.Web.Mvc;

namespace AssetManagement.UIHelper
{
    public class DataHandler : IHttpHandler, System.Web.SessionState.IRequiresSessionState
    {
        /// <summary>
        /// You will need to configure this handler in the Web.config file of your 
        /// web and register it with IIS before being able to use it. For more information
        /// see the following link: http://go.microsoft.com/?linkid=8101007
        /// </summary>
        #region IHttpHandler Members

        public AssetManagementLibrary.Queries QueryHelper
        {
            get
            {
                return new AssetManagementLibrary.Queries();
            }
        }
        public bool IsReusable
        {
            // Return false in case your Managed Handler cannot be reused for another request.
            // Usually this would be false in case you have some state information preserved per request.
            get { return true; }
        }

        public void ProcessRequest(HttpContext context)
        {
            string method = context.Request.QueryString["MethodName"].ToString();
            context.Response.ContentType = "text/json";
            string hpsm = context.Request.Form["hpsm"];
            string psid = context.Request.Form["psid"];
            switch (method)
            {
                case "GetData":
                    context.Response.Write(GetData(hpsm,psid));
                    break;
            }

        }

        protected string GetData(string hpsm, string psid)
        {
            var recordCount = 0;
            var ipGetDetails = new List<InputParameters>
            {
                new InputParameters {SqlParam = "HPSM", ParamValue = hpsm},
                new InputParameters {SqlParam = "PSID", ParamValue = psid}
            };
            var dt = QueryHelper.GetRelatedAssetsOnNewRequest(ipGetDetails);
            if (dt != null)
            {
                recordCount = dt.Count;
                var jsonSerialiser = new JavaScriptSerializer();

                var list = (List<AssetTranExtn>)HttpContext.Current.Session["datatobind_grdAssetSplit"];
                if (list != null)
                {
                    var sessionCount = list.Where(x => x.HpsmNo == hpsm && x.EndUserId == psid).Count();
                    recordCount += sessionCount;
                }
            }
            //var data = jsonSerialiser.Serialize(new { count = recordCount, hpsmno = hpsm, userid = psid });

            return (new JavaScriptSerializer().Serialize(new { count = recordCount, hpsmno = hpsm, userid = psid }));
        }


        #endregion
    }
}
