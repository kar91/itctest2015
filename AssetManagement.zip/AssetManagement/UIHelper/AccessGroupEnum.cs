﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AssetManagement.UIHelper
{
    public enum AccessGroupEnum
    {
        Approver = 1,
        FloorEngg = 9,
        Gaurd = 11,
        AssetLead = 12,
        Tier1Lead = 18,
        Tier1Engg = 19,
        EndUser = 20,
        Admin = 21
    }
}