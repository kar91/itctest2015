﻿using AssetManagementLibrary;
using AssetManagementLibrary.Entities.Movement;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using AssetManagementLibrary.OtherHelpers;
namespace AssetManagement.UIHelper
{
    public static class Helper
    {
        /// <summary>
        /// Gets the enginner specific to building
        /// </summary>
        /// <param name="buildingId">building Id</param>
        /// <returns>engineer type</returns>
        public static Engineer GetBuildingEnginner(int buildingId)
        {
            return GetBuildingEngineers().Where(engg =>
                   {
                       return engg.Locations.Any(b => b.BuildingInfo.Any(be =>
                       {
                           return be.BuildingId.HasValue ? be.BuildingId.Value == buildingId ? true : false : false;
                       }));
                   }).FirstOrDefault(); ;


        }

        private static bool GetResult(BuildingInfo b, int id)
        {
            if (b.BuildingId.HasValue)
            {
                return (b.BuildingId == id);
            }
            return false;

        }


        /// <summary>
        /// Gets all the Asset lead
        /// </summary>
        public static List<Engineer> GetAssetLeadEngineers()
        {
            return CacheHelper.GetInstance.GetValue("Engineers", new Queries().GetEnginnersDetail, 100, true, null)
            .Where(w => w.Type == "AL").ToList();
        }

        /// <summary>
        /// Gets all the building enginners 
        /// </summary>
        public static List<Engineer> GetBuildingEngineers()
        {
            return CacheHelper.GetInstance.GetValue("Engineers", new Queries().GetEnginnersDetail, 100, true, null)
            .Where(w => w.Type == "BE").ToList();
        }

        /// <summary>
        /// Gets all the movement engineers
        /// </summary>
        public static List<Engineer> GetMovementEngineers()
        {
            return CacheHelper.GetInstance.GetValue("Engineers", new Queries().GetEnginnersDetail, 100, true, null)
            .Where(w => w.Type == "M").ToList();
        }

        /// <summary>
        /// Gets all the Tier1Lead engineers
        /// </summary>
        public static List<Engineer> GetTier1LeadEngineers()
        {
            return CacheHelper.GetInstance.GetValue("Engineers", new Queries().GetEnginnersDetail, 100, true, null)
            .Where(w => w.Type == "T1L").ToList();
        }

        /// <summary>
        /// Gets all the Tier1Engineers 
        /// </summary>
        public static List<Engineer> GetTier1Engineers()
        {
            return CacheHelper.GetInstance.GetValue("Engineers", new Queries().GetEnginnersDetail, 100, true, null)
            .Where(w => w.Type == "T1E").ToList();
        }

        /// <summary>
        /// Gets all the building enginners 
        /// </summary>
        public static List<Engineer> GetEngineers()
        {
            return CacheHelper.GetInstance.GetValue("Engineers", new Queries().GetEnginnersDetail, 100, true, null);
           
        }

        /// <summary>
        /// Gets the building based on the locationId
        /// </summary>
        /// <param name="locationId">location id </param>
        /// <returns>list of building info</returns>
        public static List<BuildingInfo> GetBuildings(int locationId)
        {
            return CacheHelper.GetInstance.GetValue("LocationsWithBuildings", new Queries().GetLocationsWithBuildingInfo, 100, true, null)
                .Where(l => l.LocationID == locationId).SelectMany(s => s.BuildingInfo.DistinctBy(d => d.BuildingId)).ToList();
        }


        /// <summary>
        /// Gets the building based on the locationId
        /// </summary>
        /// <returns>list of building info</returns>
        public static List<BuildingInfo> GetBuildings()
        {
            return CacheHelper.GetInstance.GetValue("LocationsWithBuildings", new Queries().GetLocationsWithBuildingInfo, 100, true, null)
                 .SelectMany(s => s.BuildingInfo.DistinctBy(d => d.BuildingId)).ToList();
        }

        /// <summary>
        /// Gets all the building floor info based on building id
        /// </summary>
        /// <param name="buildingId">building info</param>
        /// <returns>list og building infos</returns>
        public static List<BuildingInfo> GetFloors(int buildingId)
        {
            return CacheHelper.GetInstance.GetValue("LocationsWithBuildings", new Queries().GetLocationsWithBuildingInfo, 100, true, null)
                .SelectMany(s => s.BuildingInfo).Where(b => b.BuildingId == buildingId).ToList();
        }


        public static List<Engineer> GetBuildingEngineersDistinct()
        {
            return GetBuildingEngineers().GroupBy(x => x.PSID).Select(y => y.First()).ToList();
        }

        public static List<Engineer> GetEngineersDistinct()
        {
            return GetEngineers().GroupBy(x => x.PSID).Select(y => y.First()).ToList();
        }
        /// <summary>
        /// Returns team info list from cache
        /// </summary>
        /// <returns></returns>
        public static List<Engineer> GetTeamInfo()
        {
            return CacheHelper.GetInstance.GetValue("Teams", new Queries().GetTeamInfo, 100, true, null).ConvertToEngineer();
        }

        /// <summary>
        /// Returns Engineer Type list from cache based on passed teamID
        /// </summary>
        /// <param name="TeamID">TeamID int value</param>
        /// <returns>List of Engineer</returns>
        public static List<Engineer> GetEngineerType(int? TeamID)
        {
            return CacheHelper.GetInstance.GetValue("EngineerTypes", new Queries().GetEngineerType, 100, true, null).ConvertToEngineer().Where(t => TeamID == 1 ? t.SysEngineerTypeID == 1 || t.SysEngineerTypeID == 4 || t.SysEngineerTypeID == 5 : t.SysEngineerTypeID == 1 || t.SysEngineerTypeID == 2 || t.SysEngineerTypeID == 3).ToList();
        }

        public static void SendEmail(string body, string toEmailID, string subject)
        {
            EMailHelper email = new EMailHelper();
            email.Sender = ConfigurationManager.AppSettings["EmailFromAddress"].ToString();

            //if email is not deployed, use dummy email address
            if (Convert.ToBoolean(ConfigurationManager.AppSettings["IsEmailDeployed"]))
                email.Recipient = toEmailID;
            else
            {
                email.Recipient = ConfigurationManager.AppSettings["DummyEmailAddress"].ToString();
            }
            email.RecipientCC = (String.IsNullOrEmpty(ConfigurationManager.AppSettings["EmailCCAddress"].ToString())) ? null : ConfigurationManager.AppSettings["EmailCCAddress"].ToString();
            email.Subject = subject;
            email.Body = body;

            email.Send();
        }

        public static string GetFieldValueFromGrid(ASPxGridView grid, int key, string field)
        {
            return grid.GetRowValuesByKeyValue(key, field).CheckEmptyObj();
        }

        public static int GetTransactionLogDuration()
        {
            return int.Parse(ConfigurationManager.AppSettings["TransactionLogDurationdays"]);
        }

        public static class StringExtensions
        {
            public static bool IsNullOrBlank(string text)
            {
                return text == null || text.Trim().Length == 0;
            }
        }
    }
}