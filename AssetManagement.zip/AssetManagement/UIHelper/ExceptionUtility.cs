﻿using AssetManagementLibrary.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace AssetManagement.UIHelper
{
    // Create our own utility for exceptions 
    public sealed class ExceptionUtility
    {
        // All methods are static, so this can be private 
        private ExceptionUtility()
        { }

        // Log an Exception 
        public static void LogException(Exception exc, string source)
        {
            // Include enterprise logic for logging exceptions 
            // Get the absolute path to the log file 
            string logFile = AppDomain.CurrentDomain.BaseDirectory + "ErrorLog.txt";
           // logFile = HttpContext.Current.Server.MapPath(logFile);

            // Open the log file for append and Append the log
            //StreamAppendr sw = new StreamAppendr(logFile, true);
            StringBuilder sw = new StringBuilder();
            sw.AppendLine(string.Format("********** {0} **********", DateTime.Now));
            sw.AppendLine("UserInfo: " + source);
            if (exc.InnerException != null)
            {
                sw.Append("Inner Exception Type: ");
                sw.AppendLine(exc.InnerException.GetType().ToString());
                sw.Append("Inner Exception: ");
                sw.AppendLine(exc.InnerException.Message);
                sw.Append("Inner Source: ");
                sw.AppendLine(exc.InnerException.Source);
                if (exc.InnerException.StackTrace != null)
                {
                    sw.AppendLine("Inner Stack Trace: ");
                    sw.AppendLine(exc.InnerException.StackTrace);
                }
            }
            sw.Append("Exception Type: ");
            sw.AppendLine(exc.GetType().ToString());
            sw.AppendLine("Exception: " + exc.Message);
            
            sw.AppendLine("Stack Trace: ");
            if (exc.StackTrace != null)
            {
                sw.AppendLine(exc.StackTrace);
                sw.AppendLine();
            }
            File.AppendAllText(logFile,sw.ToString());
        }


        //Log an info
        public static void LogInfo(string error)
        {
            try
            {
                // Include enterprise logic for logging exceptions 
                // Get the absolute path to the log file 
                string logFile = AppDomain.CurrentDomain.BaseDirectory + "LogInfo" + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                // logFile = HttpContext.Current.Server.MapPath(logFile);

                // Open the log file for append and Append the log
                //StreamAppendr sw = new StreamAppendr(logFile, true);
                StringBuilder sw = new StringBuilder();
                sw.AppendLine(string.Format("********** {0} **********", DateTime.Now));
                //sw.AppendLine("UserInfo: " + User.Identity.Name);
                sw.AppendLine(error);
                File.AppendAllText(logFile, sw.ToString());
            }
            catch (Exception ex)
            {

            }
        }

        // Notify System Operators about an exception 
        public static void NotifySystemOps(Exception exc)
        {
            // Include code for notifying IT system operators
        }

        
    }
    
}