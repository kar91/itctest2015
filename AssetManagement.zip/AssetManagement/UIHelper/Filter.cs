﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AssetManagement.UIHelper
{
    public class FilterValues
    {
        public object Name { get; set; }
        public object Value { get; set; }
    }

    public class Filter
    {
        public string Key { get; set; }

        public List<FilterValues> Value { get; set; }
    }
}