﻿using System;
using System.Collections.Generic;
using System.Data;
using AssetManagement.Tasks;
using System.Web;
using System.Reflection;
using System.Data.SqlClient;
using System.Data.Objects;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary;
using AssetManagementLibrary.OtherHelpers;
using AssetManagementLibrary.Entities.Movement;
using System.Web.Routing;
using System.IO;
using AssetManagement.UIHelper;
using System.Web.UI.WebControls;
using AssetManagement.APIController;
using System.Web.Http;

namespace AssetManagement
{
    public class Global : System.Web.HttpApplication
    {
        Queries queryHelper = new Queries();
        protected void Application_Start(object sender, EventArgs e)
        {

            RouteTable.Routes.MapPageRoute("VirtualRoute", System.Configuration.ConfigurationManager.AppSettings["VirtualRoute"].ToString(), "~/Movement/DefaultMovement.aspx");
            RouteTable.Routes.MapPageRoute("SubFolderRoute", System.Configuration.ConfigurationManager.AppSettings["SubFolderRoute"].ToString(), "~/Movement/DefaultMovement.aspx");

            DevExpress.Web.ASPxWebControl.CallbackError += new EventHandler(Application_Error);

            ///Add default locations to Cache
            //CacheHelper.GetInstance.AddValue("DefaultLocation", new Queries().GetDefaultLocationsForCache().ConvertToDefualtLocations(), 100, true, null);
            CacheHelper.GetInstance.AddValue("Engineers", new Queries().GetEnginnersDetail(), 100, true, null);
            CacheHelper.GetInstance.AddValue("Purposes", new Queries().GetPurposeDictionary(), 100, true, null);
            CacheHelper.GetInstance.AddValue("LocationsWithBuildings", new Queries().GetLocationsWithBuildingInfo(), 100, true, null);
            CacheHelper.GetInstance.AddValue("Teams", new Queries().GetTeamInfo(), 100, true, null);
            CacheHelper.GetInstance.AddValue("EngineerTypes", new Queries().GetEngineerType(), 100, true, null);
            CacheHelper.GetInstance.AddValue("MenuAccessItems", new Queries().GetMenuAccessItems(), 100, true, null);
            CacheHelper.GetInstance.AddValue("AssetStatus", new Queries().GetAllAssetStatus(), 100, true, null);

            //RouteConfig.RegisterRoutes(RouteTable.Routes);

            RouteTable.Routes.Ignore("{resource}.axd/{*pathInfo}");

            RouteTable.Routes.MapHttpRoute(
  name: "DefaultApi",
  routeTemplate: "{controller}/{id}",//"api/{controller}/{id}",
  defaults: new { id = System.Web.Http.RouteParameter.Optional }
).RouteHandler = new SessionStateRouteHandler();

        }

        public static String GetIP()
        {
            String ip =
                HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (string.IsNullOrEmpty(ip))
            {
                ip = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            }
            else
            {
                ip = ip.Split(',')[0];

            }

            return ip;
        }

        protected void Session_Start(object sender, EventArgs e)
        {

            var applicationID = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["ApplicationID"]);

            DataSet ds = new DataSet();
            var iploginuser = new List<InputParameters>
                        {
                            new InputParameters {SqlParam = "loginID", ParamValue = User.Identity.Name},
                            new InputParameters {SqlParam = "ApplicationID", ParamValue = applicationID},
                            new InputParameters {SqlParam = "ModeOfAccess", ParamValue = Request.UserAgent},
                            new InputParameters {SqlParam = "UserIP", ParamValue = GetIP()}
                        };
            ds = queryHelper.Getcredentials(iploginuser);

            foreach (DataRow dt in ds.Tables[0].Rows)
            {
                //Session["IsAuthorized"] = dt.Field<Int16>("RoleID"); 
                Session["IsAuthorized"] = 1;
                Session["PSID"] = dt.Field<string>("PSID");
                Session["Username"] = dt.Field<string>("Name");
                Session["Deptid"] = dt.Field<string>("Deptid");
                Session["Grade"] = dt.Field<string>("Grade");
                Session["PendingReview"] = dt.Field<int>("PendingReview");
            }

            //Change According to your testing
            //iploginuser[0].ParamValue = @"ITCINFOTECH\206211"; 

            Session["UserProfile"] = Queries.GetUserProfile(iploginuser);
            //throw new HttpException("Threw an error from Page_Load", 100); 
        }


        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }
        protected void Application_Error(object sender, EventArgs e)
        {

            // Code that runs when an unhandled error occurs
            // Get the exception object.
            Exception exc = Server.GetLastError();

            // Handle HTTP errors
            if (exc!=null && exc.GetType() == typeof(HttpException))
            {
                // The Complete Error Handling Example generates
                // some errors using URLs with "NoCatch" in them;
                // ignore these here to simulate what would happen
                // if a global.asax handler were not implemented.
                if (exc.Message.Contains("NoCatch") || exc.Message.Contains("maxUrlLength"))
                    return;

                //Redirect HTTP errors to HttpError page
                //Server.Transfer("~/Error/HttpErrorPage.aspx");

            }


            // Log the exception and notify system operators
            ExceptionUtility.LogException(exc, Convert.ToString(Session["PSID"]));
            ExceptionUtility.NotifySystemOps(exc);

            Server.ClearError();
            if (exc is HttpException)
            {
                var ex = (HttpException)exc;
                int httpcode = ex.GetHttpCode();
                if (httpcode == 404)
                    Server.Transfer("~/Error/ErrorPage404.html");
                else
                    Server.Transfer("~/Error/ErrorPage500.html");
            }
            else
            {
                Server.Transfer("~/Error/ErrorPage500.html");
            }


        }



        private void LogError(Exception ex)
        {
            try
            {
                Exception CurrentException = Server.GetLastError();
                string ErrorDetails = CurrentException.ToString();

                File.WriteAllText(Server.MapPath("~/ErrorLog.txt"), ErrorDetails);
            }
            catch (Exception)
            {


            }

        }
        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }

    }
}