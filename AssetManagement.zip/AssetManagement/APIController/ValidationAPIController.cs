﻿using AssetManagementLibrary.Entities.Movement;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.WebHost;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Script.Serialization;
using System.Web.SessionState;

namespace AssetManagement.APIController
{
    [System.Web.Http.Authorize]
    public class ValidationsController : ApiController
    {
        public AssetManagementLibrary.Queries QueryHelper
        {
            get
            {
                return new AssetManagementLibrary.Queries();
            }
        }

        //public HPSMdetail GetValidations()
        //{
        //    return new HPSMdetail();
        //}

        [System.Web.Http.HttpGet]
        [System.Web.Http.Route("Validations/{hpsm}/{psid}")]
        public HPSMdetail GetValidations(string hpsm, string psid)
        {
            var recordCount = 0;
            var ipGetDetails = new List<InputParameters>
            {
                new InputParameters {SqlParam = "HPSM", ParamValue = hpsm},
                new InputParameters {SqlParam = "PSID", ParamValue = psid}
            };
            var resultSet = QueryHelper.GetListOfAssetsForEndUser(new List<InputParameters> { new InputParameters { SqlParam = "UserPSID", ParamValue = psid } });
            List<UserAssetDetail> lstAsset = new List<UserAssetDetail>();
            var list = (List<AssetTranExtn>)HttpContext.Current.Session["datatobind_grdAssetSplit"];
            if (list != null && list.Count>0 && list.Any(x=>x.EndUserId==psid))
            {
                resultSet.AddRange(list);
            }

                //list of asset


                foreach (var dr in resultSet)
                {
                    UserAssetDetail obj = new UserAssetDetail();
                    obj.AssetTranID = dr.AssetTranId;
                obj.AssetType = dr.AssetType.ToLower();
                    obj.HPSMNo = dr.HpsmNo;
                    obj.SerialNumber = dr.SerialNo;
                    obj.StatusName = dr.StatusName;
                    lstAsset.Add(obj);
                }
                
            return (new HPSMdetail { count = lstAsset.Count(), hpsmno = hpsm, userid = psid, lstuad =lstAsset });
        }

        [System.Web.Http.HttpGet]
        [System.Web.Http.Route("Validations/{assetTranId}/{comments}")]
        public Result CancelAsset(string assetTranId, string comments, string psID)
        {
            var ipCancelAsset = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AssetTranId", ParamValue = assetTranId},
                new InputParameters {SqlParam = "Comments", ParamValue = comments},
                new InputParameters {SqlParam = "PSID", ParamValue = psID}
            };
           var result =  QueryHelper.CancelAssetRequest(ipCancelAsset);
           return (new Result { data = result });
        }

        public List<DirectAssetType> GetValidations()
        {
            List<DirectAssetType> lst = new List<DirectAssetType>();

            var ds = QueryHelper.GetSysAssetTypeForDirect();
            var myData = ds.Tables[0].AsEnumerable().Select(r => new DirectAssetType
            {
                SysAssetTypeID = r.Field<int>("SysAssetTypeID"),
                AssetType = r.Field<string>("AssetType").ToLower(),
                AssetCode = r.Field<string>("AssetCode")
            });

            lst = myData.ToList();

            return lst;
        }


    }

    
    public class DirectAssetType
    {
        public int SysAssetTypeID { get; set; }
        public string AssetType { get; set; }
        public string AssetCode { get; set; }
    } 

    public class Result
    {
        public bool data { get; set; }
    }

    public class HPSMdetail
    {
        public int count { get; set; }
        public string hpsmno { get; set; }
        public string userid { get; set; }

        public List<UserAssetDetail> lstuad { get; set; }
    }

    public class UserAssetDetail
    {
        public int AssetTranID { get; set; }
        public string HPSMNo { get; set; }
        public string SerialNumber { get; set; }
        public string AssetType { get; set; }
        public string StatusName { get; set; }

        public string NAME { get; set; }

    }

    public class SessionableControllerHandler : HttpControllerHandler, IRequiresSessionState
    {
        public SessionableControllerHandler(RouteData routeData)
            : base(routeData)
        { }
    }

    public class SessionStateRouteHandler : IRouteHandler
    {
        IHttpHandler IRouteHandler.GetHttpHandler(RequestContext requestContext)
        {
            return new SessionableControllerHandler(requestContext.RouteData);
        }
    }
}
