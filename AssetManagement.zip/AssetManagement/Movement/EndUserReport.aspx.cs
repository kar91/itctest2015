﻿using AssetManagement.Tasks;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class EndUserReport : AssetTrackerBasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            LoadGrid(false);
            if (!IsPostBack)
                cmbfilter.SelectedItem.Value = 0;
        }


        protected void LoadGrid(bool? ischecked = null, object fromdate = null, object toxdate = null)
        {
            int? check = null;
            if (cmbfilter.SelectedItem.Value.ToString() == "0")
            {
                check = 0;
                fromdate = null;
                toxdate = null;
            }
            else
            {
                if (frmdate.Value != null && todate.Value != null)
                {
                    check = null;
                    fromdate = frmdate.Value;
                    toxdate = todate.Value;
                }
            }
            var ipreport = new List<InputParameters>
            {
                new InputParameters {SqlParam = "ischecked", ParamValue = check},
                new InputParameters {SqlParam = "StartDate", ParamValue = fromdate},
                new InputParameters {SqlParam = "EndDate", ParamValue = toxdate},
            };

            var ds = QueryHelper.GetUserReport(ipreport);
            enduserreport.DataSource = ds;
            enduserreport.DataBind();
            var summary = GetRequestSummary(ds);

            lbltotal.InnerText = summary.RequestCount.ToString();
            lbldeployed.InnerText = summary.Deployed.ToString();

            lbldeployedpending.InnerText = summary.DeploymentPending.ToString();
            lbluserack.InnerText = summary.UserAcknowledged.ToString(); ;

            lbluserpending.InnerText = summary.UserAcknowledgmentPending.ToString();
            lblrejectprogress.InnerText = summary.RejectInProgress.ToString();
            lblrejected.InnerText = summary.Rejected.ToString();

        }

        protected void enduserreport_CustomColumnDisplayText(object sender, DevExpress.Web.ASPxGridViewColumnDisplayTextEventArgs e)
        {


            if (e.Column.FieldName == "IsDeployed")
            {
                if (e.Value.ToString() == "1")
                {

                    e.DisplayText = "Deployed";
                }
                else if (e.GetFieldValue("Reject").ToString() == "1")
                {
                    e.DisplayText = "Rejected";
                }

                else
                {
                    e.DisplayText = "Pending";
                }
            }
            //IsRejectInProgress,Reject
            if (e.Column.FieldName == "EndUserAck")
            {

                if (e.Value.ToString() == "1")
                {

                    e.DisplayText = "User Acknowledged";

                }
                else
                {
                    if (e.GetFieldValue("IsDeployed").ToString() == "0")
                    {
                        if (e.GetFieldValue("EndUserReject").ToString() == "1")
                            e.DisplayText = "User Rejected";
                        else if (e.GetFieldValue("Reject").ToString() == "1")
                            e.DisplayText = "Rejected";
                        else if (e.GetFieldValue("IsRejectInProgress").ToString() == "1")
                            e.DisplayText = "Reject in Progress";
                        else
                            e.DisplayText = "Deployment Pending";

                    }
                    else
                    {
                        if (e.GetFieldValue("IsRejectInProgress").ToString() == "1")
                            e.DisplayText = "Reject in Progress";
                        else if (e.GetFieldValue("Reject").ToString() == "1")
                            e.DisplayText = "Rejected";
                        else if (e.GetFieldValue("EndUserAckPending").ToString() == "1")
                            e.DisplayText = "User Acknowledgemnt Pending";
                        else
                            e.DisplayText = "N/A";
                    }

                }
            }
            if (e.Column.FieldName == "IsRejectInProgress")
            {
                if (e.Value.ToString() == "1")
                {
                    e.DisplayText = "Reject in Progress";
                }
                else if (e.GetFieldValue("Reject").ToString() == "1")
                {
                    e.DisplayText = "Rejected";
                }
                else
                {
                    e.DisplayText = "N/A";

                }
            }

            if (e.Column.FieldName == "Reject")
            {
                if (e.Value.ToString() == "1")
                {
                    e.DisplayText = "Asset Rejected";
                }
                else
                {
                    e.DisplayText = "N/A";

                }
            }
        }



        protected void submit_Click(object sender, EventArgs e)
        {

        }

        protected void cmbfilter_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cmbfilter.SelectedItem.Value.ToString() == "1")
            {
                frmdate.Enabled = true;
                todate.Enabled = true;
                submit.Enabled = true;
                divfrm.Style["Display"] = "block";
                divto.Style["Display"] = "block";

            }
            else
            {
                frmdate.Value = null;
                frmdate.Enabled = false;
                todate.Enabled = false;

                divfrm.Style["Display"] = "none";
                divto.Style["Display"] = "none";

            }
        }

        protected void Export_Click(object sender, ImageClickEventArgs e)
        {
            LoadGrid();
            var exportOptions = new DevExpress.XtraPrinting.XlsExportOptionsEx();
            exportOptions.TextExportMode = DevExpress.XtraPrinting.TextExportMode.Text;
            exportOptions.ExportType = DevExpress.Export.ExportType.WYSIWYG;
            GridViewExporter.FileName = "EndUserAcknowledgementReport_" + cmbfilter.SelectedItem.Text;
            GridViewExporter.WriteXlsToResponse(exportOptions);
        }

        private RequestSummary GetRequestSummary(DataSet ds)
        {
            var requestSummary = new RequestSummary();
            var table = ds.Tables[0].AsEnumerable();

            table.AsEnumerable().ToList().ForEach(x =>
            {
                var rejectInProgress = x.Field<int>("IsRejectInProgress");
                var rejected = x.Field<int>("Reject");
                if (rejected == 1 || rejectInProgress == 1)
                    x.SetField("DeployedPending", 0);
            });

            requestSummary.RequestCount = table.Count();
            requestSummary.Deployed = table.Sum(x => x.Field<int>("IsDeployed"));
            requestSummary.DeploymentPending = table.Sum(x => x.Field<int>("DeployedPending")); ;
            requestSummary.RejectInProgress = table.Sum(x => x.Field<int>("IsRejectInProgress"));
            requestSummary.Rejected = table.Sum(x => x.Field<int>("Reject"));
            requestSummary.UserAcknowledged = table.Sum(x => x.Field<int>("EndUserAck"));
            requestSummary.UserAcknowledgmentPending = table.Sum(x => x.Field<int>("EndUserAckPending")); ;

            requestSummary.DeploymentPending =Math.Abs ( (requestSummary.DeploymentPending ));

            //requestSummary.UserAcknowledgmentPending = requestSummary.RequestCount-(requestSummary.UserAcknowledged + requestSummary.RejectInProgress + requestSummary.Rejected) < 0 ? 0 : requestSummary.RequestCount - (requestSummary.UserAcknowledged + requestSummary.RejectInProgress + requestSummary.Rejected);

            //requestSummary.DeploymentPending = ((requestSummary.RequestCount ) - ((requestSummary.Deployed)+ (requestSummary.Rejected))) <0?0 : ((requestSummary.RequestCount) - ((requestSummary.Deployed) + (requestSummary.Rejected)));

            return requestSummary;
        }

        class RequestSummary
        {
            public int RequestCount { get; set; }
            public int Deployed { get; set; }
            public int DeploymentPending { get; set; }
            public int UserAcknowledged { get; set; }
            public int UserAcknowledgmentPending { get; set; }
            public int RejectInProgress { get; set; }
            public int Rejected { get; set; }
        }
    }
}