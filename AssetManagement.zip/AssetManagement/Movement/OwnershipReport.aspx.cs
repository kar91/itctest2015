﻿using AssetManagement.Tasks;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class OwnsershipReport : AssetTrackerBasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Ownership Report";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "AssetLead", "Approver", "Tier1Lead" };
            IsInGroup();


            if (!Page.IsPostBack)
            {
                frmdate.MaxDate = DateTime.Today;
                todate.MaxDate = DateTime.Today;

                LoadGrid(true);
                period.Visible = false;
            }

            if (TranGrid.IsCallback)
            {
                LoadGrid(false);
            }
        }

        /// <summary>
        /// On export button click, print the data into excel file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Export_Click(object sender, ImageClickEventArgs e)
        {
            LoadGrid();
            GridViewExporter.FileName = "OwnershipReport_" + DateTime.Now.Date;
            GridViewExporter.WriteXlsToResponse();
        }

        /// <summary>
        /// On search button click, load data into grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SearchByTranDt_Click(object sender, EventArgs e)
        {
            LoadGrid();
        }

        /// <summary>
        /// Load data into gridview based on SerialNo or Date range/BuildingID passed
        /// </summary>
        protected void LoadGrid(bool showAll = false)
        {
            var teamFilter = Request.QueryString["teamfilter"];

            var ipTranGrid = new List<InputParameters>
                {
                    new InputParameters {SqlParam = "FromDt", ParamValue = showAll ? null : frmdate.Value},
                    new InputParameters {SqlParam = "ToDt", ParamValue = showAll ? null : todate.Value}
                };

            var dataset = QueryHelper.GetAssetsForOwnershipReport(ipTranGrid);
            
            if (teamFilter != null)
            {
                var dataview = dataset.Tables[0].AsEnumerable().Where(x => x.Field<string>("TeamType").ToLower().Trim() == teamFilter.ToLower().Trim()).AsDataView();
                dataset = new DataSet();
                dataset.Tables.Add(dataview.ToTable());
                //dataset.Tables.Add(dataview.Table.Copy());
            }
            
               
            TranGrid.DataSource = dataset;
            TranGrid.DataBind();
        }



        protected void TranGrid_CustomCallback(object sender, DevExpress.Web.ASPxGridViewCustomCallbackEventArgs e)
        {
            LoadGrid(true);
        }

        protected void cmbfilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbfilter.Value.ToString() == "1")
            {
                period.Visible = true;
            }
            else
            {
                period.Visible = false;
                LoadGrid(true);
            }
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            LoadGrid(false);
        }

    }
}