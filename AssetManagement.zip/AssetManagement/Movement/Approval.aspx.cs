﻿using AssetManagement.Tasks;
using AssetManagementLibrary;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.Entities.Movement;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AssetManagement.UIHelper;

namespace AssetManagement.Movement
{
    public partial class Approval : AssetTrackerBasePage
    {

        #region Event Handlers

        /// <summary>
        /// Page label is set to Approval for Master page, Access Group validation check, Purpose dropdown and Grid data are filled
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Approval";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "Approver" };
            IsInGroup();

            //Purpose dropdown is populated only once on page load
            if (!Page.IsPostBack)
            {
                Session["ApprovalGridDatasource"] = null;
                LoadGrid();
            }

            //When page is in Postback, call LoadGrid function to refresh grid data
            if (ApprovalGrid.IsCallback)
            {
                if (Request.Params["__CALLBACKPARAM"].Contains("PAGERONCLICK") || Request.Params["__CALLBACKPARAM"].Contains("APPLYCOLUMNFILTER") || Request.Params["__CALLBACKPARAM"].Contains("SORT"))
                {
                    LoadGrid();
                }
            }
        }




        /// <summary>
        /// Custom action button is rendered depending upon next status for any particular request row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ApprovalGrid_HtmlRowCreated(object sender, DevExpress.Web.ASPxGridViewTableRowEventArgs e)
        {
            //if current row has data
            if (e.RowType == DevExpress.Web.GridViewRowType.Data)
            {
                string KeyVal = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetTranId").ToString();
                string[] splitObj = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "NextStageInfo").ToString().Split('|');
                string purposeName = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "PurposeName").ToString();

                //Loop through possible next stage available for request
                foreach (var item in splitObj)
                {
                    var x = item.Split('-')[0];
                    ASPxButton CustBtn = new ASPxButton();
                    CustBtn.ID = String.Format("CustBtn{0}{1}", KeyVal, item.Split('-')[0]);
                    CustBtn.Text = item.Split('-')[1];

                    switch (CustBtn.Text)
                    {
                        case "Approve": CustBtn.CssClass = "custom"; CustBtn.ImageUrl = "../Images/acknowledge.png"; break;
                        default:
                            break;
                    }


                    CustBtn.Attributes.Add("AssetTranID", KeyVal);
                    CustBtn.Attributes.Add("NextStatusID", item.Split('-')[0]);
                    CustBtn.Attributes.Add("PurposeName", purposeName);
                    CustBtn.AutoPostBack = false;

                    CustBtn.Image.Width = 20;
                    CustBtn.Image.Height = 20;
                    CustBtn.ClientSideEvents.Click = "CustomButtonOnClick";
                    e.Row.Cells[17].Controls.Add(CustBtn);
                }
            }

        }



        /// <summary>
        /// Update status of selected request, AssetTranID and next SysPurposeStageID is passed from the button clicked attributes in PerformCallback event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ApprovalGrid_CustomCallback(object sender, DevExpress.Web.ASPxGridViewCustomCallbackEventArgs e)
        {
            AssetManagementLibrary.Queries qryhelper = new Queries();
            var ipUpdateAssetStatus = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AssetTranID", ParamValue = int.Parse(e.Parameters.Split('|')[0])},
                new InputParameters {SqlParam = "SysPurposeStageID", ParamValue = int.Parse(e.Parameters.Split('|')[1])},
                new InputParameters {SqlParam = "ModBy", ParamValue = GetPSID},
                new InputParameters {SqlParam = "Comments", ParamValue = e.Parameters.Split('|')[3].ToString()}
            };
            var result = qryhelper.UpdateForApproval(ipUpdateAssetStatus);

            //if (result && "Asset Correction" == e.Parameters.Split('|')[2])
            //{
            //    qryhelper = new Queries();
            //    qryhelper.UpdateAssetCorrection(ipUpdateAssetStatus.Where(x => x.SqlParam == "AssetTranID").ToList());
            //}
            LoadGrid();
        }

        #endregion



        #region User Defined functions

        /// <summary>
        /// Load data into gridview, check selected Purpose or HpsmNo, fill HpsmNo dropdown data after every refresh
        /// </summary>
        /// <param name="purposeID"></param>
        /// <param name="HpsmNo"></param>
        protected void LoadGrid()
        {
            int? purposeID = null;
            string HpsmNo = null;

            var ipGetAssetsForApproval = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = GetSessionValue<UserProfile>("UserProfile").UserGroups.FirstOrDefault().GroupID},
                new InputParameters {SqlParam = "SysPurposeID", ParamValue = purposeID},
                new InputParameters {SqlParam = "HpsmNo", ParamValue = HpsmNo},
                new InputParameters {SqlParam = "UserPSID", ParamValue = GetPSID}
            };
            var lstAssetTranExtns = Extensions.RemoveDuplicates(QueryHelper.GetAssetsForApproval(ipGetAssetsForApproval));
            ApprovalGrid.DataSource = lstAssetTranExtns;
            ApprovalGrid.DataBind();

            SetComboxValueInSession("ApprovalGridDatasource", "hpsmno",
                lstAssetTranExtns.GroupBy(h => h.HpsmNo).Select(hp => hp.First()).Select(s => new FilterValues { Name = s.HpsmNo, Value = s.HpsmNo }).ToList());
            SetComboxValueInSession("ApprovalGridDatasource", "purpose",
                lstAssetTranExtns.GroupBy(h => h.SysPurposeId).Select(hp => hp.First()).Select(s => new FilterValues { Name = s.PurposeName, Value = s.SysPurposeId }).ToList());

        }


        public void BindData(ASPxComboBox combo, string valueField, string textField, object data)
        {
            combo.DataSource = data;
            combo.ValueField = valueField;
            combo.TextField = textField;
            combo.DataBind();
        }

        #endregion

        protected void Export_Click(object sender, ImageClickEventArgs e)
        {
            LoadGrid();
            GridViewExporter.FileName = "PendingApprovalReport_" + DateTime.Now.Date;
            GridViewExporter.WriteXlsToResponse();
        }



    }
}