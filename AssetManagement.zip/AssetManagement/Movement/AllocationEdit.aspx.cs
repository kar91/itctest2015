﻿using AssetManagement.Tasks;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.Entities.Movement;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class AllocationEdit : AssetTrackerBasePage
    {

        #region Event Handlers

        /// <summary>
        /// Page load event handler, check page access, fetch assetTranID from query string to load data into form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Return if AssetTranID missing from querystring
            if (!IsValidRequest())
                return;

            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Allocation Edit";
            }

            //check user access group for page access
            AccessGroups = new List<string> { "AssetLead" };
            IsInGroup();

            //If page is in postback, fetch assetTranID and fill asset details into Session object to be used throughout
            if (!Page.IsPostBack)
            {
                var keyField = int.Parse(Request.QueryString["AssetTranId"].ToString());
                var ipGetAssetsForAallocationEdit = new List<InputParameters>
                {
                    new InputParameters {SqlParam = "AssetTranID", ParamValue = keyField},
                    new InputParameters {SqlParam = "AccessGroupID", ParamValue = GetGroupID}
                };
                var assetTranExtn = Extensions.RemoveDuplicates(QueryHelper.GetAssetsForAllocationEdit(ipGetAssetsForAallocationEdit)).FirstOrDefault();
                Session["assetToBeAlloc"] = assetTranExtn;

                //Set default values and freeze end user fields
                var disableLabels = new Dictionary<ASPxLabel, string>() {
                    {HpsmNo,assetTranExtn.HpsmNo},
                    {Purpose,assetTranExtn.PurposeName},
                    {Requestor, assetTranExtn.CreatedByPsid},
                    {SerialNo, assetTranExtn.SerialNo},
                    {AssetType, assetTranExtn.AssetType}
                };
                SetDefaultForLabel(disableLabels);

                var disableTextBox = new Dictionary<ASPxTextBox, string>() { 
                    {FromBuilding, assetTranExtn.FromBuilding},
                    {FromArea, assetTranExtn.FromArea},
                    {FromAreaID, assetTranExtn.FromFloorId.ToString()},
                    {ToNameTxtbox, assetTranExtn.ToName},
                    {ToCubicleNoTxtbox, assetTranExtn.ToCubicleNo},
                    {ToBuildingTxtbox, assetTranExtn.ToBuilding},
                    {ToAreaTxtbox, assetTranExtn.ToArea}
                };
                SetDefaultForTextbox(disableTextBox);
                SetDefaultForCombobox(ToPsidCombo, assetTranExtn.ToPsid);
                ToPsidCombo.Enabled = false;
                ToCubicleid.Set("ToCubicleId", assetTranExtn.ToCubicleId);

                //fill data into Cubicle dropdown
                FillCubicleComboBox();

                //if purpose is of type B2B or Asset handover, then movement engg is not required
                if ((assetTranExtn.PurposeName.ToLower().Replace(" ", "") == "buildingtobuilding" || assetTranExtn.PurposeName.ToLower().Replace(" ", "") == "assetre-deployment" || assetTranExtn.PurposeName.ToLower().Replace(" ", "") == "assethandover") && (assetTranExtn.AssetType != "Laptop"))
                {
                    MovementEnggCombo.NullText = "Not required";
                    MovementEnggCombo.Enabled = false;
                }
                MovementEnggCombo.IsValid = true;
            }
            RenderCustomActionBtn((AssetTranExtn)Session["assetToBeAlloc"]);


            FillPsidComboBox();
        }


        /// <summary>
        /// Update status of submitted request, Redirect user to AssetAllocation page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CustBtn_Click(object sender, EventArgs e)
        {
            var ipUpdateAssetAlloc = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AssetTranID", ParamValue = ((AssetTranExtn)Session["assetToBeAlloc"]).AssetTranId},
                new InputParameters {SqlParam = "ToPSID", ParamValue = ToPsidCombo.Value},
                new InputParameters {SqlParam = "ToCubicleID", ParamValue = ToCubicleid.Get("ToCubicleId")},
                new InputParameters {SqlParam = "FromFloorID", ParamValue = int.Parse(FromAreaID.Text)},
                new InputParameters {SqlParam = "FromCubicleID", ParamValue = cmbcubicle.Value},
                new InputParameters {SqlParam = "FromPSID", ParamValue = FromPsidCombo.Value},
                new InputParameters {SqlParam = "MovementEnggID", ParamValue = MovementEnggCombo.Value},
                new InputParameters {SqlParam = "UserPSID", ParamValue = GetPSID},
                new InputParameters {SqlParam = "SysPurposeStageID", ParamValue = int.Parse(((ASPxButton)sender).Attributes["NextStatusID"])}
            };
            if (QueryHelper.UpdateAssetAllocation(ipUpdateAssetAlloc))
            {
                Response.Redirect("AssetAllocation.aspx");
            }
        }


        /// <summary>
        /// for storing and retreiving hidden column value in multi-column combobox for ToPsid dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ToPsidCombo_CustomJSProperties(object sender, CustomJSPropertiesEventArgs e)
        {
            ArrayList listCID = new ArrayList();
            ArrayList listFID = new ArrayList();
            foreach (ListEditItem item in ToPsidCombo.Items)
            {
                listCID.Add(item.GetValue("ToCubicleId"));
                listFID.Add(item.GetValue("ToFloorId"));
            }
            e.Properties["cpHiddenToCubicle"] = listCID;
            e.Properties["cpHiddenToFloor"] = listFID;
        }


        #endregion



        #region User Defined Functions

        /// <summary>
        /// Fetch Employee details from GetUserDetails method and fill ToPsid, FromPsid, MovementEngg dropdown
        /// </summary>
        private void FillPsidComboBox()
        {
            var ipGetUserDetails = new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserPSID", ParamValue = string.Empty},
                new InputParameters {SqlParam = "CubicleID", ParamValue = null}
            };
            var ds = QueryHelper.GetUserDetails(ipGetUserDetails);
            ToPsidCombo.DataSource = ds;
            ToPsidCombo.DataBind();

            

            var source = UIHelper.Helper.GetTier1LeadEngineers();
            FromPsidCombo.DataSource = source;
            FromPsidCombo.DataBind();

            if (source.Any(x => x.IsDefault))
                FromPsidCombo.SelectedIndex = source.IndexOf(source.FirstOrDefault(z => z.IsDefault));

            var AssetLeadSource = UIHelper.Helper.GetAssetLeadEngineers();
            MovementEnggCombo.DataSource = AssetLeadSource;
            MovementEnggCombo.DataBind();

            if(AssetLeadSource.Any(x=>x.IsDefault))
                MovementEnggCombo.SelectedIndex = AssetLeadSource.IndexOf(AssetLeadSource.FirstOrDefault(z => z.IsDefault));
        }


        /// <summary>
        /// Fetch Cubicle details based on Area and fill To Cubicle dropdown
        /// </summary>
        private void FillCubicleComboBox()
        {
            var ipcubiclebasedonarea = new List<InputParameters>
            {
                new InputParameters {SqlParam = "BuildingFloorID", ParamValue = ((AssetTranExtn)Session["assetToBeAlloc"]).FromFloorId}
            };
            var source = QueryHelper.GetCubicleBasedOnArea(ipcubiclebasedonarea);
            var datSet = source.Tables[0].AsEnumerable().Select(x => x).ToList();

            cmbcubicle.DataSource = source;
            cmbcubicle.TextField = "CubicleNo";
            cmbcubicle.ValueField = "CubicleID";
            cmbcubicle.DataBind();

            if (datSet.Count == 1)
                cmbcubicle.SelectedIndex = 1;

        }


        /// <summary>
        /// Custom action button is rendered depending upon next status of current request
        /// </summary>
        private void RenderCustomActionBtn(AssetTranExtn sessionAssetTranExtn)
        {
            foreach (var item in sessionAssetTranExtn.NextStages)
            {
                ASPxButton CustBtn = new ASPxButton();
                CustBtn.ID = String.Format("CustBtn{0}", sessionAssetTranExtn.QRCode);
                CustBtn.Text = item.PurposeStageName;
                CustBtn.CssClass = "custom";
                CustBtn.Attributes.Add("AssetTranID", sessionAssetTranExtn.AssetTranId.ToString());
                CustBtn.Attributes.Add("NextStatusID", item.PurposeStageID.ToString());
                CustBtn.AutoPostBack = true;
                CustBtn.ImageUrl = "../Images/acknowledge.png";
                CustBtn.Image.Width = 20;
                CustBtn.Image.Height = 20;
                CustBtn.Click += CustBtn_Click;
                divStatusBtn.Controls.Add(CustBtn);
            }
        }



        /// <summary>
        /// Check if AssetTranID is in query string or not
        /// </summary>
        /// <returns>If invalid, return false else return true</returns>
        private bool IsValidRequest()
        {
            if (Request.QueryString["AssetTranId"] == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }


        /// <summary>
        /// Set default values for label type control
        /// </summary>
        /// <param name="label">ASPxLabel</param>
        /// <param name="val">String value</param>
        private void SetDefaultForLabel(Dictionary<ASPxLabel, string> keyValues)
        {
            keyValues.ToList().ForEach(x => x.Key.Text = x.Value);
        }


        /// <summary>
        /// Set default values for textbox type control
        /// </summary>
        /// <param name="txtbox">ASPxTextBox</param>
        /// <param name="val">String value</param>
        private void SetDefaultForTextbox(Dictionary<ASPxTextBox,string> keyValues)
        {
            keyValues.ToList().ForEach(x => x.Key.Text = x.Value);
            keyValues.ToList().ForEach(x => x.Key.Enabled = false); 
        }


        /// <summary>
        /// Set default values for combobox type control
        /// </summary>
        /// <param name="combo">ASPxComboBox</param>
        /// <param name="val">String value</param>
        private void SetDefaultForCombobox(ASPxComboBox combo, string val)
        {
            combo.Value = val;
            combo.Enabled = true;
        }


        #endregion

        

    }
}