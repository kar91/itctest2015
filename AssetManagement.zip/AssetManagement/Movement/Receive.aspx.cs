﻿using AssetManagement.Tasks;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.OtherHelpers;
using AssetManagementLibrary.Entities.Movement;
using AssetManagementLibrary;
using AssetManagement.UIHelper;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;

namespace AssetManagement.Movement
{
    public partial class Receive : AssetTrackerBasePage
    {
        #region Event Handlers

        /// <summary>
        /// Page label is set to Receive for Master page, Access Group validation check, Purpose dropdown and Grid data are filled
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Receive";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "AssetLead", "Tier1Lead" };
            IsInGroup();

            //Purpose dropdown is populated only once on page load
            if (!Page.IsPostBack)
            {
                
                LoadGrid();
            }

            //When page is in Postback, call LoadGrid function to refresh grid data
            if (ReceiveGrid.IsCallback)
            {
                {
                    LoadGrid();
                }
            }
        }




        /// <summary>
        /// Custom action button is rendered depending upon next status for any particular request row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ReceiveGrid_HtmlRowCreated(object sender, DevExpress.Web.ASPxGridViewTableRowEventArgs e)
        {
            //if current row has data
            if (e.RowType == DevExpress.Web.GridViewRowType.Data)
            {
                string KeyVal = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetTranId").ToString();
                string[] splitObj = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "NextStageInfo").ToString().Split('|');
                var comments = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "Comments") == null ? "null" : ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "Comments").ToString();
                var AssetType = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetType").ToString();
                string assetdata = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "HpsmNo").ToString() + '|' + ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "SerialNo").ToString() + '|' + ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetType").ToString();

                //Boolean IsDirect = Convert.ToBoolean(((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "IsDirectDeploy").ToString());

                //Loop through possible next stage available for request
                foreach (var item in splitObj)
                {
                    ASPxButton CustBtn = new ASPxButton();
                    CustBtn.ID = String.Format("CustBtn{0}{1}", KeyVal, item.Split('-')[0]);
                    CustBtn.Text = item.Split('-')[1];

                    switch (CustBtn.Text)
                    {
                        case "AL Received": CustBtn.CssClass = "custom"; CustBtn.ImageUrl = "../Images/acknowledge.png"; CustBtn.Attributes.Add("comments", comments); break;
                        case "AL_Deploy": CustBtn.CssClass = "custom"; CustBtn.ImageUrl = "../Images/acknowledge.png"; CustBtn.Attributes.Add("comments", comments); break;
                        case "BE_Allocate": CustBtn.CssClass = "custom"; CustBtn.ImageUrl = "../Images/acknowledge.png"; CustBtn.Attributes.Add("comments", comments); break;
                        case "T1L_Received": CustBtn.CssClass = "custom"; CustBtn.ImageUrl = "../Images/acknowledge.png"; CustBtn.Attributes.Add("comments", comments); break;
                        case "T1L_Reject": CustBtn.CssClass = "reject"; CustBtn.ImageUrl = "../Images/rejecticon.png"; CustBtn.Attributes.Add("type", "reject"); CustBtn.Attributes.Add("comments", comments); break;
                        default:
                            break;
                    }
                    CustBtn.Attributes.Add("AssetTranID", KeyVal);
                    CustBtn.Attributes.Add("NextStatusID", item.Split('-')[0]);
                    CustBtn.Attributes.Add("status", item.Split('-')[1]);

                    CustBtn.Attributes.Add("AssetType", AssetType);
                    CustBtn.Attributes.Add("content", assetdata);

                    CustBtn.AutoPostBack = false;
                    CustBtn.Image.Width = 20;
                    CustBtn.Image.Height = 20;
                    CustBtn.ClientSideEvents.Click = "CustomButtonOnClick";
                    e.Row.Cells[13].Controls.Add(CustBtn);
                }
            }
        }


        /// <summary>
        /// Update status of selected request
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ReceiveGrid_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            //UpdateStatus(int.Parse(e.Parameters.Split('|')[0]), int.Parse(e.Parameters.Split('|')[1]), GetPSID);
            string comments = e.Parameters.Split('|')[2].ToString() == "null" ? null : e.Parameters.Split('|')[2].ToString();

            ASPxGridView grid = sender as ASPxGridView;
            int key = int.Parse(e.Parameters.Split('|')[0]);

            AssetManagementLibrary.Queries qryhelper = new Queries();
            var ipUpdateAssetStatus = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AssetTranID", ParamValue = int.Parse(e.Parameters.Split('|')[0])},
                new InputParameters {SqlParam = "SysPurposeStageID", ParamValue = int.Parse(e.Parameters.Split('|')[1])},
                new InputParameters {SqlParam = "ModBy", ParamValue = GetPSID},
                new InputParameters {SqlParam = "Comments", ParamValue = (comments == null ? null : GetPSID.ToString() + ":T1L: " + comments)}
            };
            var status = e.Parameters.Split('|')[3].ToString();

            if (qryhelper.UpdateForReceive(ipUpdateAssetStatus) && (status == "AL_Deploy"))
            {
                var source = (List<AssetTranExtn>)grid.DataSource;
                if (source != null)
                {
                    var value = source.Where(x => x.AssetTranId == key).FirstOrDefault();
                    //string HpsmNo = Helper.GetFieldValueFromGrid(grid, key, "HpsmNo");
                    string MailSubject = ConfigurationManager.AppSettings["EndUserDeploymentMailSubject"].ToString() + " - " + value.HpsmNo;

                    SendMail(value.ToName, value.ToBuilding, value.ToArea, value.ToCubicleNo, value.HpsmNo, value.AssetType, value.SerialNo, value.ToEmailID, MailSubject);
                }
            }

            LoadGrid();
        }

        #endregion



        #region User defined methods

        /// <summary>
        /// when AL_Deploy, send email via async task to end user notifying about asset details, MailTemplate used for mail body
        /// </summary>
        /// <param name="ToName"></param>
        /// <param name="ToBuilding"></param>
        /// <param name="ToArea"></param>
        /// <param name="ToCubicleNo"></param>
        /// <param name="HpsmNo"></param>
        /// <param name="AssetType"></param>
        /// <param name="SerialNo"></param>
        /// <param name="ToEmailID"></param>
        private void SendMail(string ToName, string ToBuilding, string ToArea, string ToCubicleNo, string HpsmNo, string AssetType, string SerialNo, string ToEmailID, string subject)
        {
            Task.Factory.StartNew(() =>
            {
                try
                {
                    string mailBody = "";

                    using (var reader = new StreamReader(Server.MapPath("~/Templates/MailTemplate.html")))
                    {
                        mailBody = String.Format(reader.ReadToEnd(), ToName, ToBuilding, ToArea, ToCubicleNo, HpsmNo, AssetType, SerialNo);
                    }

                    UIHelper.Helper.SendEmail(mailBody, ToEmailID, subject);
                }
                catch (Exception)
                {

                }
            });
        }


        /// <summary>
        /// Load data into gridview, fill HpsmNo dropdown data after every refresh
        /// </summary>
        /// <param name="purposeID"></param>
        /// <param name="HpsmNo"></param>
        protected void LoadGrid()
        {
            int? purposeID = null;
            string HpsmNo = null;

            var ipGetAssetsForReceive = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = GetSessionValue<UserProfile>("UserProfile").UserGroups.FirstOrDefault().GroupID},
                new InputParameters {SqlParam = "SysPurposeID", ParamValue = purposeID},
                new InputParameters {SqlParam = "HpsmNo", ParamValue = HpsmNo},
                new InputParameters {SqlParam = "UserPSID", ParamValue = GetPSID}
            };
            var lstAssetTranExtns = Extensions.RemoveDuplicates(QueryHelper.GetAssetsForReceive(ipGetAssetsForReceive));
            ReceiveGrid.DataSource = lstAssetTranExtns;
            ReceiveGrid.DataBind();
        }


        #endregion



    }
}