﻿using AssetManagement.Tasks;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class ItemSummaryReport : AssetTrackerBasePage
    {
        #region Event Handlers

        /// <summary>
        /// Page load event handler, check for page access, Load grid data, set default date to today
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Item Summary Report";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "AssetLead", "Approver", "Tier1Lead" };
            IsInGroup();

            if (!Page.IsPostBack)
            {
                frmdate.MaxDate = DateTime.Today;
                todate.MaxDate = DateTime.Today;

                LoadGrid(true);
                period.Visible = false;
                SearchByPsid.Visible = false;
            }

            //Fill engineer psid combobox, called everytime a search is made 
            if (CmbUsers.IsCallback)
                if (Request.Params["__CALLBACKID"].Contains("ctl00$ContentPlaceHolder1$CmbUsers"))
                    FillUsersComboBox(CmbUsers);

            if (TranGrid.IsCallback)
            {
                LoadGrid();
            }
        }

        /// <summary>
        /// Export button click event handler, export grid data to excel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Export_Click(object sender, ImageClickEventArgs e)
        {
            LoadGrid();
            GridViewExporter.FileName = "ItemSummaryReport_" + DateTime.Now.Date;
            GridViewExporter.WriteXlsToResponse();
        }

        /// <summary>
        /// Search by transaction date button click event handler, load data into grid by date selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SearchByTranDt_Click(object sender, EventArgs e)
        {
            LoadGrid();
        }

        /// <summary>
        /// filter dropdown selection changed handler, display filter type as per selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbfilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbfilter.Value.ToString())
            {
                case "1": period.Visible = true; SearchByPsid.Visible = false; CmbUsers.Value = null; break;
                case "2": SearchByPsid.Visible = true; period.Visible = false; frmdate.Value = null; todate.Value = null; break;
                default: period.Visible = false; SearchByPsid.Visible = false; LoadGrid(true); break;
            }
            LoadGrid(true);
        }

        /// <summary>
        /// Gridview custom callback handler, load full grid data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void TranGrid_CustomCallback(object sender, DevExpress.Web.ASPxGridViewCustomCallbackEventArgs e)
        {
            LoadGrid(true);
        }

        /// <summary>
        /// Submit button click event handler, load grid data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void submit_Click(object sender, EventArgs e)
        {
            LoadGrid(false);
        }

        /// <summary>
        /// Search button click event handler, load grid data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SearchBtn_Click(object sender, EventArgs e)
        {
            LoadGrid(false);
        }

        #endregion



        #region User Defined Functions

        /// <summary>
        /// Load data into gridview based on SerialNo or Date range/BuildingID passed
        /// </summary>
        protected void LoadGrid(bool showAll = false)
        {
            var ipTranGrid = new List<InputParameters>
            {
                new InputParameters {SqlParam = "FromDt", ParamValue = showAll ? null : frmdate.Value},
                new InputParameters {SqlParam = "ToDt", ParamValue = showAll ? null : todate.Value},
                new InputParameters {SqlParam = "Psid", ParamValue = showAll ? null : CmbUsers.Value},
            };
            TranGrid.DataSource = QueryHelper.GetAssetsForItemHistory(ipTranGrid);
            TranGrid.DataBind();
        }

        ///// <summary>
        ///// Fill engineer dropdown
        ///// </summary>
        ///// <param name="Combo"></param>
        //private void FillEngineerComboBox(ASPxComboBox Combo)
        //{
        //    var ipGetUserDetails = new List<InputParameters>
        //    {
        //        new InputParameters {SqlParam = "UserPSID", ParamValue = string.Empty},
        //        new InputParameters {SqlParam = "CubicleID", ParamValue = null}
        //    };
        //    var ds = QueryHelper.GetUserDetailsForAddEngineer(ipGetUserDetails);
        //    Combo.DataSource = ds;
        //    Combo.DataBind();
        //}


        /// <summary>
        /// Fill engineer dropdown
        /// </summary>
        /// <param name="Combo"></param>
        private void FillUsersComboBox(ASPxComboBox Combo)
        {
            var ipGetUserDetails = new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserPSID", ParamValue = string.Empty},
                new InputParameters {SqlParam = "CubicleID", ParamValue = null}
            };
            var ds = QueryHelper.GetUserDetailsForItemSummary(ipGetUserDetails);
            Combo.DataSource = ds;
            Combo.DataBind();
        }
        #endregion

    }
}