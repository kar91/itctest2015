﻿using AssetManagement.Tasks;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class Gaurd : AssetTrackerBasePage
    {

        #region Event Handlers

        /// <summary>
        /// Page load event handler, check for page access, Grid data is filled
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Guard";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "Gaurd", "FloorEngg", "AssetLead", "Tier1Lead", "Tier1Engg" };
            IsInGroup();

            //load infoGrid to display all assets currently in transition
            if (!Page.IsPostBack)
            {
                LoadInfoGrid();
            }

            //if infoGrid is in callback, i.e., some pagination event fired, refresh grid data
            if (infoGrid.IsCallback)
            {
                if (Request.Params["__CALLBACKPARAM"].Contains("PAGERONCLICK") || Request.Params["__CALLBACKPARAM"].Contains("APPLYCOLUMNFILTER") || Request.Params["__CALLBACKPARAM"].Contains("SORT"))
                {
                    LoadInfoGrid();
                }
            }

            //When page is in Postback, call LoadGrid to refresh grid data
            if (GaurdGrid.IsCallback)
            {
                if (Request.Params["__CALLBACKPARAM"].Contains("PAGERONCLICK") || Request.Params["__CALLBACKPARAM"].Contains("APPLYCOLUMNFILTER") || Request.Params["__CALLBACKPARAM"].Contains("SORT"))
                {
                    LoadGrid();
                }
            }
        }


        /// <summary>
        /// Custom action button is rendered depending upon next status for any particular request row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GaurdGrid_HtmlRowCreated(object sender, DevExpress.Web.ASPxGridViewTableRowEventArgs e)
        {
            //if current row has data
            if (e.RowType == DevExpress.Web.GridViewRowType.Data)
            {
                string KeyVal = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetTranId").ToString();
                string[] splitObj = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "NextStageInfo").ToString().Split('|');
                int IsApproverReq=Convert.ToInt32(((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "IsApproverReq").ToString());
                string Approvers = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "Approvers").ToString();

                //Loop through possible next stage available for request
                foreach (var item in splitObj)
                {
                    if (IsApproverReq == 0 || GetGroupID==21)
                    {
                        ASPxButton CustBtn = new ASPxButton();
                        CustBtn.ID = String.Format("CustBtn{0}{1}", KeyVal, item.Split('-')[0]);
                        CustBtn.Text = item.Split('-')[1] + item.Split('-')[2];
                        CustBtn.CssClass = "custom";
                        CustBtn.Attributes.Add("AssetTranID", KeyVal);
                        CustBtn.Attributes.Add("NextStatusID", item.Split('-')[0]);
                        CustBtn.Attributes.Add("status", item.Split('-')[1] + item.Split('-')[2]);
                        CustBtn.AutoPostBack = false;
                        CustBtn.ImageUrl = "../Images/acknowledge.png";
                        CustBtn.Image.Width = 20;
                        CustBtn.Image.Height = 20;
                        CustBtn.ClientSideEvents.Click = "CustomButtonOnClick";
                        e.Row.Cells[9].Controls.Add(CustBtn);
                    }
                    else
                    {
                        ASPxLabel CustLbl = new ASPxLabel();
                        CustLbl.ID = String.Format("CustLbl{0}{1}", KeyVal, item.Split('-')[0]);
                        CustLbl.Text = "Need approve from " + Approvers;
                        e.Row.Cells[9].Controls.Add(CustLbl);
                    }
                }
            }
        }


        /// <summary>
        /// Check button OnClick event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btncheck_Click(object sender, EventArgs e)
        {
            LoadGrid();

            if (GaurdGrid.VisibleRowCount == 0)
                txtSerialNo.IsValid = false;
        }


        /// <summary>
        /// Update status of selected request
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GaurdGrid_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            AssetManagementLibrary.Queries qryhelper = new AssetManagementLibrary.Queries();
            var ipUpdateGuard = new List<InputParameters> {
                new InputParameters { SqlParam = "AssetTranID", ParamValue = int.Parse(e.Parameters.Split('|')[0]) },
                new InputParameters { SqlParam = "SysPurposeStageID", ParamValue = int.Parse(e.Parameters.Split('|')[1]) },
                new InputParameters { SqlParam = "ModBy", ParamValue = GetPSID },   
            };
            qryhelper.UpdateForGuard(ipUpdateGuard);
            
            txtSerialNo.Text = String.Empty;
            LoadGrid();
        }



        /// <summary>
        /// to refresh infoGrid on Guard grid data change, i.e., when Guard grid data processed, update infoGrid 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void infoGrid_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            LoadInfoGrid();
        }


        #endregion




        #region User Defined functions

        /// <summary>
        /// Load infoGrid for displaying all assets currently in transition
        /// </summary>
        private void LoadInfoGrid()
        {
            var ipGetAssetsForInfoGaurd = new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserLoginID", ParamValue = GetPSID},
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = GetGroupID}
            };
            infoGrid.DataSource = Extensions.RemoveDuplicates(QueryHelper.GetAssetsForGaurdInTransit(ipGetAssetsForInfoGaurd));
            infoGrid.DataBind();
        }


        /// <summary>
        /// Load data into gridview
        /// </summary>
        /// <param name="text"></param>
        protected void LoadGrid()
        {
            var ipGetAssetsForGaurd = new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserLoginID", ParamValue = GetPSID},
                new InputParameters {SqlParam = "SerialNo", ParamValue = txtSerialNo.Text},
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = GetGroupID}
            };
            GaurdGrid.DataSource = Extensions.RemoveDuplicates(QueryHelper.GetAssetsForGaurd(ipGetAssetsForGaurd));
            GaurdGrid.DataBind();
        }

        #endregion

       

    }
}