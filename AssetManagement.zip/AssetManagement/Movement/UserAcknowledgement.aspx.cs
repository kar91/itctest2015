﻿using AssetManagement.Tasks;
using AssetManagementLibrary;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class UserAcknowledgement : AssetTrackerBasePage
    {
        #region Event Handlers

        /// <summary>
        /// Page label is set to Approval for Master page, Access Group validation check, Purpose dropdown and Grid data are filled
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {

            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "User Acknowledgement";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "EndUser", "AssetLead", "FloorEngg", "Approver", "Tier1Lead", "Tier1Engg" };
            IsInGroup();

            //Purpose dropdown is populated only once on page load
            if (!Page.IsPostBack)
            {
                var ipGetUserDetails = new List<InputParameters>
                {
                    new InputParameters { SqlParam = "UserPSID", ParamValue = GetPSID.ToString() }
                };
                var UserDetails = QueryHelper.GetUserDetails(ipGetUserDetails).FirstOrDefault();

                LoadGrid();

                LocationTxtBox.Text = UserDetails.ToLocation;
                BuildingTxtBox.Text = UserDetails.ToBuilding;
                AreaTxtBox.Text = UserDetails.ToArea;
                CubicleNoTxtBox.Text = UserDetails.ToCubicleNo;

                PSIDTxtBox.Text = GetPSID.ToString();
                NameTxtBox.Text = GetSessionValue<UserProfile>("UserProfile").Name;
            }

            if (UserAckGrid.IsCallback)
            {
                if (Request.Params["__CALLBACKPARAM"].Contains("PAGERONCLICK") || Request.Params["__CALLBACKPARAM"].Contains("APPLYCOLUMNFILTER") || Request.Params["__CALLBACKPARAM"].Contains("SORT"))
                {
                    LoadGrid();
                }
            }
            
        }


        


        /// <summary>
        /// Render custom button for Action column
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void UserAckGrid_HtmlRowCreated(object sender, DevExpress.Web.ASPxGridViewTableRowEventArgs e)
        {
            //if current row has data
            if (e.RowType == DevExpress.Web.GridViewRowType.Data)
            {
                string KeyVal = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetTranId").ToString();
                string[] splitObj = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "NextStageInfo").ToString().Split('|');

                var comments = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "Comments") == null ? "null" : ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "Comments").ToString();
                var AssetType = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetType").ToString();
                string assetdata = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "HpsmNo").ToString() + '|' + ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "SerialNo").ToString() + '|' + ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetType").ToString();

                // Check if EndUser already acknowledged or not, if not, display custom action button to update status, else display User Acknowledged
                if (((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "IsEndUserAcknowledged") == null || (bool)((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "IsEndUserAcknowledged") == false)
                {
                    //Loop through possible next stage available for request
                    foreach (var item in splitObj)
                    {
                        ASPxButton CustBtn = new ASPxButton();
                        CustBtn.ID = "CustBtn" + KeyVal + item.Split('-')[0];
                        CustBtn.Text = item.Split('-')[1];

                        switch (CustBtn.Text)
                        {
                            case "User_Ack": CustBtn.CssClass = "custom"; CustBtn.ImageUrl = "../Images/acknowledge.png"; CustBtn.Attributes.Add("comments", comments); break;
                            case "User_Reject": CustBtn.CssClass = "reject"; CustBtn.ImageUrl = "../Images/rejecticon.png"; CustBtn.Attributes.Add("type", "reject"); CustBtn.Attributes.Add("comments", comments); break;
                            default:
                                break;
                        }
                        //CustBtn.CssClass = "custom";
                        CustBtn.Attributes.Add("AssetTranID", KeyVal);
                        CustBtn.Attributes.Add("status", item.Split('-')[1]);
                        CustBtn.Attributes.Add("NextStatusID", item.Split('-')[0]);

                        CustBtn.Attributes.Add("AssetType", AssetType);
                        CustBtn.Attributes.Add("content", assetdata);

                        CustBtn.AutoPostBack = false;
                        //CustBtn.ImageUrl = "../Images/acknowledge.png";
                        CustBtn.Image.Width = 20;
                        CustBtn.Image.Height = 20;
                        CustBtn.ClientSideEvents.Click = "CustomButtonOnClick";
                        e.Row.Cells[6].Controls.Add(CustBtn);
                    }
                }
                else if ((bool)((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "IsEndUserAcknowledged") == false)
                {
                    ASPxLabel CustLabel = new ASPxLabel();
                    CustLabel.Text = "User Rejected";
                    e.Row.Cells[6].Controls.Add(CustLabel);
                }
                else
                {
                    ASPxLabel CustLabel = new ASPxLabel();
                    CustLabel.Text = "User Acknowledged";
                    e.Row.Cells[6].Controls.Add(CustLabel);
                }
            }
        }




        /// <summary>
        /// Update status of selected request
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void UserAckGrid_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            AssetManagementLibrary.Queries qryhelper = new Queries();
            var ipUpdateAssetStatus = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AssetTranID", ParamValue = int.Parse(e.Parameters.Split('|')[0])},
                new InputParameters {SqlParam = "SysPurposeStageID", ParamValue = int.Parse(e.Parameters.Split('|')[1])},
                new InputParameters {SqlParam = "ModBy", ParamValue = GetPSID},
                new InputParameters {SqlParam = "IsEndUserAcknowledged", ParamValue = e.Parameters.Split('|')[3].ToString() == "User_Reject" ? false : true},
                new InputParameters {SqlParam = "Comments", ParamValue = e.Parameters.Split('|')[2].ToString() == "" || e.Parameters.Split('|')[2].ToString() == "null" ? null : GetPSID.ToString() + ":User: " + e.Parameters.Split('|')[2].ToString()}
            };
            qryhelper.UpdateForEndUserAck(ipUpdateAssetStatus);
            LoadGrid();
        }

        #endregion


        #region User Defined Functions

        /// <summary>
        /// Load data into gridview
        /// </summary>
        protected void LoadGrid()
        {
            var ipGetAssetsForEndUser = new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserPSID", ParamValue = GetPSID}
            };
            UserAckGrid.DataSource = Extensions.RemoveDuplicates(QueryHelper.GetAssetsForEndUser(ipGetAssetsForEndUser));
            UserAckGrid.DataBind();
        }

        #endregion


    }
}