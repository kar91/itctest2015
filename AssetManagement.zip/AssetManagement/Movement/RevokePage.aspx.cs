﻿using AssetManagement.Tasks;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.Entities.Movement;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class RevokePage : AssetTrackerBasePage
    {
        int cmbvalue = 0;
        List<AssetTranExtn> assetlst = new List<AssetTranExtn>();
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Revoke Page";
            }

            //AccessGroup for current page is added, Access Validation is performed
            IsInCustomGroup(); //TODO CHANGE

            cmbvalue = Convert.ToInt32(cmbfilter.Value);
            if (!Page.IsPostBack)
            {
                HspmNo.Visible = false;
                //pcSuccess.EnableViewState = false;
            }

            if (TranHistoryGrid.IsCallback)
            {
                LoadGrid();
            }
        }

        /// <summary>
        /// Need to Change to base once the proper roles have been set across AssetLead and controller
        /// </summary>
        private void IsInCustomGroup()
        {
            var userProfile = GetSessionValue<UserProfile>("UserProfile");
            if (userProfile != null)
            {
                var result = userProfile.UserGroups.Any(grp => grp.GroupName == "Admin");

                if (!(userProfile.PSID == System.Configuration.ConfigurationManager.AppSettings["DefaultAssetLeadID"] || result))
                {
                    Response.Redirect("NotAuthorized.aspx");
                    //Server.Transfer("~/Error/User404.html");
                }
            }

        }

        protected void SearchBySerialNo_Click(object sender, EventArgs e)
        {
            HSPMTxtClient.Value = null;
            LoadGrid();
        }
        protected void SearchByHSPM_Click(object sender, EventArgs e)
        {
            SerialNoTxt.Value = null;
            LoadGrid();
        }
        protected void Export_Click(object sender, ImageClickEventArgs e)
        {
            LoadGrid();
            GridViewExporter.WriteXlsToResponse();
        }

        protected void cmbfilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            TranHistoryGrid.DataSource = null;
            TranHistoryGrid.DataBind();
            cmbvalue = Convert.ToInt32(cmbfilter.Value);
            switch (cmbfilter.Value.ToString())
            {

                case "1": HspmNo.Visible = false; SerialNo.Visible = true; SerialNoTxt.Value = null; break;
                case "2": HspmNo.Visible = true; SerialNo.Visible = false; HSPMTxtClient.Value = null; break;
                default: HspmNo.Visible = false; SerialNo.Visible = false; LoadGrid(); break;
            }
        }

        protected void TranHistoryGrid_HtmlRowCreated(object sender, DevExpress.Web.ASPxGridViewTableRowEventArgs e)
        {
            //if current row has data
            if (e.RowType == DevExpress.Web.GridViewRowType.Data && cmbvalue == Convert.ToInt32(cmbfilter.Value))
            {
                int getMax = assetlst.Max(s => s.RowNo);
                
                string KeyVal = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "ATHistoryID").ToString();
                string KeyVal2 = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "RowNo").ToString();
                
               

                if (Convert.ToString(getMax) != KeyVal2 )
                {
                    ASPxButton CustBtn = new ASPxButton();
                    CustBtn.Theme = "MetropolisBlue";
                    CustBtn.ID = String.Format("CustBtn{0}", KeyVal);
                    CustBtn.Text = "Revoke";
                    CustBtn.Attributes.Add("ATHistoryID", KeyVal);
                    // CustBtn.Attributes.Add("IsInTransit", KeyVal2);
                    CustBtn.HorizontalAlign = HorizontalAlign.Center;
                    CustBtn.AutoPostBack = false;
                    CustBtn.ClientSideEvents.Click = "UndoButtonOnClick";
                    e.Row.Cells[17].Controls.Add(CustBtn);
                }
            }
        }

        protected void TranHistoryGrid_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            int HThistory = Convert.ToInt32(e.Parameters);
            QueryHelper.UpdateForTransactionRevoke(new List<InputParameters> { new InputParameters {SqlParam= "ATHistoryID", ParamValue=HThistory } });
            //pcSuccess.EnableViewState = true;
            //lblsuccess.Text = "Your request has been revoked to previous step";
            LoadGrid();
        }

        List<InputParameters> SetInputParam()
        {
            return new List<InputParameters>
            {
                new InputParameters {SqlParam = "SerialNo", ParamValue = SerialNoTxt.Value},
                new InputParameters {SqlParam = "HPSMNo", ParamValue = HSPMTxtClient.Value}
            };
        }

        protected void LoadGrid()
        {
            if (SerialNoTxt.Value != null || HSPMTxtClient.Value != null)
            {
                var ipGetAssetsForRevokeWhichIsInTransit = SetInputParam();
                assetlst = QueryHelper.GetAssetsForRevoke(ipGetAssetsForRevokeWhichIsInTransit);
                bool isUnique = assetlst.Select(x => x.xRank).Distinct().Count() == assetlst.Count();

                if (isUnique)
                    assetlst = (from dt in assetlst select dt).Take(2).ToList<AssetTranExtn>();
                else
                {
                    var duplicates = assetlst.GroupBy(x => x.xRank).Where(g => g.Count() > 1)
                         .SelectMany(g => g)
                         .ToList().ToList<AssetTranExtn>();

                    //check  current rank
                    var currentrank = assetlst.FirstOrDefault().xRank;
                    if (duplicates.Any(x => x.xRank == currentrank))
                    {


                        List<AssetTranExtn> temp = new List<AssetTranExtn>();

                        AssetTranExtn obj1 = duplicates.FirstOrDefault();
                        AssetTranExtn obj2 = assetlst.FirstOrDefault(x => x.xRank == obj1.xRank - 1);
                        temp.Add(obj1);
                        if (obj2 != null)
                            temp.Add(obj2);
                        assetlst = temp;
                    }
                    else
                        assetlst = (from dt in assetlst select dt).Take(2).ToList<AssetTranExtn>();
                }


                int i = 2;
                if(assetlst.Count>1)
                assetlst.ForEach(x => x.RowNo = i--);
                TranHistoryGrid.DataSource = assetlst;
                TranHistoryGrid.DataBind();
            }
        }
    }
}