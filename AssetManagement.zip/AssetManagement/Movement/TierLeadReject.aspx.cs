﻿using AssetManagement.Tasks;
using AssetManagementLibrary.Entities.Movement;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class TierLeadReject : AssetTrackerBasePage
    {
        private List<AssetTranExtn> _rejecttemplatedatasoure = new List<AssetTranExtn>();

        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();


        }

        protected void LoadData()
        {
            var ipParams = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = "21"},


            };

            _rejecttemplatedatasoure = Extensions.RemoveDuplicates(QueryHelper.GetTleject(ipParams));


            grdrject.DataSource = _rejecttemplatedatasoure;
            grdrject.DataBind();
        }

        protected void grdrject_HtmlRowCreated(object sender, DevExpress.Web.ASPxGridViewTableRowEventArgs e)
        {
            if (e.VisibleIndex == -1) return;
            string KeyVal = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetTranId").ToString();
            string[] splitObj = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "NextStageInfo").ToString().Split('|');
            var comments = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "Comments") == null ? "null" : ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "Comments").ToString();
            var RejectType = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "RejectType").ToString();
            var IsEndUserAcknowledged = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "IsEndUserAcknowledged").ToString();

            string assetdata = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "HpsmNo").ToString() + '|' + ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "SerialNo").ToString() + '|' + ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetType").ToString();
        
            foreach (var item in splitObj)
            {
                ASPxButton CustBtn = new ASPxButton();
                ImageButton CustImgBtn = new ImageButton();
                CustBtn.ID = "CustBtn" + KeyVal + item.Split('-')[0];
                CustBtn.Text = item.Split('-')[1];
                switch (CustBtn.Text)
                {
                    case "BE_Redeploy": CustBtn.CssClass = "custom"; CustBtn.ImageUrl = "../Images/acknowledge.png"; CustBtn.Text = "BE_Redeploy"; break;
                    case "T1L_ReAllocatedT1E": CustBtn.CssClass = "custom"; CustBtn.ImageUrl = "../Images/acknowledge.png"; CustBtn.Attributes.Add("type", "reallocate"); break;

                    case "T1L_AcceptReject":
                        CustBtn.CssClass = "reject"; CustBtn.ImageUrl = "../Images/rejecticon.png"; CustBtn.Attributes.Add("type", "reject");
                        CustBtn.Attributes.Add("content", assetdata);
                        CustBtn.Attributes.Add("IsEndUserAcknowledged", IsEndUserAcknowledged);
                        CustBtn.Attributes.Add("comments", comments);
                        break;
                    default:
                        break;
                }
                CustBtn.Attributes.Add("CurrentStatus", RejectType);

                CustBtn.Attributes.Add("AssetTranID", KeyVal);
                CustBtn.Attributes.Add("NextStatusID", item.Split('-')[0]);
                CustBtn.AutoPostBack = false;

                CustBtn.Image.Width = 20;
                CustBtn.Image.Height = 20;
                CustBtn.ClientSideEvents.Click = "CustomButtonOnClick";
                e.Row.Cells[12].Controls.Add(CustBtn);
   

            }
        }

        protected void grdrject_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            string[] paramsforupdate = e.Parameters.ToString().Split('|');
            var ipUpdateAssetStatus = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AssetTranID", ParamValue = int.Parse(e.Parameters.Split('|')[0])},
                new InputParameters {SqlParam = "SysPurposeStageID", ParamValue = int.Parse(e.Parameters.Split('|')[1])},
                new InputParameters {SqlParam = "ModBy", ParamValue = GetPSID},
                new InputParameters {SqlParam = "Comments", ParamValue = e.Parameters.Split('|')[2].ToString() == "" ? null : GetPSID.ToString() + ":T1L: " + e.Parameters.Split('|')[2].ToString()}
            };
            bool stat = QueryHelper.UpdateForTLReject(ipUpdateAssetStatus);
            //if (stat != true) return;

        }

        protected void cmbengineer_Callback(object sender, CallbackEventArgsBase e)
        {
            var combobox = sender as ASPxComboBox;
            combobox.DataSource = UIHelper.Helper.GetMovementEngineers();
            combobox.TextField = "Name";
            combobox.ValueField = "PSID";
            combobox.DataBind();

        }


        protected void cmbassetstat_Callback(object sender, CallbackEventArgsBase e)
        {
            var combobox = sender as ASPxComboBox;
            combobox.DataSource = QueryHelper.GetAssetStatus();
            combobox.TextField = "AssetStatus";
            combobox.ValueField = "SysAssetStatusID";
            combobox.DataBind();
        }
    }
}