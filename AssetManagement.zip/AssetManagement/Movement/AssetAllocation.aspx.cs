﻿using AssetManagement.Tasks;
using AssetManagementLibrary;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.Entities.Movement;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class AssetAllocation : AssetTrackerBasePage
    {

        #region Event Handlers

        /// <summary>
        /// Page Load event handler, check for page access, Purpose dropdown and Grid data are filled
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Asset Allocation";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "AssetLead" };
            IsInGroup();

            //Purpose dropdown is populated only once on page load
            if (!Page.IsPostBack)
            {
                LoadGrid();
            }

            //When page is in Postback, call LoadGrid function to refresh grid data
            if (grdassetlead.IsCallback)
            {
                if (Request.Params["__CALLBACKPARAM"].Contains("PAGERONCLICK") || Request.Params["__CALLBACKPARAM"].Contains("APPLYCOLUMNFILTER") || Request.Params["__CALLBACKPARAM"].Contains("SORT"))
                {
                    LoadGrid();
                }
            }
        }




        /// <summary>
        /// Custom action button is rendered depending upon next status for any particular request row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdassetlead_HtmlRowCreated(object sender, ASPxGridViewTableRowEventArgs e)
        {
            //if current row has data
            if (e.RowType == DevExpress.Web.GridViewRowType.Data)
            {
                string KeyVal = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetTranId").ToString();
                string[] splitObj = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "NextStageInfo").ToString().Split('|');

                //Loop through possible next stage available for request
                foreach (var item in splitObj)
                {
                    ASPxButton CustBtn = new ASPxButton();
                    CustBtn.ID = String.Format("CustBtn{0}{1}", KeyVal, item.Split('-')[0]);
                    CustBtn.Text = "Edit";
                    CustBtn.CssClass = "custom";
                    CustBtn.Attributes.Add("AssetTranID", KeyVal);
                    CustBtn.Attributes.Add("NextStatusID", item.Split('-')[0]);
                    CustBtn.AutoPostBack = false;
                    CustBtn.ImageUrl = "../Images/acknowledge.png";
                    CustBtn.Image.Width = 20;
                    CustBtn.Image.Height = 20;
                    CustBtn.ClientSideEvents.Click = "CustomButtonOnClick";
                    e.Row.Cells[0].Controls.Add(CustBtn);
                }
            }
        }



        /// <summary>
        /// Redirect to Allocation Edit page for selected asset, pass assetTranID from action button attribute
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdassetlead_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            ASPxWebControl.RedirectOnCallback("AllocationEdit.aspx?AssetTranId=" + int.Parse(e.Parameters.Split('|')[0]));
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdassetlead_AutoFilterCellEditorCreate(object sender, ASPxGridViewEditorCreateEventArgs e)
        {
            e.EditorProperties = new TextBoxProperties();
        }

        #endregion



        #region User Defined Functions


        /// <summary>
        /// Load data into gridview, check selected Purpose or HpsmNo, fill HpsmNo dropdown data after every refresh
        /// </summary>
        /// <param name="purposeID"></param>
        /// <param name="HpsmNo"></param>
        protected void LoadGrid()
        {
            int? purposeID = null;
            string HpsmNo = null;

            var ipGetAssetsForAssetAallocation = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = GetGroupID},
                new InputParameters {SqlParam = "SysPurposeID", ParamValue = purposeID},
                new InputParameters {SqlParam = "HpsmNo", ParamValue = HpsmNo}
            };
            var lstAssetTranExtns = Extensions.RemoveDuplicates(QueryHelper.GetAssetsForAssetAllocation(ipGetAssetsForAssetAallocation));
            grdassetlead.DataSource = lstAssetTranExtns;
            grdassetlead.DataBind();
        }

        #endregion

    }

}