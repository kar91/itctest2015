﻿using AssetManagement.Tasks;
using AssetManagementLibrary.OtherHelpers;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class TransactionHistory : AssetTrackerBasePage
    {

        #region Event Handlers

        /// <summary>
        /// Page laod event handler, check for page access, load data for building dropdown and grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {           
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Transaction History";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "AssetLead", "Approver", "Tier1Lead" };
            IsInGroup();
            
            //bind building dropdown data
            CmbBuilding.DataSource = UIHelper.Helper.GetBuildings();
            CmbBuilding.TextField = "BuildingName";
            CmbBuilding.ValueField = "BuildingID";
            CmbBuilding.DataBind();

            if (!Page.IsPostBack)
            {
                SerialNo.Visible = false;
                
                var ipbuildingonlocation = new List<InputParameters>
                {
                    new InputParameters {SqlParam = "LocationID", ParamValue = 2},
                    new InputParameters {SqlParam = "PSID", ParamValue = Session["PSID"].ToString()},
                    new InputParameters
                    {
                        SqlParam = "ApplicationID",
                        ParamValue = Convert.ToInt16(ConfigurationManager.AppSettings["ApplicationID"]).ToString()
                    }
                };
                FromDate.Value = DateTime.Today;
                ToDate.Value = DateTime.Today;   
            }

            if (TranHistoryGrid.IsCallback)
            {
                LoadGrid();
            }
        }

        /// <summary>
        /// Search grid details by Serial Number passed and reset date field and building values
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SearchBySerialNo_Click(object sender, EventArgs e)
        {
            //Clear previous values of Date fields and Building if existing 
            FromDate.Value = null;
            ToDate.Value = null;
            CmbBuilding.Value = null;
            LoadGrid();
        }

        /// <summary>
        /// Search grid details by Date range or Building(optional) passed and reset serial number field values
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SearchByBuildingId_Click(object sender, EventArgs e)
        {
            //Clear previous serialNo values if existing
            SerialNoTxt.Value = null;
            LoadGrid();
        }

        /// <summary>
        /// On export click, gridview data exported to excel file by TranHistoryGrid name
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Export_Click(object sender, ImageClickEventArgs e)
        {
            LoadGrid();
            GridViewExporter.WriteXlsToResponse();
        }



        /// <summary>
        /// based on filter type, display dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbfilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbfilter.Value.ToString())
            {
                case "1": period.Visible = true; SerialNo.Visible = false; SerialNoTxt.Value = null; break;
                case "2": SerialNo.Visible = true; period.Visible = false; FromDate.Value = null; ToDate.Value = null; break;
                default: period.Visible = false; SerialNo.Visible = false; LoadGrid(); break;
            }
        }


        /// <summary>
        /// on search button click, load data into grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SearchBySerialNoBtn_Click(object sender, EventArgs e)
        {
            LoadGrid();
        }


        #endregion



        #region User Defined Functions

        /// <summary>
        /// Load data into gridview based on SerialNo or Date range/BuildingID passed
        /// </summary>
        protected void LoadGrid()
        {
            if (SerialNoTxt.Value != null)
            {
                var ipGetAssetsForTranHistoryBySerialNo = new List<InputParameters>
                        {
                            new InputParameters {SqlParam = "SerialNo", ParamValue = SerialNoTxt.Text}
                        };
                TranHistoryGrid.DataSource = QueryHelper.GetAssetsForTranHistory(ipGetAssetsForTranHistoryBySerialNo);
                TranHistoryGrid.DataBind();
            }
            else if (CmbBuilding.Value != null || FromDate.Value != null || ToDate.Value != null)
            {
                var ipGetAssetsForTranHistoryByBuilding = new List<InputParameters>
                        {
                            new InputParameters {SqlParam = "SerialNo", ParamValue = null},
                            new InputParameters {SqlParam = "FromModDt", ParamValue = FromDate.Value},
                            new InputParameters {SqlParam = "ToModDt", ParamValue = ToDate.Value},
                            new InputParameters {SqlParam = "BuildingID", ParamValue = CmbBuilding.Value}
                        };
                TranHistoryGrid.DataSource = QueryHelper.GetAssetsForTranHistory(ipGetAssetsForTranHistoryByBuilding);
                TranHistoryGrid.DataBind();
            }
        }

        #endregion


    }
}