﻿using AssetManagement.Tasks;
using AssetManagementLibrary.Entities;
using DevExpress.Utils;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class UserRevertAction : AssetTrackerBasePage
    {
       

        protected void Page_Load(object sender, EventArgs e)
        {
            IsInCustomGroup();

            if (!IsCallback)
            {
                if (Master != null)
                {
                    var lblMasterStatus = (Label)Master.FindControl("lblStatus");

                    lblMasterStatus.Text = "User Revert Action";
                }
            }


            LoadUserRevertActionGrid();
            
        }

        /// <summary>
        /// Need to Change to base once the proper roles have been set across AssetLead and controller
        /// </summary>
        private void IsInCustomGroup()
        {
            var userProfile = GetSessionValue<UserProfile>("UserProfile");
            if (userProfile != null)
            {
                var result = userProfile.UserGroups.Any(grp => grp.GroupName == "Admin");

                if (!(userProfile.PSID == System.Configuration.ConfigurationManager.AppSettings["DefaultAssetLeadID"] || result))
                {
                    Response.Redirect("NotAuthorized.aspx");
                    //Server.Transfer("~/Error/User404.html");
                }
            }

        }

        private void LoadUserRevertActionGrid()
        {
            GrdUserRevertAction.DataSource = QueryHelper.GetUserRevertActionDetails();
            GrdUserRevertAction.DataBind();
        }

        protected void GrdUserRevertAction_CustomButtonCallback(object sender, DevExpress.Web.ASPxGridViewCustomButtonCallbackEventArgs e)
        {
            var key = GrdUserRevertAction.GetRowValues(e.VisibleIndex, "SAFeedbackID").ToString();

            var ipUserRevert = new List<InputParameters>
            {
                new InputParameters {SqlParam = "SAFeedbackID", ParamValue = key}
            };

            QueryHelper.UpdateUserRevertActionDetails(ipUserRevert);
            LoadUserRevertActionGrid();
        }

   
        protected void GrdUserRevertAction_CustomButtonInitialize(object sender, ASPxGridViewCustomButtonEventArgs e)
        {
            if (e.VisibleIndex == -1) return;

            if (((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "IsActionTaken").ToString() == "Yes")
            {
                //e.Visible = DefaultBoolean.False;
                e.Enabled = false;
                e.Text = "Yes";
            }
        }

        protected void GrdUserRevertAction_HtmlRowPrepared(object sender, ASPxGridViewTableRowEventArgs e)
        {
            if (e.VisibleIndex == -1) return;

            if (((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "IsActionTaken").ToString() == "Yes")
                e.Row.BackColor = Color.FromArgb(213,247,223);
        }


    }
}