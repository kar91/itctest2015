﻿using AssetManagement.Tasks;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class ConfigurationEngineer : AssetTrackerBasePage
    {

        #region Event Handlers

        /// <summary>
        /// Handle grid and engineer dropdown data filling
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            AccessGroups = new List<string> { "Tier1Lead", "Approver" };

            IsInGroup();
            
            //Fill grid data and Engineer filter dropdown
            if (!Page.IsPostBack)
            {
                LoadGrid();
            }

            //If grid is in callback on any Sorting, paging, column filtering event, then reload grid data
            if (ConfigGrid.IsCallback)
            {
                if (Request.Params["__CALLBACKPARAM"].Contains("PAGERONCLICK") || Request.Params["__CALLBACKPARAM"].Contains("APPLYCOLUMNFILTER") || Request.Params["__CALLBACKPARAM"].Contains("SORT"))
                {
                    LoadGrid();
                }
            }

            //Fill Engineer filter dropdown
            FillEngineerComboBox(CmbEngineer);
        }


        /// <summary>
        /// Fill Tier1Engineer data for dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ConfigGrid_CellEditorInitialize(object sender, DevExpress.Web.ASPxGridViewEditorEventArgs e)
        {
            ASPxGridView gridTable = (ASPxGridView)sender;

            //If editor cell under Tier1Engg column, fill dropdown data
            if (e.Column.FieldName == "Tier1EnggId")
            {
                var combo = (ASPxComboBox)e.Editor;
                FillEngineerComboBox(combo);
            }
        }


        /// <summary>
        /// Update Tier1Engineer for selected row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ConfigGrid_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            var ipUpdateConfigEngg = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AssetTranID", ParamValue = e.Keys[0]},
                new InputParameters {SqlParam = "Tier1EnggID", ParamValue = e.NewValues[4]}
            };
            if (QueryHelper.UpdateConfigurationEngineer(ipUpdateConfigEngg))
            {
                e.Cancel = true;
                ((ASPxGridView)sender).CancelEdit();
                LoadGrid();
            }
        }


        /// <summary>
        /// for searching via Engineer Psid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void CmbEngineer_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadGrid();
        }


        /// <summary>
        /// for searching via hpsmNo 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SearchByHpsm_Click(object sender, EventArgs e)
        {
            LoadGrid();
        }

        /// <summary>
        /// Export grid data into Excel sheet
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Export_Click(object sender, ImageClickEventArgs e)
        {
            LoadGrid(ConfigGrid);
           

            GridViewExporter.FileName = "ConfigurationEngineerReport_" + DateTime.Now.Date;
            GridViewExporter.WriteXlsToResponse();


        }

        #endregion


        #region User Defined functions

        /// <summary>
        /// Fill data for Engineer combobox 
        /// </summary>
        /// <param name="combo"></param>
        /// <param name="cubicleID"></param>
        /// <param name="UserPsid"></param>
        protected void FillEngineerComboBox(ASPxComboBox combo)
        {
            combo.DataSource = UIHelper.Helper.GetTier1Engineers();
            combo.DataBind();
        }
        
        /// <summary>
        /// Load data into gridview
        /// </summary>
        /// <param name="purposeID"></param>
        /// <param name="HpsmNo"></param>
        protected void LoadGrid()
        {
            string engineerID = null;

            //Check if Engineer is selected
            if (CmbEngineer.Value != null)
            {
                engineerID = CmbEngineer.Value.ToString();
            }

            var ipGetAssetsForConfig = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = GetSessionValue<UserProfile>("UserProfile").UserGroups.FirstOrDefault().GroupID},
                new InputParameters {SqlParam = "EngineerID", ParamValue = engineerID},
                new InputParameters {SqlParam = "HpsmNo", ParamValue = HpsmNoTxtBox.Value}
            };

            ConfigGrid.DataSource = Extensions.RemoveDuplicates(QueryHelper.GetAssetsForConfigEngineer(ipGetAssetsForConfig)); ;
            ConfigGrid.DataBind();
        }

        protected void LoadGrid(ASPxGridView sender)
        {
            string engineerID = null;

            //Check if Engineer is selected
            if (CmbEngineer.Value != null)
            {
                engineerID = CmbEngineer.Value.ToString();
            }

            var ipGetAssetsForConfig = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = GetSessionValue<UserProfile>("UserProfile").UserGroups.FirstOrDefault().GroupID},
                new InputParameters {SqlParam = "EngineerID", ParamValue = engineerID},
                new InputParameters {SqlParam = "HpsmNo", ParamValue = HpsmNoTxtBox.Value}
            };

            sender.DataSource = Extensions.RemoveDuplicates(QueryHelper.GetAssetsForConfigEngineer(ipGetAssetsForConfig)); ;
            sender.DataBind();
           
        }

        #endregion

    }
}