﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace AssetManagement.Movement.Reports
{
    public partial class DeploymentReport : DevExpress.XtraReports.UI.XtraReport
    {
        public DeploymentReport()
        {
            InitializeComponent();
        }

    }
}
