﻿using AssetManagement.Tasks;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.Entities.Movement;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class RejectMonitor : AssetTrackerBasePage
    {
        private List<AssetTranExtn> _rejecttemplatedatasoure = new List<AssetTranExtn>();

        /// <summary>
        /// Default page load event, initialise grid data 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "AssetLead" };
            IsInGroup();

            LoadData();
        }

        /// <summary>
        /// Load data into grid and store copy in private property
        /// </summary>
        protected void LoadData()
        {
            var ipParams = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = GetSessionValue<UserProfile>("UserProfile").UserGroups.FirstOrDefault().GroupID},
            };

            _rejecttemplatedatasoure = Extensions.RemoveDuplicates(QueryHelper.GetRejectedAssets(ipParams));

            grdrject.DataSource = _rejecttemplatedatasoure;
            grdrject.DataBind();
        }

        /// <summary>
        /// Custom button is rendered depending upon next status for any particular request row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdrject_HtmlRowCreated(object sender, DevExpress.Web.ASPxGridViewTableRowEventArgs e)
        {
            if (e.VisibleIndex == -1) return;
            string KeyVal = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetTranId").ToString();
            string[] splitObj = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "NextStageInfo").ToString().Split('|');
            var comments = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "Comments") == null ? null : ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "Comments").ToString();
            var RejectType = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "RejectType").ToString();
            var IsEndUserAcknowledged = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "IsEndUserAcknowledged").ToString();
            var PurposeID = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "SysPurposeId").ToString();
            var AssetType = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetType").ToString();

            string assetdata = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "HpsmNo").ToString() + '|' + ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "SerialNo").ToString() + '|' + ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetType").ToString();
            ASPxButton CustBtn = new ASPxButton();
            ImageButton CustImgBtn = new ImageButton();
            foreach (var item in splitObj)
            {
                CustBtn.ID = "CustBtn" + KeyVal + item.Split('-')[0];
                CustBtn.Text = item.Split('-')[1];
                CustBtn.CssClass = "reject";
                CustBtn.ImageUrl = "../Images/rejecticon.png";
                CustBtn.Attributes.Add("type", "reject");
                CustBtn.Attributes.Add("comments", comments);
                CustBtn.Attributes.Add("CurrentStatus", RejectType);
                CustBtn.Attributes.Add("IsEndUserAcknowledged", IsEndUserAcknowledged);
                CustBtn.Attributes.Add("PurposeID", PurposeID);
                CustBtn.Attributes.Add("AssetType", AssetType);
                CustBtn.Attributes.Add("AssetTranID", KeyVal);
                CustBtn.Attributes.Add("content", assetdata);
                CustBtn.Attributes.Add("NextStatusID", item.Split('-')[0]);
                CustBtn.AutoPostBack = false;

                CustBtn.Image.Width = 20;
                CustBtn.Image.Height = 20;
                CustBtn.ClientSideEvents.Click = "CustomButtonOnClick";
                e.Row.Cells[12].Controls.Add(CustBtn);
                LoadData();
            }
        }

        /// <summary>
        /// Update status of selected request
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdrject_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            string[] paramsforupdate = e.Parameters.ToString().Split('|');

            var ipUpdateAssetStatus = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AssetTranID", ParamValue = int.Parse(paramsforupdate[0])},
                new InputParameters {SqlParam = "Purposestageid", ParamValue = int.Parse(paramsforupdate[1])},
                new InputParameters {SqlParam = "Psid", ParamValue = GetPSID},
                new InputParameters {SqlParam = "movementengineerpsid", ParamValue = (paramsforupdate[3]=="null" ? null : paramsforupdate[3].ToInt())},
                new InputParameters {SqlParam = "AssetStatusId", ParamValue = (paramsforupdate[4]=="null" ? null : paramsforupdate[4].ToInt())},

                new InputParameters {SqlParam = "Comments", ParamValue = string.IsNullOrEmpty(Convert.ToString(paramsforupdate[2]))?null : GetPSID.ToString() + ":AL: " +Convert.ToString(paramsforupdate[2]) }
            };
            bool stat = QueryHelper.updateFinalreject(ipUpdateAssetStatus);
            if (stat != true) return;

        }

        /// <summary>
        /// Movement engineer dropdown callback event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbengineer_Callback(object sender, CallbackEventArgsBase e)
        {
            var combobox = sender as ASPxComboBox;
            combobox.DataSource = UIHelper.Helper.GetAssetLeadEngineers();
            combobox.TextField = "Name";
            combobox.ValueField = "PSID";
            combobox.DataBind();

        }

        /// <summary>
        /// Asset status dropdown callback event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbassetstat_Callback(object sender, CallbackEventArgsBase e)
        {
            var combobox = sender as ASPxComboBox;
            combobox.DataSource = QueryHelper.GetAssetStatus();
            combobox.TextField = "AssetStatus";
            combobox.ValueField = "SysAssetStatusID";
            combobox.DataBind();
        }
    }
}