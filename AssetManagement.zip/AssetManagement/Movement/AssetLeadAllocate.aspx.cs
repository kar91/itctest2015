﻿using AssetManagement.Tasks;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class AssetLeadAllocate : AssetTrackerBasePage
    {

        DBHelper db = new DBHelper();
        protected void Page_Load(object sender, EventArgs e)
        {
            var ipGetAssetsForAssetAllocation = new List<InputParameters>
            {

                new InputParameters {SqlParam = "AccessGroupID", ParamValue = 21},

                new InputParameters {SqlParam = "SysPurposeID", ParamValue = null},


            };
            grdassetlead.DataSource = Extensions.RemoveDuplicates(QueryHelper.GetAssetsForAssetAllocation(ipGetAssetsForAssetAllocation));

            grdassetlead.DataBind();
        }

        protected void grdassetlead_CellEditorInitialize(object sender, ASPxGridViewEditorEventArgs e)
        {
            if (!grdassetlead.IsEditing || e.Column.FieldName != "AssetTranId") return;
            ASPxComboBox combo = e.Editor as ASPxComboBox;
            var ds = db.GetDataSet("select EMPLID as PSID, NAME_DISPLAY as Name from I3LIntMaster.[dbo].[PS_I2L_EMP_INFO]", CommandType.Text, null);
            combo.DataSource = ds;
            combo.DataBind();
        }
    }
}