﻿using AssetManagement.Tasks;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class InventorySummaryReport : AssetTrackerBasePage
    {
        
        #region Event handlers

        /// <summary>
        /// Page load event handler, set date to today
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Inventory Summary Report";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "AssetLead", "Approver", "Tier1Lead" };
            IsInGroup();

            if (!Page.IsPostBack)
            {
                frmdate.Date = DateTime.Today;
                todate.Date = DateTime.Today;
                frmdate.MaxDate = DateTime.Today;
                todate.MaxDate = DateTime.Today;
            }

            if (TranGrid.IsCallback)
            {
                LoadGrid(false);
            }
        }

        /// <summary>
        /// Export button click event handler, export grid data to excel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Export_Click(object sender, ImageClickEventArgs e)
        {
            LoadGrid();
            GridViewExporter.FileName = "InventorySummaryReport_" + DateTime.Now.Date;
            GridViewExporter.WriteXlsToResponse();
        }

        /// <summary>
        /// Submit button click handler, load grid by date selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void submit_Click(object sender, EventArgs e)
        {
            LoadGrid(false);
        }

        /// <summary>
        /// filter dropdown selection changed, display filter option
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbfilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbfilter.Value.ToString() == "1")
            {
                period.Visible = true;
            }
            else
            {
                period.Visible = false;
                LoadGrid(true);
            }
        }

        /// <summary>
        /// Gridview custom callback handler, redirect incoming request to MovementReport page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void TranGrid_CustomButtonCallback(object sender, DevExpress.Web.ASPxGridViewCustomButtonCallbackEventArgs e)
        {
            ASPxWebControl.RedirectOnCallback("Movement.aspx?BuildingID=" + TranGrid.GetRowValues(e.VisibleIndex, "BuildingID") + "&Date=" + ((DateTime)TranGrid.GetRowValues(e.VisibleIndex, "DateCalculated")).Date);
        }

        #endregion


        #region User defined methods

        /// <summary>
        /// Load data into gridview based on SerialNo or Date range/BuildingID passed
        /// </summary>
        protected void LoadGrid(bool showAll = false)
        {
            var ipTranGrid = new List<InputParameters>
            {
                new InputParameters {SqlParam = "FromDt", ParamValue = showAll ? null : frmdate.Value},
                new InputParameters {SqlParam = "ToDt", ParamValue = showAll ? null : todate.Value}
            };

            TranGrid.DataSource = QueryHelper.GetInventorySummary(ipTranGrid);
            TranGrid.DataBind();
        }

        #endregion

    }
}