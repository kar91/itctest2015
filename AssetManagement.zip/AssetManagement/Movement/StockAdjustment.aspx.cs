﻿using AssetManagement.Tasks;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.Entities.Movement;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class StockAdjustment : AssetTrackerBasePage
    {
        #region global variables

        protected List<AssetTranExtn> assetlst;

        #endregion


        #region Event Handlers


        /// <summary>
        /// Bind data to building and status dropdown inside popup
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Stock Adjustment";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "AssetLead", "Approver" };
            IsInGroup();


            LoadGrid();

            //When page first load, bind asset details data to grid, load building & status dropdown
            if (!Page.IsPostBack)
            {
                cmbBuilding.DataSource = UIHelper.Helper.GetBuildings();
                cmbBuilding.DataBind();

                cmbStatus.DataSource = QueryHelper.GetAllAssetStatus();
                cmbStatus.ValueField = "Key";
                cmbStatus.TextField = "Value";
                cmbStatus.DataBind();
            }
        }

        /// <summary>
        /// event handler to render custom Adjust button for last column in grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void AdjustmentGrid_HtmlRowCreated(object sender, DevExpress.Web.ASPxGridViewTableRowEventArgs e)
        {
            //if current row has data
            if (e.RowType == DevExpress.Web.GridViewRowType.Data)
            {
                string KeyVal = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetId").ToString();

                ASPxButton CustBtn = new ASPxButton();
                CustBtn.Theme = "MetropolisBlue";
                CustBtn.ID = String.Format("CustBtn{0}", KeyVal);
                CustBtn.Text = "Adjust";
                CustBtn.Attributes.Add("AssetID", KeyVal);
                CustBtn.HorizontalAlign = HorizontalAlign.Center;
                CustBtn.AutoPostBack = false;
                CustBtn.ClientSideEvents.Click = "AdjustButtonOnClick";
                e.Row.Cells[7].Controls.Add(CustBtn);
            }
        }

        /// <summary>
        /// Binds dataset to PopupGrid for asset selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PopupGrid_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            cmbenduserdetails.SelectedIndex = -1;
            cmbBuilding.SelectedIndex = -1;
            cmbArea.SelectedIndex = -1;
            cmbCubicle.SelectedIndex = -1;
            PopupGrid.DataSource = assetlst.Where(s => s.AssetId == int.Parse(e.Parameters));
            PopupGrid.DataBind();

        }

        /// <summary>
        /// fill data for psid dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbEndUserPsid_Callback(object sender, CallbackEventArgsBase e)
        {
            var ipGetUserDetails = new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserPSID", ParamValue = string.Empty},
                new InputParameters {SqlParam = "CubicleID", ParamValue = null}
            };
            var ds = QueryHelper.GetUserDetails(ipGetUserDetails);
            cmbenduserdetails.DataSource = ds;
            cmbenduserdetails.DataBind();
        }

        /// <summary>
        /// cascading dropdown, load data for area dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbArea_Callback(object sender, CallbackEventArgsBase e)
        {
            if (cmbBuilding.Value != null)
            {
                cmbArea.DataSource = UIHelper.Helper.GetFloors(int.Parse(e.Parameter.ToString()));
                cmbArea.DataBind();
            }
        }

        /// <summary>
        /// cascading dropdown, load data for cubicle dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbCubicle_Callback(object sender, CallbackEventArgsBase e)
        {
            if (cmbArea.Value != null)
            {
                var ipcubiclebasedonarea = new List<InputParameters>
                {
                    new InputParameters {SqlParam = "BuildingFloorID", ParamValue = e.Parameter}
                };
                cmbCubicle.DataSource = QueryHelper.GetCubicleBasedOnArea(ipcubiclebasedonarea);
                cmbCubicle.DataBind();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void submit_Click(object sender, EventArgs e)
        {
            var assetid = PopupGrid.GetRowValues(0, "AssetId");
            var cubicleid = cmbCubicle.Value;
            var psid = cmbenduserdetails.Value;
            var statusid = cmbStatus.Value;
            var ipStockAdjustUpdate = new List<InputParameters>
            {
                new InputParameters {SqlParam = "SysAssetId", ParamValue = assetid},
                new InputParameters {SqlParam = "ToCubicle", ParamValue = cubicleid},
                new InputParameters {SqlParam = "ToPSID", ParamValue = psid},
                new InputParameters {SqlParam = "AssetStatusID", ParamValue = statusid},
                new InputParameters {SqlParam = "ModBy", ParamValue = GetPSID},

            };

            //update asset details if new value has been passed
            if (cubicleid != null || psid != null || statusid != null)
            {
                if (QueryHelper.InsertNewRequestStockAdjustment(ipStockAdjustUpdate)) {

                    string EmailID = ConfigurationManager.AppSettings["AssetCorrectionEmailAddress"].ToString();

                    string assetType = PopupGrid.GetRowValuesByKeyValue(assetid, "AssetType").ToString();
                    string serialNo = PopupGrid.GetRowValuesByKeyValue(assetid, "SerialNo").ToString();

                    string FromStatus = PopupGrid.GetRowValuesByKeyValue(assetid, "AssetStatus").ToString();
                    string FromPsid = PopupGrid.GetRowValuesByKeyValue(assetid, "FromPsid").ToString();
                    string FromName = PopupGrid.GetRowValuesByKeyValue(assetid, "FromName").ToString();
                    string FromCubicle = PopupGrid.GetRowValuesByKeyValue(assetid, "FromCubicleNo").ToString();
                    string FromArea = PopupGrid.GetRowValuesByKeyValue(assetid, "FromArea").ToString();
                    string FromBuilding = PopupGrid.GetRowValuesByKeyValue(assetid, "FromBuilding").ToString();
                    
                    string ToStatus = cmbStatus.Text;
                    string ToPsid = cmbenduserdetails.Value.ToString();
                    string ToName = cmbenduserdetails.Text;
                    string ToCubicle = cmbCubicle.Text;
                    string ToArea = cmbArea.Text;
                    string ToBuilding = cmbBuilding.Text;

                    string Requestor = GetPSID + ", " + GetName;
                    
                    SendMail(EmailID,assetType,serialNo,FromStatus,FromPsid,FromName,FromCubicle,FromArea,FromBuilding,ToStatus,ToPsid,ToName,ToCubicle,ToArea,ToBuilding,Requestor);
                    
                }

                //reload grid data
                LoadGrid();
            }

            //close popup
            AssetDetailsPopup.ShowOnPageLoad = false;
        }


        #endregion


        #region User defined methods


        /// <summary>
        /// send template mail to user asynchronously
        /// </summary>
        private void SendMail(string emailid, string assettype, string serialno, string fromstatus, string frompsid, string fromname, string fromcubicle, string fromarea, string frombuilding, string tostatus, string topsid, string toname, string tocubicle, string toarea, string tobuilding, string requestor)
        {
            Task.Factory.StartNew(() =>
            {
                try
                {
                    string mailBody = "";
                    using (var reader = new StreamReader(Server.MapPath("~/Templates/AssetCorrection.html")))
                    {
                        mailBody = String.Format(reader.ReadToEnd(), assettype, serialno, fromstatus, frombuilding, fromarea, fromcubicle, frompsid, tostatus, tobuilding, toarea, tocubicle, topsid, requestor);
                    }
                    UIHelper.Helper.SendEmail(mailBody, emailid, "Request for data corrections in AMS");
                }
                catch (Exception)
                {

                }
            });

        }


        /// <summary>
        /// Fetch all assets from master table for Grid
        /// </summary>
        protected void LoadGrid()
        {
            var ipGetAssetsFoStockAdjust = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = GetSessionValue<UserProfile>("UserProfile").UserGroups.FirstOrDefault().GroupID},
            };
            assetlst = QueryHelper.GetAssetsForStockAdjustment(ipGetAssetsFoStockAdjust);
            AdjustmentGrid.DataSource = assetlst;
            AdjustmentGrid.DataBind();
        }


        #endregion

    }
}