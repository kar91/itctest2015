﻿using AssetManagementLibrary.Entities.Movement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using AssetManagement.Tasks;
using AssetManagementLibrary.Entities;

namespace AssetManagement.Movement
{
    public partial class CancelRequest  : AssetTrackerBasePage
    {
        private List<AssetTranExtn> _assetsplitdatasource = new List<AssetTranExtn>();
        public AssetManagementLibrary.Queries QueryHelper
        {
            get
            {
                return new AssetManagementLibrary.Queries();
            }
        }
        /// <summary>
        /// Need to Change to base once the proper roles have been set across AssetLead and controller
        /// </summary>
        private void IsInCustomGroup()
        {
            var userProfile = GetSessionValue<UserProfile>("UserProfile");
            if (userProfile != null)
            {
                var result = userProfile.UserGroups.Any(grp => grp.GroupName == "Admin");
                
                if (!(userProfile.PSID == System.Configuration.ConfigurationManager.AppSettings["DefaultAssetLeadID"] || result))
                {
                    Response.Redirect("NotAuthorized.aspx");
                    //Server.Transfer("~/Error/User404.html");
                }
            }

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            IsInCustomGroup();

            if (!IsCallback)
            {
                if (Master != null)
                {
                    var lblMasterStatus = (Label)Master.FindControl("lblStatus");

                    lblMasterStatus.Text = "Cancel Request";
                }
            }
            //if (!Page.IsPostBack)
            //{
            //    pcSuccess.EnableViewState = false;
            //}
            LoadGrid();
            grdAssetCancel.JSProperties["cpUserPSID"] = GetPSID ;
        }

        public void LoadGrid()
        {
            _assetsplitdatasource = QueryHelper.GetCancelDataList().ConvertToAssetExtension();
            grdAssetCancel.DataSource = _assetsplitdatasource;
            grdAssetCancel.DataBind();
        }

        protected void grdAssetCancel_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            LoadGrid();
        }
    }
}