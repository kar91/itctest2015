﻿using AssetManagement.Tasks;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web.UI.WebControls;
using AssetManagementLibrary.Entities.Movement;
using AssetManagementLibrary;
using DevExpress.XtraPrinting.Native;
using System.Web;
using System.Collections;

namespace AssetManagement.Movement
{
    #region Summary
    /// *************************************NewRequest Page******************************************
    /// Inherits from     :AssetTrackerBasePage
    /// Master Page       :AssetMovementMaster
    /// Classes Used      :Checkbox,DefultId,Maingriddatasource
    /// Controls Used     :AspxGridview:
    ///                    -grdAssetSplit,grdAssetList
    ///                    -Total 2
    ///                   :AspxCombobox:
    ///                    -cmbtype,cmbhpsmnumber,cmbpurposetype,cmbLocFrom,cmbAreafrom
    ///                     cmbfromfloor,cmbAssetType,cmbarea,cmbbuilding,cmbcubicle,cmbenginner
    ///                    -Total 11
    /// Sessions Used     :GridFilters,data,datatobind,typeof,contains
    ///                    -Total 5
    /// type of Calls     :Callback
    /// Helper methods    :Extension.cs,Dbhelper.cs,Cachehelper.cs,QueryHelper.cs
    /// Paussible errors  :-Object refrence not set on submit :PurposeID is not present
    ///                    -Dupicate key error:The record to be submitted has already been submitted
    /// ************************************End of Summary******************************************
    ///   
    /// Version          :I think its is 1
    /// Author           :Leovin.S
    /// Created          :6/29/16
    /// Last modified on :4/8/2016              

    #endregion Summary

    /// <summary>
    ///     Page for raising new asset requests and viewing transactions across various access levels
    /// </summary>
    public partial class Request1 : AssetTrackerBasePage
    {

        #region Global Variables

        private List<Assetsinsession> _contains = new List<Assetsinsession>();

        private List<AssetTranExtn> _filterquery = new List<AssetTranExtn>();
        public int Count { get; set; }
        private int? current;
        private int? previous = null;


        private List<AssetTranExtn> _mainds = new List<AssetTranExtn>();
        private List<AssetTranExtn> _assetsplitdatasource = new List<AssetTranExtn>();

        #endregion Global Variables

        #region PreDefined Methods

        /// <summary>
        ///     Generic method call
        /// </summary>
        /// <param name="sender">Page</param>
        /// <param name="e">events</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //throw new HttpException();
            grdAssetList.DataBind();
            if (!IsCallback)
            {
                if (Master != null)
                {
                    var lblMasterStatus = (Label)Master.FindControl("lblStatus");

                    lblMasterStatus.Text = "New Request";
                }
                AccessGroups = new List<string> { "AssetLead", "Approver" };
                IsInGroup();
                Loadpurpose();

            }
            if (grdAssetList.IsCallback)
            {
                Session["datatobind_grdAssetList"] = null;
                List<string> param = new List<string> { "PAGERONCLICK", "APPLYCOLUMNFILTER", "SORT", "CUSTOMCALLBACK" };
                if (!Request.Params["__CALLBACKPARAM"].Contains("clear"))
                    if (Request.Params["__CALLBACKPARAM"].Contains("PAGERONCLICK") || Request.Params["__CALLBACKPARAM"].Contains("APPLYCOLUMNFILTER") || Request.Params["__CALLBACKPARAM"].Contains("SORT") || Request.Params["__CALLBACKPARAM"].Contains("isforadding"))

                        Loadgrid();
            }

        }

        protected void Page_Init(object sender, EventArgs e)
        {
            if (Request.Params["__CALLBACKPARAM"] == null) return;
            if (!Request.Params["__CALLBACKPARAM"].ToLower().Contains("frompsid")) return;
            Loadgrid();

        }
        #endregion

        #region Action Oriented Methods

        #region grid specific methods
        /// ------------------Précis of logics being implemented--------------------
        /// Methods involving grdAssetSplit:
        ///       a)LoadConfirmationGrid()
        ///       b)Loadsplitgrid()
        /// Methods involving grdAssetList:
        ///       a)Loadgrid
        /// LoadConfirmationGrid():Used to load data when user switches between transaction
        ///                        log and new requirements
        ///                        The data provided to new request depends on the data pre
        ///                        existing before switching to transaction log
        /// LoadSplitGrid():Used to carry out one of the following functions
        ///                 a)Submit data for approval
        ///                   Required params:"submit"
        ///                   action params  :selected asset ids
        ///                   return params  :Number of success scenarios
        ///                 b)Transaction view to show all history
        ///                   Required params:"|"
        ///                   action params:HPSM number,Movemnt Type(user specific)
        ///                   return params:data set of data to bind
        /// Note:Following columns are made visible :currentstatus,nextstatus,overseer,comments
        ///      descriptionn
        ///                 c)Show current request if any on switch to new request
        ///                   Required params:"req"
        ///                   action params:N/A
        ///                   return params:N/A
        ///Note:Following columns are made invisible :currentstatus,nextstatus,overseer,comment
        ///     descriptionn
        ///     The load is based on the session
        /// LoadGrid():Used to load the popup grid based on the gang of three selection
        ///            Required params:BuildingID,FloorID(Nullable),SysAssetTypeID(Nullable)
        ///            action params:BuildingID,FloorID(Nullable),SysAssetTypeID(Nullable)
        ///            return params:data set of data to bind

        /// <summary>
        ///     To refresh the grid in one of the following scenarios
        ///     a)On submitting grids for approval
        ///     b)Switching to transaction log and switching back to request in the current scope
        /// </summary>
        public void LoadConfirmationGrid()
        {
           
        }

        /// <summary>
        ///     The method  which hnadles the data to be loaded to the split grid.It loads data for the following scenarios in
        ///     order
        ///     a)Appending of data based on the selected purpose type asset details
        ///     b)Submition of the entire data or selective data for approval
        ///     c)View the transaction log of the current user
        /// </summary>
        /// <param name="sender">AspxGridview grdAssetSplit</param>
        protected void Load_grdAssetSplit(ASPxGridView sender)
        {
            if (Session["typeof_assetsplitgrid_callbackparam"] == null) return;
            var type = Session["typeof_assetsplitgrid_callbackparam"].ToString();
            if (type == "submit")
            {
                //var fieldValues = grdAssetSplit.GetSelectedFieldValues("AssetId");

                //Submitforapproval(fieldValues);

                //if (fieldValues.Count == 0) return;
                //CustomCallbackReturnParameters(Count.ToString(), sender);
                //Count = 0;
            }
            else
            {
                if (type.Contains("|"))
                {
                    int? movementtypeid = null;
                    string hpsmnumber = null;

                    var sqlipparameters = type.Split('|');
                    if (sqlipparameters[0] != "null")
                        movementtypeid = int.Parse(sqlipparameters[0]);
                    if (sqlipparameters[1] != "null")
                        hpsmnumber = (sqlipparameters[1]);

                    sender.Selection.CancelSelection();

                    var iptransaction = new List<InputParameters>
                    {
                        //"null" ? (int?)null : Convert.ToInt32(sqlipparameters[1]),
                        new InputParameters {SqlParam = "UserPSID", ParamValue = GetPSID},
                        new InputParameters {SqlParam = "SysPurposeID", ParamValue = movementtypeid},
                        new InputParameters {SqlParam = "HPSMNo", ParamValue = hpsmnumber}
                    };
                    _assetsplitdatasource = QueryHelper.GettransactionLog(iptransaction).ConvertToAssetExtension();
                    sender.DataSource = _assetsplitdatasource;
                    Session["grid_filters"] = _assetsplitdatasource;

                    Setgridview(false, sender);

                    CustomCallbackReturnParameters("filter", sender);
                    sender.DataBind();
                }

            }
        }


        private void CustomCallbackReturnParameters(string param, ASPxGridView grid)
        {
            grid.JSProperties.Add("cpIsCustomCallback", null);
            grid.JSProperties["cpIsCustomCallback"] = param;

        }

        private void Setgridview(bool visible, ASPxGridView grid)
        {
            var columns = new List<string> { "CreatedOn", "CurrentStatus", "NextStatus", "ModDt", "OverSeer", "Comments", "Description", "PurposeName" };

            grid.Settings.ShowTitlePanel = visible;
            grid.Columns[0].Visible = visible;
            var bandCol = grid.Columns["Transaction"] as GridViewBandColumn;
            if (bandCol != null) bandCol.Visible = !visible;  //sets false if true ;if true false
            grid.Settings.ShowTitlePanel = visible;
            grid.DataColumns.ForEach(d =>
            {
                d.Visible = !columns.Contains((d.FieldName)) || !visible;
            }
           );
        }

        /// <summary>
        ///     Loads Asset List data to AspxGridview grdAssetList
        /// </summary>
        protected void Loadgrid(string typeofload = null)
        {
            List<AssetTranExtn> assets;
            var grdFilter = GetSessionValue<GridFilters>("GridFilters");
            if (grdFilter == null) return;


            var ipselection = new List<InputParameters>
            {
                new InputParameters {SqlParam = "BuildingID", ParamValue = grdFilter.BuildingId},
                new InputParameters {SqlParam = "FloorID", ParamValue = grdFilter.FloorId},
                new InputParameters {SqlParam = "SysAssetTypeID", ParamValue = grdFilter.AssetTypeId},
                new InputParameters {SqlParam = "SysPurposeID", ParamValue = grdFilter.SysPurposeID}
            };



            assets = QueryHelper.GetpopUpAssetgridData(ipselection).ConvertToAssetExtension();



            Session["datatobind_grdAssetList"] = assets;
            grdAssetList.DataSource = null;
            grdAssetList.DataBind();
            grdAssetList.DataSource = assets;
            grdAssetList.DataBind();
            grdAssetList.Selection.CancelSelection();
        }


        #endregion

        #region Default value Setting for comboboxes Methods
        ///------------------Précis of logics being implemented--------------------
        /// Methods involved:
        ///         a)Assigndefaultvalues()
        ///         b)Filteredrow()
        ///         c)SetValue()
        /// AssignDefaultValues():
        ///         Gets the webcontrol which requested default value and the purpose type
        ///         id for which the default values are to be set
        /// Required params:purose type id, Webcontrol which initiated the request
        /// Sub method call:Filteredrow()
        ///                 Setvalue()
        /// FilteredRow():
        ///         Gets the purposetype specific or PSID(in case of building to building)
        ///         set of defaults to be bound
        /// Required params:purpose type id
        /// returns :list of defaultids
        /// Sub method call :none
        /// SetValue:Sets the default value for the webcontrols
        /// Required params:list of defaultid,aspxcombobox or aspxspinedit
        /// Submethod call:none

        /// <summary>
        ///     To get the default data from the requested data set
        /// </summary>
        /// <param name="id">The selected parameter (purpose id or PSID ) based on which the filter should apply</param>
        /// <param name="type"></param>
        /// <returns>The filtered data row as a list of defaults</returns>
        protected void AssignDefaultvalues(int id, ASPxWebControl type)
        {
            if (Session["current"] == null)
            {
                Session["current"] = 0;
            }
            current = id;
            if (type == null) return;
            if (current != int.Parse(Session["current"].ToString()))
            {
                Session["current"] = current;

                Session["listsplit"] = Filteredrow(id);

            }

            var combo = type as ASPxComboBox;
            if (combo != null)
            {
                var cmbset = combo;
                Setvalue((List<DefaultLocation>)Session["listsplit"], cmbset);
            }
            else
            {
                var spnset = type as ASPxSpinEdit;
                Setvalue((List<DefaultLocation>)Session["listsplit"], null, spnset);
            }
        }

        /// <summary>
        ///     The main method called to get default values for predfined purposes
        /// </summary>
        /// <param name="id">selected purpose type</param>
        protected List<DefaultLocation> Filteredrow(int id)
        {
            DataSet defaultDsId;
            DataRow[] rows;
            // IEnumerable rows = null;


            defaultDsId = CacheHelper.GetInstance.GetValue("Deafaults", QueryHelper.GetDefaultLocationsForCache, 0, true, null);

            rows = defaultDsId.Tables[0].Select("SysPurposeID=" + id + "");

            if (rows.IsEmpty())
            {
                var ippsid = new List<InputParameters> { new InputParameters { SqlParam = "UserPSID", ParamValue = id } };
                defaultDsId = QueryHelper.GetDefaultBuildingtoBuuildingDataset(ippsid);
                rows = defaultDsId.Tables[0].Select("ToPSID=" + id + "");
            }

            return rows.Select(item => new DefaultLocation()
            {
                FromLocationID = ToNullableInt(item[1].ToString()),
                FromBuildingID = ToNullableInt(item[2].ToString()),
                FromFloorID = ToNullableInt(item[3].ToString()),
                FromCubicleID = ToNullableInt(item[4].ToString()),
                FromPSID = item[5].ToString(),
                ToLocationID = ToNullableInt(item[7].ToString()),
                ToBuildingID = ToNullableInt(item[8].ToString()),
                ToFloorID = ToNullableInt(item[9].ToString()),
                ToCubicleID = ToNullableInt(item[10].ToString()),
                ToPSID = item[11].ToString()
            }).ToList();
        }

        /// <summary>
        ///     Set the default value for Selected purpose
        /// </summary>
        /// <param name="setter">Gets the default value to be set</param>
        /// <param name="cmbset">Gets the combobox to be set with the default values</param>
        /// <param name="spnset">Gets the spin edit to be set with the default values</param>
        protected void Setvalue(List<DefaultLocation> setter = null, ASPxComboBox cmbset = null, ASPxSpinEdit spnset = null)
        {
            if (setter == null) return;

            Dictionary<string, string> lookup = new Dictionary<string, string>()
            {
                { "cmbLocFrom", "FromLocationID" },
                { "cmbAreafrom", "FromBuildingID" },
                { "cmbfromfloor", "FromFloorID" },
                { "cmbarea", "ToLocationID" },
                { "cmbbuilding", "ToBuildingID" },
                { "cmbfloor", "ToFloorID" },
                { "cmbcubicle", "ToCubicleID" }
            };


            foreach (var item in setter)
            {
                try
                {
                    if (cmbset != null)
                    {

                        string para;
                        if (lookup.TryGetValue(cmbset.ID, out para))   // TryGetValue, on popular request
                        {
                            var value = GetPropertyValue<int>(item, para);
                            cmbset.SelectedIndex = cmbset.Items.FindByValue(value.ToString()).Index;
                            cmbset.SelectedItem.Value = int.Parse(value.ToString());
                        }


                        cmbset.DataBind();
                        break;
                    }
                    if (spnset == null) continue;
                    switch (spnset.ID)
                    {
                        case "spnPsid":
                            spnset.Value = item.FromPSID;
                            spnset.Text = item.FromPSID.ToString();
                            break;
                    }
                    break;
                }
                catch
                {
                    break;
                    //throw new Exception("Warning Unauthorized Action detected !!!");
                }
            }
        }

        public T GetPropertyValue<T>(object source, string property)
        {
            object value = source.GetType().GetProperty(property).GetValue(source, null);
            if (value == null)
                return default(T);
            return (T)value;
        }


        #endregion

        #region Data Call Oriented Methods

        /// <summary>
        ///     Method which splits the data selected in grdAssetSplit for submit and refreshes the existing data source
        /// </summary>
        /// <param name="assetsSelected">list of ids selected in the AspxGridview grdAssetSplit</param>
        protected void Submitforapproval(List<object> assetsSelected = null)
        {
            if (Session["datatobind_grdAssetSplit"] == null) return;
            var list = (List<AssetTranExtn>)Session["datatobind_grdAssetSplit"];
            var assetSelected = (List<Assetsinsession>)Session["contains_selectedassets"];
            if (assetsSelected != null && assetsSelected.Count > 0)
            {
                foreach (var asset in assetsSelected)
                {
                    var selecetd = list.Where(x => x.AssetTranId == int.Parse(asset.ToString()));
                    var listsplit = selecetd.ToList();
                    Insert(listsplit);
                    Count++;

                    list.RemoveAll(r => r.AssetTranId == int.Parse(asset.ToString()));
                    assetSelected.RemoveAll(c => c.Assetid == asset.ToInt());
                }
                Session["datatobind_grdAssetSplit"] = list;
                Session["contains_selectedassets"] = assetSelected;
                LoadConfirmationGrid();
            }
            //bool dtat = db.ExecuteNonQuery(query, CommandType.Text, null);
        }

        /// <summary>
        ///     Method call to submit data for approval
        ///     The method calls the query helper to push data to server
        /// </summary>
        /// <param name="assets">List of data to be passed to stored procedure as in put parameters</param>
        protected void Insert(List<AssetTranExtn> assets)
        {
            foreach (var asset in assets)
            {
                var ipsubmitdata = new List<InputParameters>
                {
                    new InputParameters {SqlParam = "AssetID", ParamValue = asset.AssetId.ToString()},
                    new InputParameters {SqlParam = "HPSMNo", ParamValue = asset.HpsmNo},
                    new InputParameters {SqlParam = "SysPurposeID", ParamValue = asset.SysPurposeId},
                    new InputParameters {SqlParam = "FromFloorID", ParamValue = asset.FromFloorId},
                    new InputParameters {SqlParam = "FromCubicleID", ParamValue = asset.FromCubicleId},
                    new InputParameters {SqlParam = "FromPSID", ParamValue = asset.FromPsid},
                    new InputParameters {SqlParam = "FromBuildingEnggID", ParamValue = asset.FromBuildingEnggId},
                    new InputParameters {SqlParam = "ToFloorID", ParamValue = asset.ToFloorId},
                    new InputParameters {SqlParam = "ToCubicleID", ParamValue = asset.ToCubicleId},
                    new InputParameters {SqlParam = "ToPSID", ParamValue = asset.ToPsid},
                    new InputParameters {SqlParam = "MovementEnggID", ParamValue = asset.MovementEnggId},
                    new InputParameters {SqlParam = "ToBuildingEnggID", ParamValue = asset.ToBuildingEnggId},
                    new InputParameters {SqlParam = "UserPSID", ParamValue = GetPSID},
                    new InputParameters {SqlParam = "EndUserCubicleID", ParamValue = asset.EndUserCubicleID},
                    new InputParameters {SqlParam = "IsReplacement", ParamValue = asset.IsReplacement},
                    new InputParameters {SqlParam = "ReplacementDate", ParamValue = asset.ReplacementDate},


                };
                if (asset.SysPurposeId == GetPurposeID("Building to building"))
                {
                    ipsubmitdata.Add(new InputParameters { SqlParam = "EndUserID", ParamValue = asset.ToPsid });
                }
                else
                {
                    ipsubmitdata.Add(new InputParameters { SqlParam = "EndUserID", ParamValue = asset.EndUserId });
                }
                QueryHelper.SubmitAssetMovement(ipsubmitdata);
            }
        }

        #endregion Data Call Oriented Methods

        #endregion

        #region Callbacks

        #region Grid Callbacks

        /// ------------------Functionality of Grid Views---------------------------
        /// @)The grdAssetList does one of the following functions
        /// a)Gets data based on the Location set
        /// b)Pushes the selected data to grdAssetSplit
        /// c)Self clears the data on one of the following scenarios
        /// c.1)Close of pop up or dismisall
        /// c.2)Push of data to grdAssetSplit
        /// @)The grdAssetsplit does one of the following functions
        /// a)Displays the selected data from the popup
        /// b)Submits the data as a whole or selectively
        /// c)Shows the history of transactions for the current loggedin user
        /// ------------------Précis of logics being implemented--------------------
        /// grdAssetList:
        /// **************************Scenario 1************************************
        /// The grid loads based on the data sent from the gang of three
        /// a)BuildingID
        /// b)FloorID (can be passed null)
        /// c)AssetTypeID (can be passed null)
        /// The data is sent from the three with a seperator '|' based on which the
        /// split happens and passed to request sp and the grid shows the data
        /// Requested parameter:'BuildingID|FloorID|AssetTypeID'
        /// **************************Scenario 2**************************************
        /// The grid clears the data and reloads empty based on one of the following
        /// a)Close of pop-up window
        /// b)data pushed for main grid for the following purposes
        /// b.1)Building to Building
        /// Requested parameter:'clear'
        /// **************************Scenario 3**************************************
        /// The grid pushes data to the main grid grdAssetSplit
        /// This happens in two ways and is combined in one method
        /// a)data sent from the callbackwith a seprator'/'
        /// b)filtered row data of the dataset based on the selected assetID
        /// Requested Parameter:
        /// a)from callback:   'FromBuilding/ToArea/ToBuilding/ToFloorId/ToFloor/ToCubicleId/ToCubicle/Engineer/Psid/FromArea/HPSMNo/ToPSID/SelectedPurposeId'
        /// b)filtered data:   'AssetTrackerID,Serialnumber,FARNumber,FromCubicle,AssetType,FloorNo,FromPSID,FromId,FromCubicleId'
        /// <summary>
        ///     The callback from grdassetList to load/push data in the following scenarios in order
        ///     a)Grid loads data based on the selected building ,floor , asset type
        ///     b)clears the data on add click or close of the form
        ///     c)Provides data to asset split grid on add click
        /// </summary>
        /// <param name="sender">AspxGridView grdAssetSplit</param>
        /// <param name="e">events</param>
        protected void grdAssetList_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            var grdAssetlistcallbackvalues = e.Parameters;

            if (grdAssetlistcallbackvalues.Contains("|"))
            {
                var sqlipparameters = grdAssetlistcallbackvalues.Split('|');
                var grdFilter = new GridFilters
                {
                    AssetTypeId = sqlipparameters[1] == "null" ? (int?)null : Convert.ToInt32(sqlipparameters[1]),
                    BuildingId = sqlipparameters[0] == "null" ? (int?)null : Convert.ToInt32(sqlipparameters[0]),
                    FloorId = sqlipparameters[2] == "null" ? (int?)null : Convert.ToInt32(sqlipparameters[2]),
                    SysPurposeID = sqlipparameters[4] == "null" ? (int?)null : Convert.ToInt32(sqlipparameters[4]),

                };
                Session["GridFilters"] = grdFilter;
                Loadgrid(sqlipparameters[3]);



            }
            else
            {
                if (e.Parameters == "clear")
                {
                    Session["datatobind_grdAssetList"] = null;
                    var gvProject = sender as ASPxGridView;
                    if (gvProject == null) return;
                    gvProject.FilterExpression = "";
                    gvProject.DataSource = Session["datatobind_grdAssetList"];
                    gvProject.DataBind();
                    gvProject.Selection.UnselectAll();
                }
                else
                {
                    var fieldValues = grdAssetList.GetSelectedFieldValues("AssetId");
                    var grdAssetListDatasource = (List<AssetTranExtn>)Session["datatobind_grdAssetList"];
                    if (Session["contains_selectedassets"] != null)
                    {
                        _contains = (List<Assetsinsession>)Session["contains_selectedassets"];
                    }
                    if (Session["datatobind_grdAssetSplit"] != null)
                    {
                        _mainds = (List<AssetTranExtn>)Session["datatobind_grdAssetSplit"];
                    }
                    foreach (var fielditem in fieldValues)
                    {
                        var sqlipparameters = grdAssetlistcallbackvalues.Split('/');

                        if (grdAssetListDatasource == null) continue;
                        var item = grdAssetListDatasource.FirstOrDefault(x => x.AssetId == (int?)fielditem);

                        //foreach (var item in rows)
                        //{
                        var exists = _mainds.Any(x => x.AssetId == item.AssetId);
                        if (exists) continue;

                        _contains.Add(new Assetsinsession { Assetid = (int?)fielditem });

                        _mainds.Add(new AssetTranExtn
                        {
                            AssetTranId = item.AssetId.Value,
                            AssetId = item.AssetId,
                            SerialNo = item.SerialNo,
                            FARNumber = item.FARNumber,
                            FromCubicleNo = item.FromCubicleNo,
                            AssetType = item.AssetType,
                            FromFloor = item.FromFloor,
                            FromPsid = item.FromPsid,
                            FromFloorId = item.FromFloorId,
                            FromCubicleId = item.FromCubicleId,
                            FromBuilding = sqlipparameters[0],
                            ToArea = sqlipparameters[2],
                            ToBuilding = sqlipparameters[4],
                            ToFloorId = sqlipparameters[5] == "" ? null : sqlipparameters[5].ToInt(),
                            ToFloor = sqlipparameters[6],
                            ToCubicleId = sqlipparameters[7] == "" ? null : sqlipparameters[7].ToInt(),
                            ToCubicleNo = sqlipparameters[8],
                            MovementEnggId = sqlipparameters[9] == "null" ? null : sqlipparameters[9].ToString(),
                            Psid = sqlipparameters[9],
                            FromArea = sqlipparameters[10],
                            HpsmNo = sqlipparameters[11].ToString(),
                            ToPsid = sqlipparameters[12].ToString(),
                            SysPurposeId = sqlipparameters[13] == "" ? null : sqlipparameters[13].ToInt(),
                            FromBuildingEnggId = sqlipparameters[15].ToString(),
                            ToBuildingEnggId = sqlipparameters[14].ToString(),
                            EndUserId = sqlipparameters[16].ToString(),
                            EndUserCubicleID = sqlipparameters[17] == "" ? null : sqlipparameters[17].ToInt(),
                            IsReplacement = sqlipparameters[18].ToString() == "null" ? false : (bool.Parse(sqlipparameters[18])),
                            ReplacementDate = sqlipparameters[19].ToString() == "null" || sqlipparameters[18].ToString() == "false" || sqlipparameters[18].ToString() == "null" ? "" : sqlipparameters[19].ToString()

                        });
                        //}
                    }

                    Session["contains_selectedassets"] = _contains;
                    Session["datatobind_grdAssetSplit"] = _mainds;
                    LoadConfirmationGrid();
                }
            }
        }

        protected void ToPsidCombo_CustomJSProperties(object sender, CustomJSPropertiesEventArgs e)
        {
            ArrayList listCID = new ArrayList();
            ArrayList listFID = new ArrayList();
            foreach (ListEditItem item in cmbenduserdetails.Items)
            {
                listCID.Add(item.GetValue("ToCubicleId"));
                listFID.Add(item.GetValue("ToFloorId"));
            }
            e.Properties["cpHiddenToCubicle"] = listCID;
            e.Properties["cpHiddenToFloor"] = listFID;
        }
        /// <summary>
        ///     The calll back from grdAssetSplit which provides the type parameter for the grid to load
        /// </summary>
        /// <param name="sender">AspxGridview grdAssetSplit</param>
        /// <param name="e">events</param>
        protected void grdAssetSplit_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            var parameter = e.Parameters;
            Session["typeof_assetsplitgrid_callbackparam"] = parameter;
            var gv = (ASPxGridView)sender;
            Load_grdAssetSplit(gv);
        }

        #endregion

        #region Combobox Callbacks

        /// In order of loading
        /// a)Location        (depends on cache)
        /// b)Building        (Depends on selected Location ID)
        /// C)Floor           (Depends on selected Building ID)
        /// d)Cubicle         (Depends On selected Floor Id)
        /// e)Asset Type      (Independent)
        /// f)Enginner Data   (Independent)
        /// Filter for Transaction Log
        /// a)HPSMNumber,Movement Type (Depends on Logged in user PSID)
        /// ------------------Précis of logics being implemented--------------------
        /// Logic being implemented:
        /// -The returnig parameter is checked for string splitter
        /// -If exists then default values are processed
        /// -Currently for the following purposes are set as default requestors
        /// a)Store to Building
        /// b)default Ready
        /// c)Stage to Building
        /// Requested parameter:Purpose Type selected ID
        /// -The following purposes are set as default on demand requestors
        /// a)Building to Building
        /// Requested parameter:Selected asset Type owner's PSID
        /// ------------------Flow of data between Comboboxes---------------------
        /// Location(cache)->Building(selected LocationID)->Floor(Selected BuildingID)
        /// ->Cubicle(selected FloorID)->PSID(selected CubicleID)
        /// -------------------Method of call--------------------------------------
        /// Call backs:cmbarea,cmbAssetType,cmbbuilding,cmbcubicle,cmbengineer,cmbfloor
        /// Page Load:Purpose Combobox
        /// <summary>
        ///     to bind data to Location from Cache object
        /// </summary>
        /// <param name="sender">AspxComboBox</param>
        /// <param name="e">events</param>
        protected void cmbarea_Callback(object sender, CallbackEventArgsBase e)
        {
            var combo = sender as ASPxComboBox;

            string[] defaulttran = null;

            if (e.Parameter.Contains('|'))
            {
                Session["isdefaultid_flag"] = true;
                defaulttran = e.Parameter.Split('|');
            }
            else
            {
                Session["isdefaultid_flag"] = false;
            }
            if (combo != null)
            {
                combo.DataSource = CacheHelper.GetInstance.GetValue("location", QueryHelper.GetLocations, 0, true, null);
                combo.TextField = "LocationName";
                combo.ValueField = "LocationID";
                combo.DataBind();

                if ((bool)Session["isdefaultid_flag"] != true) return;
                if (defaulttran == null) return;
                AssignDefaultvalues(int.Parse(defaulttran[0]), combo);


            }
            if (defaulttran != null) Session["purposesystype"] = defaulttran[0];
        }

        /// <summary>
        ///     Call back to load list of asset Types available
        /// </summary>
        /// <param name="sender">AspxComboBox cmbAssetType</param>
        /// <param name="e">events</param>
        protected void cmbAssetType_Callback(object sender, CallbackEventArgsBase e)
        {
            var ds = QueryHelper.GetAssetType();

            {
                cmbAssetType.DataSource = ds;
                cmbAssetType.TextField = "AssetType";
                cmbAssetType.ValueField = "SysAssetTypeID";
                cmbAssetType.DataBind();
            }
        }

        /// <summary>
        ///     to bind data to building  combo box based on the selected location for from and to
        /// </summary>
        /// <param name="sender">AspxComboBox</param>
        /// <param name="e">events</param>
        protected void cmbbuilding_Callback(object sender, CallbackEventArgsBase e)
        {

            var combo = sender as ASPxComboBox;

            //var ipbuildingonlocation = new List<InputParameters>
            //{
            //    new InputParameters {SqlParam = "LocationID", ParamValue = e.Parameter},
            //    new InputParameters {SqlParam = "PSID", ParamValue = Session["PSID"].ToString()},
            //    new InputParameters
            //    {
            //        SqlParam = "ApplicationID",
            //        ParamValue = Convert.ToInt16(ConfigurationManager.AppSettings["ApplicationID"]).ToString()
            //    }
            //};

            if (combo == null) return;

            //combo.DataSource = QueryHelper.GetBlockBasedOnLocation(ipbuildingonlocation);
            if (!string.IsNullOrEmpty(e.Parameter))
            {
                combo.DataSource = UIHelper.Helper.GetBuildings(Convert.ToInt32(e.Parameter));
                combo.TextField = "BuildingName";
                combo.ValueField = "BuildingID";
                combo.DataBind();
            }

            if ((bool?)Session["isdefaultid_flag"] != true) return;
            if (Session["purposesystype"] != null)
                AssignDefaultvalues(int.Parse(Session["purposesystype"].ToString()), combo);
        }

        /// <summary>
        ///     to bind data to floor  combo box based on the selected building for from and to
        /// </summary>
        /// <param name="sender">AspxComboBox</param>
        /// <param name="e">events</param>
        protected void cmbfloor_Callback(object sender, CallbackEventArgsBase e)
        {
            var combo = sender as ASPxComboBox;

            //var ipareabasedonblock = new List<InputParameters>
            //{
            //    new InputParameters {SqlParam = "BuildingID", ParamValue = e.Parameter},
            //    new InputParameters {SqlParam = "PSID", ParamValue = Session["PSID"].ToString()},
            //    new InputParameters
            //    {
            //        SqlParam = "ApplicationID",
            //        ParamValue = Convert.ToInt16(ConfigurationManager.AppSettings["ApplicationID"]).ToString()
            //    }
            //};

            if (combo == null) return;
            if (!string.IsNullOrEmpty(e.Parameter))
            {

                //combo.DataSource = QueryHelper.GetAreaBasedOnBlock(ipareabasedonblock);
                combo.DataSource = UIHelper.Helper.GetFloors(Convert.ToInt32(e.Parameter));
                combo.TextField = "FloorNo";
                combo.ValueField = "BuildingFloorID";
                combo.DataBind();
            }
            if ((bool?)Session["isdefaultid_flag"] != true) return;
            if (Session["purposesystype"] != null)
                AssignDefaultvalues(int.Parse(Session["purposesystype"].ToString()), combo);
        }

        /// <summary>
        ///     To bind data to cubicle combo box based on the selected floor for from and to
        /// </summary>
        /// <param name="sender">AspxComboBox </param>
        /// <param name="e">events</param>
        protected void cmbcubicle_Callback(object sender, CallbackEventArgsBase e)
        {
            var combo = sender as ASPxComboBox;

            var ipcubiclebasedonarea = new List<InputParameters>
            {
                new InputParameters {SqlParam = "BuildingFloorID", ParamValue = e.Parameter}
            };

            if (combo == null) return;
            combo.DataSource = QueryHelper.GetCubicleBasedOnArea(ipcubiclebasedonarea);
            combo.TextField = "CubicleNo";
            combo.ValueField = "CubicleID";
            combo.DataBind();
            if ((bool?)Session["isdefaultid_flag"] != true) return;
            if (Session["purposesystype"] != null)
                AssignDefaultvalues(int.Parse(Session["purposesystype"].ToString()), combo);
            Session["isdefaultid_flag"] = false;
        }

        /// <summary>
        ///     Callback to load Engineer combox
        /// </summary>
        /// <param name="sender">AspxComboBox cmbengineer</param>
        /// <param name="e">events</param>
        protected void cmbengineer_Callback(object sender, CallbackEventArgsBase e)
        {

            ASPxComboBox combobox = sender as ASPxComboBox;
            var cmbEngineerDatasource =
                UIHelper.Helper.GetBuildingEngineersDistinct();
            if (combobox == null) return;
            combobox.DataSource = cmbEngineerDatasource;
            combobox.DataBind();
        }

        #endregion Combobox Callbacks

        #region Filter Combo Boxes

        /// <summary>
        ///     Call back for loading HPSM filter
        /// </summary>
        /// <param name="sender">AspxComboBox cmbhpsmnumber</param>
        /// <param name="e">events</param>
        protected void cmbhpsmnumber_Callback(object sender, CallbackEventArgsBase e)
        {

            Loadfilters(sender as ASPxComboBox, "HPSMNo", "HPSMNo", "HPSMNo");

        }

        /// <summary>
        ///     Call back for loading Purpose type filter
        /// </summary>
        /// <param name="sender">AspxComboBox cmbpurposetype</param>
        /// <param name="e">events</param>
        protected void cmbpurposetype_Callback(object sender, CallbackEventArgsBase e)
        {

            Loadfilters(sender as ASPxComboBox, "PurposeName", "SysPurposeId", "Purpose");
        }


        protected void Loadfilters(ASPxComboBox sender, string textfield, string valuefield, string filter)
        {

            _filterquery = (List<AssetTranExtn>)Session["grid_filters"];
            switch (filter)
            {
                case "HPSMNo":
                    sender.DataSource = _filterquery.GroupBy(x => x.HpsmNo).Select(y => y.First());
                    break;
                case "Purpose":
                    sender.DataSource = _filterquery.GroupBy(x => x.SysPurposeId).Select(y => y.First());
                    break;
            }
            sender.TextField = textfield;
            sender.ValueField = valuefield;
            sender.DataBind();
        }


        #endregion

        #region Callback Pannel Callbacks

        /// <summary>
        ///     To set the PSID for To location on one of the following senarios
        ///     a)Default Purpose Type values
        ///     b)Dependent values based on Cubicle
        ///     c)Building to building single psid data
        /// </summary>
        /// <param name="sender">AspxCallBackPannel txtcallback</param>
        /// <param name="e">events</param>
        protected void txtcallback_Callback(object sender, CallbackEventArgsBase e)
        {
            if (!e.Parameter.Contains('|'))
            {
                var ipcubicleid = new List<InputParameters>
                {
                    new InputParameters {SqlParam = "CubicleID", ParamValue = e.Parameter}
                };
                var dtLoginInfo = QueryHelper.GetPSID(ipcubicleid).Tables[0];
                spnPsid.Text = dtLoginInfo.Rows.Count > 0 ? dtLoginInfo.Rows[0]["PSID"].ToString() : string.Empty;
            }
            else
            {
                var defaulttran = e.Parameter.Split('|');
                spnPsid.Text = defaulttran[0];
            }
            //if ((bool?)Session["isdefaultid_flag"] != true) return;
            //if (Session["purposesystype"] != null)
            //    AssignDefaultvalues(int.Parse(Session["purposesystype"].ToString()), spnPsid);
            //Session["isdefaultid_flag"] = false;
        }

        #endregion Callback Pannel Callbacks

        #endregion

        #region Devexpress event Handlers

        /// <summary>
        ///     To prevent the selected data from  being selected again in the same scope at a differet time before the data is
        ///     submitted
        /// </summary>
        /// <param name="sender">ASPxGridView grdAssetList</param>
        /// <param name="e">events</param>
        protected void grdAssetList_CommandButtonInitialize(object sender, ASPxGridViewCommandButtonEventArgs e)
        {
            if (Session["contains_selectedassets"] == null) return;
            var assetsInSession = (List<Assetsinsession>)Session["contains_selectedassets"];
            var grid = (ASPxGridView)sender;

            foreach (var item in assetsInSession)
            {
                if (grid != null && (int?)grid.GetRowValues(e.VisibleIndex, "AssetId") == item.Assetid)
                {
                    e.Enabled = false;
                }
            }
        }

        /// <summary>
        ///     The Binding of the confirmation grid whic has the data of the selected assets
        /// </summary>
        /// <param name="sender">AspxGridview grdAssetSplit</param>
        /// <param name="e">events</param>
        protected void grdAssetSplit_Init(object sender, EventArgs e)
        {
            var gvProject = sender as ASPxGridView;

            if (Session["datatobind_grdAssetSplit"] != null)
            {
                var list = (List<AssetTranExtn>)Session["datatobind_grdAssetSplit"];
                if (gvProject == null) return;
                gvProject.DataSource = list;
                gvProject.DataBind();
            }
            else
            {
                if (gvProject == null) return;
                gvProject.DataSource = null;
                gvProject.DataBind();
            }
        }


        #endregion Devexpress event Handlers

        #region Combox data source (Only combobox which loads without call back)

        /// <summary>
        ///     To load data to combox box purpose.Purpose provides a list of purposes
        /// </summary>
        protected void Loadpurpose()
        {

            var availablePurposetypes = CacheHelper.GetInstance.GetValue("Purposes", new Queries().GetPurposeDictionary, 100, true, null);
            cmbtype.DataSource = availablePurposetypes.ToList();
            cmbtype.TextField = "Value";
            cmbtype.ValueField = "Key";
            cmbtype.DataBind();
        }

        #endregion Combox data source (Only combobox which loads without call back)
        protected void cmbEndUserPsid_Callback(object sender, CallbackEventArgsBase e)
        {
            var ipGetUserDetails = new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserPSID", ParamValue = string.Empty},
                new InputParameters {SqlParam = "CubicleID", ParamValue = null}
            };
            var ds = QueryHelper.GetUserDetails(ipGetUserDetails);
            cmbenduserdetails.DataSource = ds;
            cmbenduserdetails.DataBind();
        }




        public Object GetObject(string key, Dictionary<string, ASPxLabel> dict)
        {

            if (dict.ContainsKey(key))
                return dict[key];
            return null;
        }


        /// <summary>
        ///     Generic call for checking if the inherent source is a nullable int
        /// </summary>
        /// <param name="s">string to be checked</param>
        /// <returns>inteher or null</returns>
        public int? ToNullableInt(string s)
        {
            int i;
            if (int.TryParse(s, out i)) return i;
            return null;
        }

        /// <summary>
        ///     class to maintain the selected check boxes across grdAssetplit and grd AssetList
        /// </summary>
        public class Assetsinsession
        {
            public int? Assetid { get; set; }
        }




        internal class GridFilters
        {
            public int? AssetTypeId { get; set; }

            public int? BuildingId { get; set; }
            public int? FloorId { get; set; }

            public int? SysPurposeID { get; set; }
        }


    }


}