﻿using AssetManagement.Tasks;
using AssetManagementLibrary.Entities.Movement;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AssetManagementLibrary.OtherHelpers;
using AssetManagement.UIHelper;

namespace AssetManagement.Movement
{
    public partial class TransactionLog : AssetTrackerBasePage
    {
        #region Global Variables

        private List<AssetTranExtn> _assetsplitdatasource = new List<AssetTranExtn>();
        private List<AssetTranExtn> _filterquery = new List<AssetTranExtn>();

        #endregion



        #region Event Handlers

        /// <summary>
        /// Page load event handler, check for page access, fill data into gridview and filter dropdowns
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Master != null)
            {
                var lblMasterStatus = (Label)Master.FindControl("lblStatus");

                lblMasterStatus.Text = "Transaction Log";
            }

            //Page access groups
            AccessGroups = new List<string> { "AssetLead", "Approver","Tier1Lead" };
            IsInGroup();

            if (!Page.IsPostBack)
            {
                SetDate();
                Load_grdAssetSplit(grdAssetSplit);
            }

            if (grdAssetSplit.IsCallback)
            {
                Load_grdAssetSplit(grdAssetSplit);
            }

            chkShowAll.CheckedChanged += ChkShowAll_CheckedChanged;

        }


        void SetDate()
        {
            deEnd.DateRangeSettings.MinDayCount = 0;
            int maxDayCount = Helper.GetTransactionLogDuration();
            if (maxDayCount >= 0 && maxDayCount < deEnd.DateRangeSettings.MinDayCount)
                maxDayCount = deEnd.DateRangeSettings.MinDayCount;
            deEnd.DateRangeSettings.MaxDayCount = maxDayCount;
            //seMaxDayCount.Value = deEnd.DateRangeSettings.MaxDayCount;

            deStart.Value = DateTime.Now.AddDays(-29);
            deStart.MaxDate = DateTime.Now;
            deEnd.MaxDate = DateTime.Now;
            deEnd.Value = DateTime.Now;
            tbInfo.Value = "30 days";
        }

        private void ChkShowAll_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShowAll.Checked)
            {
                deStart.Value = null;
                deEnd.Value = null;
                deStart.Enabled = false;
                deEnd.Enabled = false;
                tbInfo.Value = "0 days";
                btnSubmit.Enabled = false;

            }
            else
            {
                SetDate();
                btnSubmit.Enabled = true;
                deStart.Enabled = true;
                deEnd.Enabled = true;

            }


            List<InputParameters> iptransaction = Setparam();
            _assetsplitdatasource = QueryHelper.GettransactionLog(iptransaction).ConvertToAssetExtension();
            grdAssetSplit.DataSource = _assetsplitdatasource;
            grdAssetSplit.DataBind();

            Session["grid_filters"] = _assetsplitdatasource;
        }

        /// <summary>
        /// Export grid data into Excel sheet
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Export_Click(object sender, ImageClickEventArgs e)
        {
            Load_grdAssetSplit(grdAssetSplit);
            GridViewExporter.FileName = "TransactionLogReport_" + DateTime.Now.Date;
            GridViewExporter.WriteXlsToResponse();


        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (IsPostBack && ASPxEdit.ValidateEditorsInContainer(this))
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "alert",
                //        @"<script type=""text/javascript"">alert('The form has been submitted successfully.');</script>");

                List<InputParameters> iptransaction = Setparam();
                _assetsplitdatasource = QueryHelper.GettransactionLog(iptransaction).ConvertToAssetExtension();
                grdAssetSplit.DataSource = _assetsplitdatasource;
                grdAssetSplit.DataBind();

                Session["grid_filters"] = _assetsplitdatasource;
            }
        }


        #endregion



        #region User Defined Functions

        /// <summary>
        /// Load data into gridview and store in a session object to be used by the filter dropdowns
        /// </summary>
        /// <param name="sender">AspxGridview grdAssetSplit</param>
        protected void Load_grdAssetSplit(ASPxGridView sender)
        {
            List<InputParameters> iptransaction = Setparam();
            _assetsplitdatasource = QueryHelper.GettransactionLog(iptransaction).ConvertToAssetExtension();
            sender.DataSource = _assetsplitdatasource;
            sender.DataBind();

            Session["grid_filters"] = _assetsplitdatasource;
        }


        List<InputParameters> Setparam()
        {
            TimeSpan tsMin = TimeSpan.Parse("00:00:00");
            TimeSpan tsMax = TimeSpan.Parse("23:59:59");
            List<InputParameters> iptransaction = new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserPSID", ParamValue = GetPSID},
                new InputParameters {SqlParam = "SysPurposeID", ParamValue = null},
                new InputParameters {SqlParam = "HPSMNo", ParamValue = null},
                new InputParameters {SqlParam = "FromDate", ParamValue =(deStart.Value!=null? (Convert.ToDateTime(deStart.Value).Add(tsMin)):deStart.Value)},
                new InputParameters {SqlParam = "ToDate", ParamValue =(deEnd.Value!=null?(Convert.ToDateTime(deEnd.Value).Add(tsMax)):deEnd.Value )}//DateTime.Now}
            };

            return iptransaction;
        }

        /// <summary>
        /// Bind filter data for dropdown based on passed arguments
        /// </summary>
        /// <param name="sender">Dropdown to be binded to</param>
        /// <param name="textfield">Textfield of the dropdown</param>
        /// <param name="valuefield">Valuefield of the dropdown</param>
        /// <param name="filter">Filter name to identify type of dropdown</param>
        protected void Loadfilters(ASPxComboBox sender, string textfield, string valuefield, string filter)
        {
            _filterquery = (List<AssetTranExtn>)Session["grid_filters"];
            switch (filter)
            {
                case "HPSMNo":
                    sender.DataSource = _filterquery.GroupBy(x => x.HpsmNo).Select(y => y.First());
                    break;
                case "Purpose":
                    sender.DataSource = _filterquery.GroupBy(x => x.SysPurposeId).Select(y => y.First());
                    break;
            }
            sender.TextField = textfield;
            sender.ValueField = valuefield;
            sender.DataBind();
        }

        #endregion

    }
}