﻿using AssetManagement.Tasks;
using AssetManagementLibrary;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.Entities.Movement;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AssetManagement.UIHelper;

namespace AssetManagement.Movement
{
    public partial class Configuration : AssetTrackerBasePage
    {

        #region Event Handlers

        /// <summary>
        /// Page load event handler, check for page access, Purpose dropdown and Grid data are filled
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {

            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Configuration";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "Tier1Engg" };
            IsInGroup();

            //Purpose dropdown is populated only once on page load
            if (!Page.IsPostBack)
            {
                LoadGrid();
            }

            //When page is in Postback, call LoadGrid function to refresh grid data
            if (ConfigGrid.IsCallback)
            {
                if (Request.Params["__CALLBACKPARAM"].Contains("PAGERONCLICK") || Request.Params["__CALLBACKPARAM"].Contains("APPLYCOLUMNFILTER") || Request.Params["__CALLBACKPARAM"].Contains("SORT"))
                {
                    LoadGrid();
                }
            }
        }


        /// <summary>
        /// Custom action button is rendered depending upon next status for any particular request row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ConfigGrid_HtmlRowCreated(object sender, ASPxGridViewTableRowEventArgs e)
        {
            //if current row has data
            if (e.RowType == DevExpress.Web.GridViewRowType.Data)
            {
                string KeyVal = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetTranId").ToString();
                string[] splitObj = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "NextStageInfo").ToString().Split('|');
                var comments = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "Comments") == null ? "null" : ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "Comments").ToString();
                var AssetType = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetType").ToString();
                string assetdata = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "HpsmNo").ToString() + '|' + ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "SerialNo").ToString() + '|' + ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetType").ToString();

                //Loop through possible next stage available for request
                foreach (var item in splitObj)
                {
                    ASPxButton CustBtn = new ASPxButton();
                    CustBtn.ID = String.Format("CustBtn{0}{1}", KeyVal, item.Split('-')[0]);
                    CustBtn.Text = item.Split('-')[1];

                    switch (CustBtn.Text)
                    {
                        case "Ready_For_Deploy": CustBtn.CssClass = "custom"; CustBtn.ImageUrl = "../Images/acknowledge.png"; CustBtn.Attributes.Add("comments", ""); break;
                        case "T1E_Reject": CustBtn.CssClass = "reject"; CustBtn.ImageUrl = "../Images/rejecticon.png"; CustBtn.Attributes.Add("type", "reject"); CustBtn.Attributes.Add("comments", comments); break;
                        case "OK": CustBtn.CssClass = "custom"; CustBtn.ImageUrl = "../Images/acknowledge.png"; CustBtn.Attributes.Add("comments", ""); break;
                        case "NOT OK": CustBtn.CssClass = "reject"; CustBtn.ImageUrl = "../Images/rejecticon.png"; CustBtn.Attributes.Add("type", "handover"); CustBtn.Attributes.Add("comments", comments); break;
                        case "Accept_Movement": CustBtn.CssClass = "custom"; CustBtn.ImageUrl = "../Images/acknowledge.png"; CustBtn.Attributes.Add("comments", ""); break;
                        default:
                            break;
                    }
                    
                    CustBtn.Attributes.Add("AssetTranID", KeyVal);
                    CustBtn.Attributes.Add("status", item.Split('-')[1]);
                    CustBtn.Attributes.Add("NextStatusID", item.Split('-')[0]);                    
                    CustBtn.Attributes.Add("AssetType", AssetType);
                    CustBtn.Attributes.Add("content", assetdata);
                    CustBtn.HorizontalAlign = HorizontalAlign.Center;
                    CustBtn.AutoPostBack = false;
                    CustBtn.Image.Width = 20;
                    CustBtn.Image.Height = 20;
                    CustBtn.ClientSideEvents.Click = "CustomButtonOnClick";
                    e.Row.Cells[11].Controls.Add(CustBtn);
                }

            }

        }



        /// <summary>
        /// In Handover process flow, if status selected as OK/NOT-OK, then send asynchronous mail for asset team with asset details for asset reception
        /// </summary>
        /// <param name="HpsmNo"></param>
        /// <param name="AssetType"></param>
        /// <param name="SerialNo"></param>
        /// <param name="Status"></param>
        /// <param name="StatusBy"></param>
        /// <param name="Comments"></param>
        /// <param name="psid"></param>
        /// <param name="name"></param>
        /// <param name="cubicleno"></param>
        /// <param name="floor"></param>
        /// <param name="building"></param>
        /// <param name="ToEmailID"></param>
        private void SendHandoverMail(string HpsmNo, string AssetType, string SerialNo, string Status, string StatusBy, string Comments, string psid, string name, string cubicleno, string floor, string building, string ToEmailID, string MailSubject)
        {
            Task.Factory.StartNew(() =>
            {
                try
                {
                    string mailBody = "";
                    using (var reader = new StreamReader(Server.MapPath("~/Templates/HandoverEmailTemplate.html")))
                    {
                        mailBody = String.Format(reader.ReadToEnd(), System.DateTime.Now.ToString("dd/MM/yyyy"), HpsmNo, AssetType, SerialNo, Status, StatusBy, Comments, psid, name, cubicleno, floor, building);
                    }
                    //UIHelper.Helper.SendEmail(mailBody, ToEmailID, MailSubject);
                    //10/04/2017
                    EMailHelper email = new EMailHelper();
                    email.Sender = ConfigurationManager.AppSettings["EmailFromAddress"].ToString();

                    //if email is not deployed, use dummy email address
                    if (Convert.ToBoolean(ConfigurationManager.AppSettings["IsEmailDeployed"]))
                        email.Recipient = ToEmailID;
                    else
                    {
                        email.Recipient = ConfigurationManager.AppSettings["DummyEmailAddress"].ToString();
                    }
                    email.RecipientCC = (String.IsNullOrEmpty(ConfigurationManager.AppSettings["EmailCCAddress"].ToString())) ? null : ConfigurationManager.AppSettings["EmailCCAddress"].ToString();
                    email.RecipientBCC = (String.IsNullOrEmpty(ConfigurationManager.AppSettings["EmailBCCAddress"].ToString())) ? null : ConfigurationManager.AppSettings["EmailBCCAddress"].ToString();
                    email.Subject = MailSubject;
                    email.Body = mailBody;
                    email.Send();
                }
                catch (Exception)
                {

                }
            });

        }



        /// <summary>
        /// On BE Deploy action, send template mail to user asynchronously
        /// </summary>
        /// <param name="ToName"></param>
        /// <param name="ToBuilding"></param>
        /// <param name="ToArea"></param>
        /// <param name="ToCubicleNo"></param>
        /// <param name="HpsmNo"></param>
        /// <param name="AssetType"></param>
        /// <param name="SerialNo"></param>
        /// <param name="ToEmailID"></param>
        private void SendDeploymentMail(string ToName, string ToBuilding, string ToArea, string ToCubicleNo, string HpsmNo, string AssetType, string SerialNo, string ToEmailID, string MailSubject)
        {
            Task.Factory.StartNew(() =>
            {
                try
                {
                    string mailBody = "";
                    using (var reader = new StreamReader(Server.MapPath("~/Templates/MailTemplate.html")))
                    {
                        mailBody = String.Format(reader.ReadToEnd(), ToName, ToBuilding, ToArea, ToCubicleNo, HpsmNo, AssetType, SerialNo);
                    }
                    UIHelper.Helper.SendEmail(mailBody, ToEmailID, MailSubject);
                }
                catch (Exception)
                {

                }
            });

        }



        /// <summary>
        /// Update status of selected request
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ConfigGrid_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            int key = int.Parse(e.Parameters.Split('|')[0]);
            string comments = e.Parameters.Split('|')[2].ToString() == "null" ? "" : e.Parameters.Split('|')[2].ToString();
            string statusText = e.Parameters.Split('|')[3].ToString();
            ASPxGridView grid = (ASPxGridView)sender;

            string assetType = grid.GetRowValuesByKeyValue(key, "AssetType").ToString();

            AssetManagementLibrary.Queries qryhelper = new Queries();
            var ipUpdateAssetStatus = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AssetTranID", ParamValue = int.Parse(e.Parameters.Split('|')[0])},
                new InputParameters {SqlParam = "SysPurposeStageID", ParamValue = int.Parse(e.Parameters.Split('|')[1])},
                new InputParameters {SqlParam = "ModBy", ParamValue = GetPSID},
                new InputParameters {SqlParam = "Comments", ParamValue = comments == "" ? null : GetPSID.ToString() + ":T1E: " + comments}
            };

            //if handover process flow and status of type OK/NOT-OK, then trigger mail to asset team, else if asset type other, then send mail to end user
            if (qryhelper.UpdateForConfig(ipUpdateAssetStatus))
            {
                string purposeId = Helper.GetFieldValueFromGrid(grid, key, "SysPurposeId");
                string psid = Helper.GetFieldValueFromGrid(grid, key, "ToPsid");
                string name = Helper.GetFieldValueFromGrid(grid, key, "ToName");
                string cubicleno = Helper.GetFieldValueFromGrid(grid, key, "ToCubicleNo");
                string floor = Helper.GetFieldValueFromGrid(grid, key, "ToFloor");
                string building = Helper.GetFieldValueFromGrid(grid, key, "ToBuilding");
                string HpsmNo = Helper.GetFieldValueFromGrid(grid, key, "HpsmNo");
                string AssetType = Helper.GetFieldValueFromGrid(grid, key, "AssetType");
                string AssetCategory = Helper.GetFieldValueFromGrid(grid, key, "AssetCategory");
                string SerialNo = Helper.GetFieldValueFromGrid(grid, key, "SerialNo");
                string emailID = Helper.GetFieldValueFromGrid(grid, key, "ToEmailID");
                string DeploymentMailSubject = ConfigurationManager.AppSettings["EndUserDeploymentMailSubject"].ToString() + " - " + HpsmNo;
                string HandoverMailSubject = ConfigurationManager.AppSettings["AssetHandoverMailSubject"].ToString() + " - " + HpsmNo;

                if ((AssetCategory == "Others" && statusText == "Ready_For_Deploy" && purposeId == "5"))
	            {
                    SendDeploymentMail(name, building, floor, cubicleno, HpsmNo, AssetType, SerialNo, emailID, DeploymentMailSubject);
	            }
                else if (statusText == "OK" || statusText == "NOT OK")
	            {
                    SendHandoverMail(HpsmNo, AssetType, SerialNo, statusText == "OK" ? "Clear" : "Not Clear", Session["Username"].ToString(), comments, psid, name, cubicleno, floor, building, ConfigurationManager.AppSettings["AssetHandOverToEmailAddress"].ToString(), HandoverMailSubject);
	            }
                else if ((statusText == "Ready_For_Deploy" && purposeId == "6"))
                {
                    SendDeploymentMail(name, building, floor, cubicleno, HpsmNo, AssetType, SerialNo, emailID, DeploymentMailSubject);
                }
            }
            LoadGrid();
        }



        #endregion



        #region User Defined Functions


        /// <summary>
        /// Load data into gridview
        /// </summary>
        /// <param name="purposeID"></param>
        /// <param name="HpsmNo"></param>
        protected void LoadGrid()
        {
            int? purposeID = null;
            string HpsmNo = null;

            var ipGetAssetsForConfig = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = GetSessionValue<UserProfile>("UserProfile").UserGroups.FirstOrDefault().GroupID},
                new InputParameters {SqlParam = "SysPurposeID", ParamValue = purposeID},
                new InputParameters {SqlParam = "HpsmNo", ParamValue = HpsmNo},
                new InputParameters {SqlParam = "UserPSID", ParamValue = GetPSID}
            };
            var lstAssetTranExtns = Extensions.RemoveDuplicates(QueryHelper.GetAssetsForConfig(ipGetAssetsForConfig));
            ConfigGrid.DataSource = lstAssetTranExtns;
            ConfigGrid.DataBind();
        }


        #endregion

    }
}