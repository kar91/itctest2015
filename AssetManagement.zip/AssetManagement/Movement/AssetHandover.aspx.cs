﻿using AssetManagement.Tasks;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AssetManagementLibrary.Entities.Movement;
    
namespace AssetManagement.Movement
{
    public partial class AssetHandover : AssetTrackerBasePage
    {
        private List<AssetTranExtn> _handoverdatasource = new List<AssetTranExtn>();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Asset Handover";
            }


            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "Tier1Lead" };
            IsInGroup();

            ASPxLabel1.Text = "Selection criteria: " + "\n " + "1. Laptops & desktops should not be selected together" + "\n " + "2. While assigning engineers please make sure building selections are same";

            if (!IsCallback)
            {
                Session["callback_Datasource"] = null;
            }
            BindGrid();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="accessGroupId"></param>
        /// <param name="hpsmNo"></param>
        /// <param name="sysPurposeId"></param>
        /// <param name="fromBuildingId"></param>
        /// <param name="toBuildingId"></param>
        /// <returns></returns>
        protected List<AssetTranExtn> LoadDataforHandOver(int accessGroupId, string hpsmNo , int? sysPurposeId = null, int? fromBuildingId = null, int? toBuildingId = null)
        {
            var ipHandoverIpParams = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = accessGroupId},
                new InputParameters {SqlParam = "SysPurposeID", ParamValue = sysPurposeId},
                new InputParameters {SqlParam = "HpsmNo", ParamValue = hpsmNo == "" ? null : hpsmNo},
                new InputParameters {SqlParam = "FromBuildID", ParamValue =fromBuildingId},
                new InputParameters {SqlParam = "TOBuildID", ParamValue = toBuildingId},

            };
            _handoverdatasource = QueryHelper.GetAssetsforHandoverDataSet(ipHandoverIpParams).ConvertToAssetExtension();
            if (!grdAssetHandover.IsCallback)
            {
                LoadDataFilters(_handoverdatasource);
            }
            else
            {
                Session["callback_Datasource"] = _handoverdatasource;

                grdAssetHandover.DataSource = _handoverdatasource;
                grdAssetHandover.DataBind();
            }
            return _handoverdatasource;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="isupdate"></param>
        private void BindGrid(bool isupdate = false)
        {
            if (isupdate == false)
            {
                if (Session["callback_Datasource"] == null)
                {
                    if (GetGroupID != null) LoadDataforHandOver(GetGroupID.Value,null);
                    grdAssetHandover.DataSource = _handoverdatasource;
                    grdAssetHandover.DataBind();
                }
                else
                {


                    var datasourceCallback = (List<AssetTranExtn>)Session["callback_Datasource"];
                    grdAssetHandover.DataSource = datasourceCallback;
                    grdAssetHandover.DataBind();
                }
            }
            else
            {
                if (GetGroupID != null) LoadDataforHandOver(GetGroupID.Value,null);
                Session["callback_Datasource"] = _handoverdatasource;
                grdAssetHandover.DataSource = _handoverdatasource;
                grdAssetHandover.DataBind();
                LoadDataFilters(_handoverdatasource);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="handoverData"></param>
        protected void LoadDataFilters(List<AssetTranExtn> handoverData)
        {
            BindFilters(cmbHpsm, handoverData.GroupBy(x => x.HpsmNo).Select(y => y.First()), "HpsmNo", "AssetTranId");
            BindFilters(cmbPurpose, handoverData.GroupBy(x => x.SysPurposeId).Select(y => y.First()), "PurposeName", "SysPurposeId");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="comboBox"></param>
        /// <param name="dataToBind"></param>
        /// <param name="textField"></param>
        /// <param name="valueField"></param>
        /// <param name="defaultBuildingid"></param>
        protected void BindFilters(ASPxComboBox comboBox, object dataToBind, string textField, string valueField, string defaultBuildingid = null)
        {
            comboBox.DataSource = dataToBind;
            comboBox.TextField = textField;
            comboBox.ValueField = valueField;
            comboBox.ValueType = typeof(string);
            comboBox.DataBind();
            if (defaultBuildingid == null || defaultBuildingid == "MovementEngineer") return;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdAssetHandover_OnCustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            if (!e.Parameters.Contains('|')) return;
            var callbackParameters = e.Parameters.Split('|');
            switch (callbackParameters[0].ToString().ToLower())
            {
                case "filter":
                    if (GetGroupID != null)
                        LoadDataforHandOver(GetGroupID.Value, callbackParameters[1].ToString(),
                            ToNullableInt(callbackParameters[2]));
                    break;
                case "submit":
                    SubmitHandoverdata(grdAssetHandover.GetSelectedFieldValues("AssetTranId"),
                        ToNullableInt(callbackParameters[1]),
                        ToNullableInt(callbackParameters[2]), ToNullableInt(callbackParameters[3]));
                    
                    break;
            }

            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectedKey"></param>
        /// <param name="fromEngineerId"></param>
        /// <param name="toEngineerId"></param>
        /// <param name="movementEngineerId"></param>
        protected void SubmitHandoverdata(List<object> selectedKey, int? fromEngineerId, int? toEngineerId, int? movementEngineerId)
        {
            foreach (var assetTranId in selectedKey)
            {
                var ipHandoverIpParams = new List<InputParameters>
              {
                new InputParameters {SqlParam = "AssetTranID", ParamValue = assetTranId},
                new InputParameters {SqlParam = "FromBuildingEnggID", ParamValue = fromEngineerId},
                new InputParameters {SqlParam = "ToBuildingEnggID", ParamValue = toEngineerId},
                new InputParameters {SqlParam = "MovementEngineerID", ParamValue = movementEngineerId},
                new InputParameters {SqlParam = "ModBy", ParamValue = GetPSID}
               };

                QueryHelper.UpdateHandOverStatus(ipHandoverIpParams);
                BindGrid(true);
            }


        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public int? ToNullableInt(string s)
        {
            int i;
            if (int.TryParse(s, out i)) return i;
            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ComboBoxCallback(object sender, CallbackEventArgsBase e)
        {
            if (Purpose.Get("purposeId") != null && Purpose.Get("purposeId").ToString() == "4")
            {
                if (e.Parameter == "MovementEngineer")
                {
                    BindFilters(sender as ASPxComboBox,
                    UIHelper.Helper.GetAssetLeadEngineers(), "Name", "PSID",
                    e.Parameter);    
                }
                else
                {
                    BindFilters(sender as ASPxComboBox,
                        (sender as ASPxComboBox).ID.ToString() == "cmbFrmEngineer" ? UIHelper.Helper.GetTier1Engineers().Where(b => b.SysTeamID == 2) : UIHelper.Helper.GetAssetLeadEngineers(), "Name", "PSID",
                    e.Parameter);    
                } 
            }
            else
            {
                BindFilters(sender as ASPxComboBox,
                e.Parameter == "MovementEngineer" ? UIHelper.Helper.GetTier1Engineers().Where(m => m.SysTeamID == 2) : UIHelper.Helper.GetTier1Engineers().Where(w => w.SysTeamID == 2), "Name", "PSID",
                e.Parameter);    
            }
            
        }
    }
}