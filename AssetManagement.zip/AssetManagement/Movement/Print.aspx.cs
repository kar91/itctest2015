﻿using AssetManagement.Tasks;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class Print : AssetTrackerBasePage
    {
        #region Event Handlers

        /// <summary>
        /// Page load event handler, load data into grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Print";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "AssetLead" };
            IsInGroup();

            if (!Page.IsPostBack)
            {
                ToDate.Date = DateTime.Today;
                formType.Set("type", "");
            }

            if (PrintGrid.IsCallback)
            {
                LoadGrid();
            }
        }

        /// <summary>
        /// Search by hpsm no button click event handler, load grid data by hpsm no entered
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SearchByHpsmNo_Click(object sender, EventArgs e)
        {
            ToDate.Value = null;
            LoadGrid();
        }

        /// <summary>
        /// Search by date button click event handler, load grid data by date range selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SearchByDate_Click(object sender, EventArgs e)
        {
            LoadGrid();
        }

        /// <summary>
        /// Load child grid data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PrintDetailGrid_BeforePerformDataSelect(object sender, EventArgs e)
        {
            ASPxGridView printDetailGrid = (ASPxGridView)sender;
            var ipGetAssetsForPrintDetail = new List<InputParameters>
            {
                new InputParameters {SqlParam = "Date", ParamValue = ToDate.Value},
                new InputParameters {SqlParam = "HpsmNo", ParamValue = printDetailGrid.GetMasterRowKeyValue()},
                new InputParameters {SqlParam = "Type", ParamValue = formType.Get("type").ToString() == ""? null : formType.Get("type").ToString()}
            };
            printDetailGrid.DataSource = QueryHelper.GetAssetsForPrintDetail(ipGetAssetsForPrintDetail);
        }

        /// <summary>
        /// Print button click event handler, pass report type and key to PrintLayout page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Print_Click(object sender, ImageClickEventArgs e)
        {
            var qryString = String.Empty;
            if (PrintGrid.GetSelectedFieldValues() == null)
                return;

            PrintGrid.GetSelectedFieldValues("HpsmNo").ForEach(s => qryString = qryString + s + ',');
            PrintGrid.Selection.UnselectAll();
            if (Session["PrintType"] != null)
            {
                Session["PrintType"] = null;
            }
            Session["PrintType"] = new KeyValuePair<string, string>(formType.Get("type").ToString(), qryString);
            Session["PrintDate"] = ToDate.Value;
            Response.Redirect("../Movement/PrintLayout.aspx", true);

        }

        #endregion


        #region User Defined Functions


        /// <summary>
        /// Load data into gridview based on SerialNo or Date range/BuildingID passed
        /// </summary>
        protected void LoadGrid()
        {
            var ipGetAssetsForPrint = new List<InputParameters>
            {
                new InputParameters {SqlParam = "Date", ParamValue = ToDate.Value},
                new InputParameters {SqlParam = "Type", ParamValue = formType.Get("type").ToString() == ""? null : formType.Get("type").ToString()}
            };
            PrintGrid.DataSource = QueryHelper.GetAssetsForPrintMaster(ipGetAssetsForPrint);
            PrintGrid.DataBind();
        }

        #endregion

        protected void ToDate_Init(object sender, EventArgs e)
        {
            ASPxDateEdit de = sender as ASPxDateEdit;
            de.MaxDate = DateTime.Now;
        }


    }
}