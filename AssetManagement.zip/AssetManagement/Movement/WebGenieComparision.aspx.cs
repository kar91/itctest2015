﻿using AssetManagement.Tasks;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class WebGenieComparision : AssetTrackerBasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "WebGenieComparision Report";
            }
            LoadGrid();
        }

        private void LoadGrid()
        {
            var dataset = QueryHelper.GetWebGenieComparisionDetails();
            grdAssetSplit.DataSource = dataset;
            grdAssetSplit.DataBind();
        }

        protected void Export_Click(object sender, ImageClickEventArgs e)
        {
            Load_grdAssetSplit(grdAssetSplit);
            GridViewExporter.FileName = "WebGenieComparisionReport_" + DateTime.Now.ToShortDateString();
            GridViewExporter.WriteXlsToResponse();


        }
        protected void Load_grdAssetSplit(ASPxGridView sender)
        {
            var dataset = QueryHelper.GetWebGenieComparisionDetails();
            sender.DataSource = dataset;
            sender.DataBind();

            
        }
    }
}