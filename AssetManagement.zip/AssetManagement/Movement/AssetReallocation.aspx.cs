﻿using AssetManagement.Tasks;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AssetManagementLibrary.Entities.Movement;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary;
namespace AssetManagement.Movement
{
    public partial class AssetReallocation : AssetTrackerBasePage
    {

        #region Event Handlers

        /// <summary>
        /// Page load event handler, check for page access, load grid data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {

            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Asset Reallocation";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "Tier1Lead" };
            IsInGroup();

            //Purpose dropdown is populated only once on page load
            if (!Page.IsPostBack)
            {
                Session["IsGridRowValid"] = false;
                LoadGrid();
            }

            //When page is in Postback, call LoadGrid function to refresh grid data
            if (AssetReallocGrid.IsCallback)
            {
                if (Request.Params["__CALLBACKPARAM"].Contains("PAGERONCLICK") || Request.Params["__CALLBACKPARAM"].Contains("APPLYCOLUMNFILTER") || Request.Params["__CALLBACKPARAM"].Contains("SORT"))
                {
                    LoadGrid();
                }
            }
        }






        /// <summary>
        /// Custom action button is rendered depending upon next status for any particular request row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void AssetReallocGrid_HtmlRowCreated(object sender, ASPxGridViewTableRowEventArgs e)
        {
            //if current row has data
            if (e.RowType == DevExpress.Web.GridViewRowType.Data)
            {
                string KeyVal = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetTranId").ToString();
                string[] splitObj = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "NextStageInfo").ToString().Split('|');

                //Loop through possible next stage available for request
                foreach (var item in splitObj)
                {
                    ASPxButton CustBtn = new ASPxButton();
                    CustBtn.ID = String.Format("CustBtn{0}{1}", KeyVal, item.Split('-')[0]);
                    CustBtn.Text = item.Split('-')[1];
                    CustBtn.CssClass = "custom";
                    CustBtn.Attributes.Add("AssetTranID", KeyVal);
                    CustBtn.Attributes.Add("NextStatusID", item.Split('-')[0]);
                    CustBtn.AutoPostBack = false;
                    CustBtn.ImageUrl = "../Images/acknowledge.png";
                    CustBtn.Image.Width = 20;
                    CustBtn.Image.Height = 20;
                    CustBtn.ClientSideEvents.Click = "CustomButtonOnClick";
                    e.Row.Cells[14].Controls.Add(CustBtn);
                }
            }

        }



        /// <summary>
        /// When grid editor mode is triggered, load Psid, Cubicle dropdown data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void AssetReallocGrid_CellEditorInitialize(object sender, ASPxGridViewEditorEventArgs e)
        {
            ASPxGridView gridTable = (ASPxGridView)sender;

            //If editor cell under FromPsid column, fill dropdown data for Psid
            if (e.Column.FieldName == "FromPsid")
            {
                var combo = (ASPxComboBox)e.Editor;
                FillPsidComboBox(combo, null, String.Empty);
                
                if (combo.IsCallback)
                { 
                    var hpsmNo = gridTable.GetRowValuesByKeyValue(gridTable.GetRowValues(e.VisibleIndex, "AssetTranId"), "HpsmNo").ToString();
                    var ipGetCubicle = new List<InputParameters>
                    {
                        new InputParameters {SqlParam = "HPSMNo", ParamValue =hpsmNo}
                    };
                    var result = QueryHelper.GetTier1EnggOnHPSM(ipGetCubicle);
                    if (result.Count > 0)
                    {
                        var SelectedPSID = from a in result
                                           select a;

                        if (combo.Items.Count > 0 && combo.Items.FindByValue(SelectedPSID.FirstOrDefault().PSID) != null)
                        {
                            combo.JSProperties["cpisFromPSID"] = combo.Items.FindByValue(SelectedPSID.FirstOrDefault().PSID).Index;
                        }
                    }
                    
                }

            }
            
            if (e.Column.FieldName == "IsMovement")
            {
                var checkbox = (ASPxCheckBox)e.Editor;
                checkbox.Enabled = (gridTable.GetRowValues(e.VisibleIndex, "AssetCategory").ToString() == "Others" && (((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "PurposeName").ToString() == "Asset Handover" || ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "PurposeName").ToString() == "Store to building" || ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "PurposeName").ToString() == "Stage to building"));
            }

            //If editor cell under FromCubicleNo column, fill dropdown data for CubicleNo based upon Area present
            if (e.Column.FieldName == "FromCubicleNo")
            {
                var combo = (ASPxComboBox)e.Editor;
                if (combo.IsCallback)
                {
                    var ipGetCubicle = new List<InputParameters>
                    {
                        new InputParameters {SqlParam = "BuildingFloorID", ParamValue = gridTable.GetRowValues(e.VisibleIndex, "FromFloorId")}
                    };
                    combo.DataSource = QueryHelper.GetCubicleForComboBox(ipGetCubicle);
                    combo.TextField = "FromCubicleNo";
                    combo.ValueField = "FromCubicleId";
                    combo.DataBind();
                    if(combo.Items.Count == 1)
                    {
                        combo.JSProperties["cpisFromCubicle"] = combo.Items[0].Index;
                    }
                }
            }

            //If editor cell under Action column, add custom button for Update action
            if (e.Column.Caption == "Action")
            {
                string KeyVal = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetTranId").ToString();
                string[] splitObj = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "NextStageInfo").ToString().Split('|');

                //Loop through possible next stage available for request
                foreach (var item in splitObj)
                {
                    ASPxButton CustBtn = new ASPxButton();
                    CustBtn.ID = String.Format("CustBtn{0}{1}", KeyVal, item.Split('-')[0]);
                    CustBtn.Text = item.Split('-')[1];
                    CustBtn.CssClass = "custom";
                    CustBtn.Attributes.Add("AssetTranID", KeyVal);
                    CustBtn.Attributes.Add("NextStatusID", item.Split('-')[0]);
                    CustBtn.AutoPostBack = false;
                    CustBtn.ImageUrl = "../Images/acknowledge.png";
                    CustBtn.Image.Width = 20;
                    CustBtn.Image.Height = 20;
                    CustBtn.ClientSideEvents.Click = "CustomEditorButtonOnClick";
                    e.Editor.Controls.Add(CustBtn);
                }
            }
        }


        /// <summary>
        /// When grid data update is triggered
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void AssetReallocGrid_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            var nextStatus = ((ASPxGridView)sender).GetRowValuesByKeyValue(e.Keys[0], new string[] { "NextStageInfo" }).ToString().Split('|');

            var ipUpdateAssetRealloc = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AssetTranID", ParamValue = e.Keys[0]},
                new InputParameters {SqlParam = "FromFloorID", ParamValue = ((ASPxGridView)sender).GetRowValuesByKeyValue(e.Keys[0], new string[] { "FromFloorId" })},
                new InputParameters {SqlParam = "FromCubicleID", ParamValue = e.NewValues[11]},
                new InputParameters {SqlParam = "FromPSID", ParamValue =e.NewValues[12]},
                new InputParameters {SqlParam = "UserPSID", ParamValue = GetPSID},
                new InputParameters {SqlParam = "SysPurposeStageID", ParamValue = int.Parse(hdnNextStatus.Get("nextstatus").ToString())},
                new InputParameters {SqlParam = "IsMovement", ParamValue = e.NewValues["IsMovement"]},
            };

            //if asset details update is successful, set IsGridRowValid to true, exit edit mode
            if (QueryHelper.UpdateAssetReallocation(ipUpdateAssetRealloc))
            {
                Session["IsGridRowValid"] = true;
                e.Cancel = true;
                ((ASPxGridView)sender).CancelEdit();
                LoadGrid();
            }

        }


        #endregion




        #region User defined functions


        /// <summary>
        /// Fill data for PSID combobox 
        /// </summary>
        /// <param name="combo"></param>
        /// <param name="cubicleID"></param>
        /// <param name="UserPsid"></param>
        protected void FillPsidComboBox(ASPxComboBox combo, int? cubicleID, string UserPsid)
        {
            var ipGetUserDetails = new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserPSID", ParamValue = UserPsid},
                new InputParameters {SqlParam = "CubicleID", ParamValue = cubicleID}
            };
            combo.DataSource = UIHelper.Helper.GetTier1Engineers();//QueryHelper.GetUserDetails(ipGetUserDetails);
            combo.DataBind();
        }


        /// <summary>
        /// Load data into gridview
        /// </summary>
        /// <param name="purposeID"></param>
        /// <param name="HpsmNo"></param>
        protected void LoadGrid()
        {
            int? purposeID = null;
            string HpsmNo = null;

            var ipGetAssetsForAssetReallocation = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = GetSessionValue<UserProfile>("UserProfile").UserGroups.FirstOrDefault().GroupID},
                new InputParameters {SqlParam = "SysPurposeID", ParamValue = purposeID},
                new InputParameters {SqlParam = "HpsmNo", ParamValue = HpsmNo},
                new InputParameters {SqlParam = "UserPSID", ParamValue = GetPSID}
            };
            var lstAssetTranExtns = Extensions.RemoveDuplicates(QueryHelper.GetAssetsForAssetReallocation(ipGetAssetsForAssetReallocation));
            AssetReallocGrid.DataSource = lstAssetTranExtns;
            AssetReallocGrid.DataBind();

            Session["AssetRealloc_HpsmNo"] = lstAssetTranExtns.Select(l => l.HpsmNo);
        }



        #endregion

        protected void AssetReallocGrid_Init(object sender, EventArgs e)
        {

        }

        protected void AssetReallocGrid_CustomUnboundColumnData(object sender, ASPxGridViewColumnDataEventArgs e)
        {
            if (e.IsGetData && e.Column.FieldName == "IsMovement")
            {
                object key = e.GetListSourceFieldValue(e.ListSourceRowIndex, AssetReallocGrid.KeyFieldName);
                e.Value = false;
            }
        }

    }
}