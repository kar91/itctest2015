﻿using AssetManagement.Tasks;
using DevExpress.Web.ASPxPivotGrid;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class StatusReport : AssetTrackerBasePage
    {
        #region Event Handlers

        /// <summary>
        /// Page load event handler, check for page access, load data into grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Status Wise Report";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "AssetLead", "Approver", "Tier1Lead" };
            IsInGroup();

            if (!Page.IsPostBack)
            {
                LoadGrid();
            }

            if (StatusGrid.IsCallback)
            {
                LoadGrid();
            }
        }


        /// <summary>
        /// Search by serial no button click event handler, load grid by serial no entered
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SearchBySerialNo_Click(object sender, EventArgs e)
        {
            LoadGrid();
        }

        /// <summary>
        /// Status dropdown changed event handler, load data into grid by status selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void CmbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadGrid();
        }

        /// <summary>
        /// Export button click event handler, export grid data to excel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Export_Click(object sender, ImageClickEventArgs e)
        {
            LoadGrid();
            var FileName = "StatusWiseReport_" + DateTime.Now;
            GridViewExporter.ExportXlsxToResponse(FileName);
        }

        #endregion


        #region User Defined Functions

        /// <summary>
        /// Load data into grid based upon passed serial no filter if present
        /// </summary>
        protected void LoadGrid()
        {
            string serialNo = null;
            int? statusID = null;
            
            if (SerialNoTxt.Value != null)
            {
                serialNo = SerialNoTxt.Value.ToString();
            }

            var ipGetAssetsForStatusReport = new List<InputParameters>
            {
                new InputParameters {SqlParam = "SerialNo", ParamValue = serialNo},
                new InputParameters {SqlParam = "StatusID", ParamValue = statusID}
            };
            StatusGrid.DataSource = QueryHelper.GetAssetsForStatusReport(ipGetAssetsForStatusReport);
            StatusGrid.DataBind();
        }

        #endregion

    }
}