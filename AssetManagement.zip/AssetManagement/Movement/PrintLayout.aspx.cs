﻿using AssetManagementLibrary.Entities.Movement.Report;
using AssetManagement.Movement.Reports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AssetManagementLibrary.OtherHelpers;
using AssetManagement.Tasks;

namespace AssetManagement.Movement
{
    public partial class PrintLayout : AssetTrackerBasePage
    {
        /// <summary>
        /// Page load event handler, check for page access, load report based on type passed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "AssetLead" };
            IsInGroup();

            if (Session["PrintType"] == null)
                return;
            var keyvalue = (KeyValuePair<string, string>)Session["PrintType"];
            var type = keyvalue.Key;
            var value = keyvalue.Value;

            if (type == "Movement")
            {
                IterateReports<MovementReport>(GetForm(type, value));
            }
            else if (type == "Handover")
            {
                IterateReports<HandOverReport>(GetForm(type, value));
            }
            else
            {
                IterateReports<DeploymentReport>(GetForm(type, value));
            }
        }

        /// <summary>
        /// Generic method item report generator
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="forms"></param>
        private void IterateReports<T>(List<Form> forms) where T : DevExpress.XtraReports.UI.XtraReport, new()
        {
            T temp = null;
            if (forms == null) return;

            forms.ForEach(x =>
            {
                T report = new T();
                report.DataSource = new List<Form>() { x };
                report.CreateDocument();

                if (temp != null)
                {
                    temp.Pages.AddRange(report.Pages);
                }
                else
                    temp = report;
            });

            DocumentViewer.Report = temp;
        }

        /// <summary>
        /// Get report data
        /// </summary>
        /// <param name="type"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        private List<Form> GetForm(string type, string value)
        {
            List<Form> forms = new List<Form>();

            if (Session["PrintType"] != null)
            {
                var ipGetAssetsForPrint = new List<InputParameters> { new InputParameters { SqlParam = "HpsmNo", ParamValue = value } };

                if (type == "Movement")
                {
                    ipGetAssetsForPrint.Add(new InputParameters { SqlParam = "Type", ParamValue = "Movement" });
                    
                    if (QueryHelper.UpdateFormNo(ipGetAssetsForPrint))
                    {
                        ipGetAssetsForPrint.RemoveAt(1);
                        ipGetAssetsForPrint.Add(new InputParameters
                        {
                            SqlParam = "Date",
                            ParamValue = Session["PrintDate"] != null ? Convert.ToDateTime(Session["PrintDate"]) : DateTime.Now
                        });
                        forms = CheckAssetCount(Extensions.MergeAssets(QueryHelper.GetAssetsForMovement(ipGetAssetsForPrint)));
                    }
                }
                else if (type == "Handover")
                {
                    ipGetAssetsForPrint.Add(new InputParameters { SqlParam = "Type", ParamValue = "Handover" });
                    if (QueryHelper.UpdateFormNo(ipGetAssetsForPrint))
                    {
                        ipGetAssetsForPrint.RemoveAt(1);
                        ipGetAssetsForPrint.Add(new InputParameters
                        {
                            SqlParam = "Date",
                            ParamValue = Session["PrintDate"] != null ? Convert.ToDateTime(Session["PrintDate"]) : DateTime.Now
                        });
                        forms = CheckAssetCount(Extensions.MergeAssets(QueryHelper.GetAssetsForHandover(ipGetAssetsForPrint)));
                    }
                }
                else
                {
                    ipGetAssetsForPrint.Add(new InputParameters { SqlParam = "Type", ParamValue = "Deployment" });
                    if (QueryHelper.UpdateFormNo(ipGetAssetsForPrint))
                    {
                        ipGetAssetsForPrint.RemoveAt(1);
                        ipGetAssetsForPrint.Add(new InputParameters
                        {
                            SqlParam = "Date",
                            ParamValue = Session["PrintDate"] != null ? Convert.ToDateTime(Session["PrintDate"]) : DateTime.Now
                        });
                        forms = CheckAssetCount(Extensions.MergeAssets(QueryHelper.GetAssetsForDeploy(ipGetAssetsForPrint)));
                    }
                }

            }
            return forms;
        }

        /// <summary>
        /// Add Blank Rows to Asset if Count of data is less than 5
        /// </summary>
        /// <param name="forms"></param>
        /// <returns></returns>
        private List<Form> CheckAssetCount(List<Form> forms)
        {
            foreach (var item in forms)
            {
                for (int i = item.Assets.Count; i < 5; i++)
                {
                    item.Assets.Add(new AssetDetails { AssetType = null, FAR = null, Make = null, Model = null, SerialNumber = null });
                }
            }
            return forms;
        }

    }
}