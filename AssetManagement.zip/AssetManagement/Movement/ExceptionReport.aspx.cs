﻿using AssetManagement.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class ExceptionReport : AssetTrackerBasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Exception Report";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "AssetLead", "Approver", "Tier1Lead" };
            IsInGroup();

            LoadGrid();
        }

        /// <summary>
        /// On export button click, print the data into excel file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Export_Click(object sender, ImageClickEventArgs e)
        {
            LoadGrid();
            GridViewExporter.FileName = "ExceptionReport_" + DateTime.Now.Date;
            GridViewExporter.WriteXlsToResponse();
        }
        

        /// <summary>
        /// Load data into gridview based on SerialNo or Date range/BuildingID passed
        /// </summary>
        protected void LoadGrid()
        {
            TranGrid.DataSource = QueryHelper.GetAssetsForExceptionReport();
            TranGrid.DataBind();
        }

    }
}