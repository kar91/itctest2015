﻿using AssetManagement.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class Movement : AssetTrackerBasePage
    {
        /// <summary>
        /// Page load event handler, check for page access, load grid data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Movement Report";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "AssetLead", "Approver", "Tier1Lead" };
            IsInGroup();


            if (!Page.IsPostBack)
            {
                frmdate.MaxDate = DateTime.Today;
                todate.MaxDate = DateTime.Today;

                LoadGrid(true);
                period.Visible = false;
            }

            if (TranGrid.IsCallback)
            {
                LoadGrid(false);
            }
        }

        /// <summary>
        /// Export button click event handler, export grid data to excel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Export_Click(object sender, ImageClickEventArgs e)
        {
            LoadGrid();
            GridViewExporter.FileName = "MovementReport_" + DateTime.Now.Date;
            GridViewExporter.WriteXlsToResponse();
        }

        /// <summary>
        /// Gridview custom callback event handler, load full data to grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void TranGrid_CustomCallback(object sender, DevExpress.Web.ASPxGridViewCustomCallbackEventArgs e)
        {
            LoadGrid(true);
        }

        /// <summary>
        /// Load data into gridview based on SerialNo or Date range/BuildingID passed
        /// </summary>
        protected void LoadGrid(bool showAll = false)
        {
            var ipTranGrid = new List<InputParameters>();
            
            if (Request.QueryString["Date"] != null)
            {
                ipTranGrid.Add(new InputParameters { SqlParam = "FromDt", ParamValue = Request.QueryString["Date"] });
                ipTranGrid.Add(new InputParameters { SqlParam = "ToDt", ParamValue = showAll ? null : todate.Value });
                ipTranGrid.Add(new InputParameters { SqlParam = "BuildingID", ParamValue = Request.QueryString["BuildingID"] });
            }
            else
            {
                ipTranGrid.Add(new InputParameters { SqlParam = "FromDt", ParamValue = showAll ? null : frmdate.Value });
                ipTranGrid.Add(new InputParameters { SqlParam = "ToDt", ParamValue = showAll ? null : todate.Value });
            }
            
            
            TranGrid.DataSource = QueryHelper.GetAssetsForMovementReport(ipTranGrid);
            TranGrid.DataBind();
        }

        /// <summary>
        /// filter dropdown changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbfilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbfilter.Value.ToString() == "1")
            {
                period.Visible = true;
            }
            else
            {
                period.Visible = false;
                LoadGrid(true);
            }
        }

        /// <summary>
        /// Submit button click event handler, load grid data by date filters selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void submit_Click(object sender, EventArgs e)
        {
            LoadGrid(false);
        }

        protected void TranGrid_CustomColumnDisplayText(object sender, DevExpress.Web.ASPxGridViewColumnDisplayTextEventArgs e)
        {
            if (e.Column.FieldName == "MovOutDate" && e.Value.ToString() == "1/1/1900 12:00:00 AM")
            {
                e.DisplayText = "";
            }
        }

    }
}