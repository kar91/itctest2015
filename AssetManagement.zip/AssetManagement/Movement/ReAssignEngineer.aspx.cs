﻿using AssetManagement.Tasks;
using AssetManagementLibrary.Entities.Movement;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using DevExpress.Web.Data;

namespace AssetManagement.Movement
{
    public partial class ReAssignEngineer : AssetTrackerBasePage
    {
        private List<AssetTranExtn> _assetintransit = new List<AssetTranExtn>();
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Init(object sender, EventArgs e)
        {
            Filter();
        }

        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            AccessGroups = new List<string> { "Tier1Lead", "AssetLead", "Approver" };
            IsInGroup();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="accessGroupId"></param>
        /// <param name="hpsmNo"></param>
        /// <param name="frmeng"></param>
        /// <param name="toeng"></param>
        protected void Loaddata(int accessGroupId, string hpsmNo = null, string frmeng = null, string toeng = null)
        {
            var ipParams = new List<InputParameters>
            {
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = accessGroupId},
                new InputParameters {SqlParam = "HpsmNo", ParamValue = hpsmNo}
            };
            _assetintransit = QueryHelper.GetAssetsInTransactionDataSet(ipParams).ConvertToAssetExtension();
            BindGridData(_assetintransit);
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="datSource"></param>
        protected void BindGridData(List<AssetTranExtn> datSource)
        {
            grdReassign.DataSource = datSource;
            grdReassign.DataBind();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="comboBox"></param>
        /// <param name="dataToBind"></param>
        /// <param name="textField"></param>
        /// <param name="valueField"></param>
        protected void BindFilters(ASPxComboBox comboBox, object dataToBind, string textField, string valueField)
        {
            comboBox.DataSource = dataToBind;
            comboBox.TextField = textField;
            comboBox.ValueField = valueField;
            comboBox.ValueType = typeof(string);
            comboBox.DataBind();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnsearchbyhpsm_OnClick(object sender, EventArgs e)
        {
            Filter();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void combobox_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            Filter();
        }

        /// <summary>
        /// 
        /// </summary>
        protected void Filter()
        {
            string frmpsid = null;
            string topsid = null;
            //var hpsmno = null;
            //if (hpsmno == "") hpsmno = null;

            if (GetGroupID != null) Loaddata(GetGroupID.Value, null, frmpsid, topsid);
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdReassign_OnCellEditorInitialize(object sender, ASPxGridViewEditorEventArgs e)
        {
            var engs = new string[] { "FromEngineer", "ToEngineer" };
            if (engs.Contains(e.Column.FieldName))
            {
                var cmbeng = e.Editor as ASPxComboBox;

                var currentStatus = (grdReassign.GetRowValues(e.VisibleIndex, "CurrentStatus")).ToString();
                var purposeName = (grdReassign.GetRowValues(e.VisibleIndex, "PurposeName")).ToString();

                BindFilters(cmbeng, UIHelper.Helper.GetEngineersDistinct(), "Name", "PSID");

                if (currentStatus == "Mov-In" || currentStatus == "BE Received" || currentStatus == "BE_Deployed")
                {
                    if (e.Column.FieldName == "FromEngineer")
                        cmbeng.Enabled = false;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdReassign_OnRowUpdating(object sender, ASPxDataUpdatingEventArgs e)
        {
            string fromengineer = e.NewValues["FromEngineer"].ToString();
            if (Chkifnew(fromengineer) == false)
                fromengineer = null;
            string newengineer = e.NewValues["ToEngineer"].ToString();
            if (Chkifnew(newengineer) == false)
                newengineer = null;
            var key = grdReassign.GetRowValuesByKeyValue(e.Keys[0], "AssetTranId").ToString();
            var ipParams = new List<InputParameters>
            {
                new InputParameters {SqlParam = "FromEngineer", ParamValue = fromengineer},
                new InputParameters {SqlParam = "ToEngineer", ParamValue = newengineer},
                new InputParameters {SqlParam = "AssetTranID", ParamValue = key}
            };
            Session["frmpsid"] = null;
            Session["topsid"] = null;
            var result = QueryHelper.UpdateEngineers(ipParams);
            e.Cancel = true;
            grdReassign.CancelEdit();
            Filter();
            upd.UpdateMode = UpdatePanelUpdateMode.Conditional;
            upd.Update();

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        private static bool Chkifnew(string input)
        {
            int check;
            return int.TryParse(input, out check);
        }


    }
}