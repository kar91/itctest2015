﻿using AssetManagement.Tasks;
using AssetManagementLibrary;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AssetManagement.Movement
{
    public partial class AddEngineer : AssetTrackerBasePage
    {
        /// <summary>
        /// Page load event, check access group for page access, fill Team Type dropdown data, 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //check access group for page access
            AccessGroups = new List<string> { "Admin" };
            IsInGroup();

            if (!Page.IsPostBack)
            {
                FillTeamComboBox(CmbTeam);

                CmbBuilding.DataSource = UIHelper.Helper.GetBuildings();
                CmbBuilding.DataBind();

                LoadGrid();
            }

            //Fill engineer psid combobox, called everytime a search is made 
            if (CmbEngineer.IsCallback)
                if (Request.Params["__CALLBACKID"].Contains("ctl00$ContentPlaceHolder1$CmbEngineer"))
                    FillEngineerComboBox(CmbEngineer);

            if (AddEnggGrid.IsCallback)
            {
                if (Request.Params["__CALLBACKPARAM"].Contains("PAGERONCLICK") || Request.Params["__CALLBACKPARAM"].Contains("APPLYCOLUMNFILTER") || Request.Params["__CALLBACKPARAM"].Contains("SORT"))
                {
                    LoadGrid();
                }
            }

        }


        /// <summary>
        /// Floor dropdown callback when adding engineer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void CmbArea_Callback(object sender, CallbackEventArgsBase e)
        {
            if (CmbBuilding.Value != null)
            {
                CmbArea.DataSource = UIHelper.Helper.GetFloors(int.Parse(e.Parameter.ToString()));
                CmbArea.DataBind();
            }
        }


        /// <summary>
        /// Engineer Type dropdown callback when adding engineer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void CmbEnggType_Callback(object sender, CallbackEventArgsBase e)
        {
            if (CmbTeam.Value != null)
                FillEngineerTypeComboBox(CmbEngineerType, int.Parse(CmbTeam.Value.ToString()));
        }



        /// <summary>
        /// When grid changed to editor mode, Engineer psid, type and team dropdowns to be filled with data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void AddEnggGrid_CellEditorInitialize(object sender, DevExpress.Web.ASPxGridViewEditorEventArgs e)
        {
            ASPxGridView gridTable = (ASPxGridView)sender;

            //If editor cell under BuildingName column, fill dropdown data for Building editor dropdown
            if (e.Column.FieldName == "BuildingName")
            {
                var combo = (ASPxComboBox)e.Editor;
                var enggType = AddEnggGrid.GetRowValues(e.VisibleIndex, "Type");
                FillComboBox(combo, UIHelper.Helper.GetBuildings());
            }

            //If editor cell under FloorNo column, fill dropdown data for FloorNo editor dropdown
            if (e.Column.FieldName == "FloorNo")
            {
                var cmbArea = e.Editor as ASPxComboBox;
                var enggType = AddEnggGrid.GetRowValues(e.VisibleIndex, "Type");
                if (AddEnggGrid.GetRowValues(e.VisibleIndex, "BuildingName").ToString() != "")
                {
                    int BuildingId = (int)UIHelper.Helper.GetBuildings().Where(s => s.BuildingName == AddEnggGrid.GetRowValues(e.VisibleIndex, "BuildingName").ToString()).Select(b => b.BuildingId).FirstOrDefault();
                    FillComboBox(cmbArea, UIHelper.Helper.GetFloors(BuildingId));
                }
                cmbArea.Callback += new CallbackEventHandlerBase(cmbAreaEditor_OnCallback);
            }

            //If editor cell under Engineer column, fill dropdown data for Engineer Psid
            if (e.Column.FieldName == "TeamName")
            {
                var combo = (ASPxComboBox)e.Editor;
                FillTeamComboBox(combo);
            }

            //If editor cell under Engineer column, fill dropdown data for Engineer Psid
            if (e.Column.FieldName == "Type")
            {
                var combo = (ASPxComboBox)e.Editor;
                combo.Callback += new CallbackEventHandlerBase(cmbTypeEditor_OnCallback);
            }

            //If editor cell under Engineer column, fill dropdown data for Engineer Psid
            if (e.Column.FieldName == "PSID")
            {
                var combo = (ASPxComboBox)e.Editor;
                if (combo.IsCallback)
                    FillEngineerComboBox(combo);
            }
        }


        /// <summary>
        /// Floor editor dropdown callback while changing engineer location details inside gridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbAreaEditor_OnCallback(object sender, CallbackEventArgsBase e)
        {
            if (e.Parameter != "")
            {
                FillComboBox(sender as ASPxComboBox, UIHelper.Helper.GetFloors(int.Parse(e.Parameter)));
            }
        }


        /// <summary>
        /// Engineer Type editor dropdown callback while changing engineer details inside gridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbTypeEditor_OnCallback(object sender, CallbackEventArgsBase e)
        {
            if (e.Parameter != "")
                FillEngineerTypeComboBox(sender as ASPxComboBox, int.Parse(e.Parameter));
        }



        /// <summary>
        /// Deleting row from gridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void AddEnggGrid_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            var ipDeleteSysEngineers = new List<InputParameters>
            {
                new InputParameters {SqlParam = "SysEngineerID", ParamValue = e.Keys[0]}
            };

            if (QueryHelper.DeleteSysEngineer(ipDeleteSysEngineers))
            {
                e.Cancel = true;
                CacheHelper.GetInstance.Remove("Engineers");
                CacheHelper.GetInstance.GetValue("Engineers", new Queries().GetEnginnersDetail, 100, true, null);
                FillEngineerComboBox(CmbEngineer);
                LoadGrid();
            }
        }

        /// <summary>
        /// Updating row from gridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void AddEnggGrid_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            List<InputParameters> ipUpdateSysEngineer = new List<InputParameters>();
            var flagBE = false;

            //Set the flagBE if engineer type being changed from non-BE to BE, or existing BE updating location details
            if ((e.NewValues[2] ?? "").ToString() == "1" || ((e.OldValues[4] ?? "").ToString() == "BE" && (e.NewValues[4] ?? "").ToString() == "1") || (e.NewValues[4] ?? "").ToString() == "1")
                flagBE = true;

            //If engineer type being changed from BE or to BE, then number of new values for editors will be 9 including Building and floor details
            if (e.NewValues.Count > 7)
            {
                ipUpdateSysEngineer.Add(new InputParameters { SqlParam = "SysEngineerID", ParamValue = e.Keys[0] });
                ipUpdateSysEngineer.Add(new InputParameters { SqlParam = "PSID", ParamValue = e.NewValues[5] });
                ipUpdateSysEngineer.Add(new InputParameters { SqlParam = "SysEngineerTypeID", ParamValue = e.NewValues[4] });
                ipUpdateSysEngineer.Add(new InputParameters { SqlParam = "UserPSID", ParamValue = GetPSID });
                ipUpdateSysEngineer.Add(new InputParameters { SqlParam = "TeamID", ParamValue = e.NewValues[3] });
                ipUpdateSysEngineer.Add(new InputParameters { SqlParam = "BuildingFloorID", ParamValue = flagBE ? e.NewValues[2] : null });
            }
            //If engineer type being changed from not BE to not BE, then number of new values for editors will be 7, i.e., Building and floor details will not show up in new values
            else
            {
                ipUpdateSysEngineer.Add(new InputParameters { SqlParam = "BuildingFloorID", ParamValue = null });
                ipUpdateSysEngineer.Add(new InputParameters { SqlParam = "SysEngineerID", ParamValue = e.Keys[0] });
                ipUpdateSysEngineer.Add(new InputParameters { SqlParam = "PSID", ParamValue = e.NewValues[3] });
                ipUpdateSysEngineer.Add(new InputParameters { SqlParam = "SysEngineerTypeID", ParamValue = e.NewValues[2] });
                ipUpdateSysEngineer.Add(new InputParameters { SqlParam = "UserPSID", ParamValue = GetPSID });
                ipUpdateSysEngineer.Add(new InputParameters { SqlParam = "TeamID", ParamValue = e.NewValues[1] });
            }

            //if engineer details update is successful, exit edit mode
            if (QueryHelper.UpdateSysEngineer(ipUpdateSysEngineer))
            {
                e.Cancel = true;
                ((ASPxGridView)sender).CancelEdit();
                CacheHelper.GetInstance.Remove("Engineers");
                CacheHelper.GetInstance.GetValue("Engineers", new Queries().GetEnginnersDetail, 100, true, null);
                FillEngineerComboBox(CmbEngineer);
                LoadGrid();
            }

        }

        /// <summary>
        /// Load data into gridview
        /// </summary>
        /// <param name="purposeID"></param>
        /// <param name="HpsmNo"></param>
        protected void LoadGrid()
        {
            var ipGetAssetsForAddEngineer = new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserPSID", ParamValue = GetPSID}
            };
            AddEnggGrid.DataSource = GetGridData(ipGetAssetsForAddEngineer);
            AddEnggGrid.DataBind();
        }



        /// <summary>
        /// Add engineer button click event, validate in case of duplicate data, i.e., psid with same type already present in gridview or not
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void AddEngineerBtn_Click(object sender, EventArgs e)
        {
            int engineerPsid = int.Parse(ConvertPSID(CmbEngineer.Value.ToString()));

            //else update the new entry into gridview
            var ipAddSysEngineers = new List<InputParameters>
            {
                new InputParameters {SqlParam = "PSID", ParamValue = ConvertPSID(CmbEngineer.Value.ToString())},
                new InputParameters {SqlParam = "SysEngineerTypeID", ParamValue = CmbEngineerType.Value},
                new InputParameters {SqlParam = "DefaultFloorID", ParamValue = CmbArea.Value},
                new InputParameters {SqlParam = "UserPSID", ParamValue = GetPSID},
                new InputParameters {SqlParam = "TeamID", ParamValue = CmbTeam.Value}
            };

            if (QueryHelper.AddSysEngineer(ipAddSysEngineers))
            {
                CmbEngineer.Value = null;
                CacheHelper.GetInstance.Remove("Engineers");
                CacheHelper.GetInstance.GetValue("Engineers", new Queries().GetEnginnersDetail, 100, true, null);
                Response.Redirect("../Movement/AddEngineer.aspx", true);
            }
        }

        /// <summary>
        /// Convert List of Engineer data to table passed for gridview, list of Locations and BuildingInfo converted to bind to gridview
        /// </summary>
        /// <param name="ipGetAssetsForAddEngineer"></param>
        /// <returns></returns>
        private DataTable GetGridData(List<InputParameters> ipGetAssetsForAddEngineer)
        {
            DataTable table = new DataTable();
            table.Columns.Add("SysEngineerID", typeof(int));
            table.Columns.Add("LocationName", typeof(string));
            table.Columns.Add("BuildingName", typeof(string));
            table.Columns.Add("FloorNo", typeof(string));

            table.Columns.Add("TeamName", typeof(string));
            table.Columns.Add("Type", typeof(string));
            table.Columns.Add("PSID", typeof(string));

            table.Columns.Add("NAME_DISPLAY", typeof(string));
            table.Columns.Add("ModBy", typeof(string));
            table.Columns.Add("ModDt", typeof(DateTime));

            foreach (var item in QueryHelper.GetAssetsForAddEngineer(ipGetAssetsForAddEngineer))
            {
                foreach (var loc in item.Locations)
                {
                    foreach (var binfo in loc.BuildingInfo)
                    {
                        table.Rows.Add(item.SysEngineerID, loc.LocationName, binfo.BuildingName, binfo.FloorNo, item.TeamName, item.Type, item.PSID, item.Name, item.ModBy, item.ModDt);
                    }
                }
            }
            return table;
        }

        /// <summary>
        /// Fill passed Aspxcombobox with dataset supplied
        /// </summary>
        /// <param name="combo">AspxComboBox to bind to</param>
        /// <param name="DataSet">DataSet for binding</param>
        private void FillComboBox(ASPxComboBox combo, object DataSet)
        {
            combo.DataSource = DataSet;
            combo.DataBind();
        }

        /// <summary>
        /// Fill data for team combobox
        /// </summary>
        /// <param name="Combo">pass combobox to bind data</param>
        private void FillTeamComboBox(ASPxComboBox Combo)
        {
            Combo.DataSource = UIHelper.Helper.GetTeamInfo();//QueryHelper.GetTeamInfo();
            Combo.DataBind();
        }

        /// <summary>
        /// Fill data for Engineer type combobox
        /// </summary>
        /// <param name="Combo">pass combobox to bind data</param>
        private void FillEngineerTypeComboBox(ASPxComboBox Combo, int? CmbTeamID)
        {
            Combo.DataSource = UIHelper.Helper.GetEngineerType(CmbTeamID);//QueryHelper.GetEngineerType(CmbTeamID);
            Combo.DataBind();
        }

        /// <summary>
        /// Fill data for engineer psid combobox, called everytime when search is made
        /// </summary>
        /// <param name="Combo">pass combobox to bind data</param>
        private void FillEngineerComboBox(ASPxComboBox Combo)
        {
            var ipGetUserDetails = new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserPSID", ParamValue = string.Empty},
                new InputParameters {SqlParam = "CubicleID", ParamValue = null}
            };
            var ds = QueryHelper.GetUserDetailsForAddEngineer(ipGetUserDetails);
            Combo.DataSource = ds;
            Combo.DataBind();
        }


        /// <summary>
        /// Convert psid to generic 0 padded form when length less than required
        /// </summary>
        /// <param name="psid"></param>
        /// <returns>0 padded psid</returns>
        private string ConvertPSID(string psid)
        {
            if (psid.Length <= 2)
                psid = "00" + psid;
            if (psid.Length <= 3)
                psid = "0" + psid;

            return psid;
        }

        /// <summary>
        /// Grid custom filter 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void AddEnggGrid_AutoFilterCellEditorCreate(object sender, ASPxGridViewEditorCreateEventArgs e)
        {
            e.EditorProperties = new TextBoxProperties();
        }

    }
}