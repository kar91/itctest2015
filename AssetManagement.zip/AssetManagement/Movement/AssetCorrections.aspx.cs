﻿using AssetManagement.Tasks;
using AssetManagement.UIHelper;
using AssetManagementLibrary;
using AssetManagementLibrary.Entities;
using AssetManagementLibrary.Entities.Movement;
using AssetManagementLibrary.OtherHelpers;
using DevExpress.Web;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web.UI;
using System.Web.UI.WebControls;

//using AssetManagement.UIHelper.Helper;

namespace AssetManagement.Movement
{
    public partial class AssetCorrections : AssetTrackerBasePage
    {
        #region global variables

        public bool IsEnable = true;
        protected List<AssetTranExtn> assetlst = new List<AssetTranExtn>();
        protected List<MasterData> lst = new List<MasterData>();
        #endregion global variables

        #region Event Handlers

        /// <summary>
        /// event handler to render custom Adjust button for last column in grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void AdjustmentGrid_HtmlRowCreated(object sender, DevExpress.Web.ASPxGridViewTableRowEventArgs e)
        {
            //if current row has data
            if (e.RowType == DevExpress.Web.GridViewRowType.Data)
            {
                string KeyVal = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "AssetId").ToString();
                string KeyVal2 = ((ASPxGridView)sender).GetRowValues(e.VisibleIndex, "IsInTransit").ToString();

                ASPxButton CustBtn = new ASPxButton();
                CustBtn.Theme = "MetropolisBlue";
                CustBtn.ID = String.Format("CustBtn{0}", KeyVal);
                CustBtn.Text = "Adjust";
                CustBtn.Attributes.Add("AssetID", KeyVal);
                CustBtn.Attributes.Add("IsInTransit", KeyVal2);
                CustBtn.HorizontalAlign = HorizontalAlign.Center;
                CustBtn.AutoPostBack = false;
                CustBtn.ClientSideEvents.Click = "AdjustButtonOnClick";
                e.Row.Cells[10].Controls.Add(CustBtn);
            }
        }

        /// <summary>
        /// cascading dropdown, load data for area dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbArea_Callback(object sender, CallbackEventArgsBase e)
        {
            if (cmbBuilding.Value != null)
            {
                cmbArea.DataSource = UIHelper.Helper.GetFloors(int.Parse(e.Parameter.ToString()));
                cmbArea.DataBind();
            }

        }

        /// <summary>
        /// cascading dropdown, load data for cubicle dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbCubicle_Callback(object sender, CallbackEventArgsBase e)
        {
            if (cmbArea.Value != null)
            {
                var ipcubiclebasedonarea = new List<InputParameters>
                {
                    new InputParameters {SqlParam = "BuildingFloorID", ParamValue = e.Parameter}
                };
                cmbCubicle.DataSource = QueryHelper.GetCubicleBasedOnArea(ipcubiclebasedonarea);
                cmbCubicle.DataBind();
            }

        }

        /// <summary>
        /// fill data for psid dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbEndUserPsid_Callback(object sender, CallbackEventArgsBase e)
        {
            var ipGetUserDetails = new List<InputParameters>
            {
                new InputParameters {SqlParam = "UserPSID", ParamValue = string.Empty},
                new InputParameters {SqlParam = "CubicleID", ParamValue = null}
            };
            //var ds = QueryHelper.GetUserDetails(ipGetUserDetails);
            var ds = QueryHelper.GetUserDetailsForItemSummary(ipGetUserDetails);
            cmbenduserdetails.DataSource = ds;
            cmbenduserdetails.DataBind();

        }



        ///cmbStatus
        protected void cmbStatus_Callback(object sender, CallbackEventArgsBase e)
        {
            if (Convert.ToBoolean(Session["IsInTransit"]))
            {
                var source = CacheHelper.GetInstance.GetValue("AssetStatus", new Queries().GetAllAssetStatus, 100, true, null);

                var sorted = from rec in source
                             where rec.Value.ToUpper() == "LOST"
                             select rec;
                cmbStatus.DataSource = sorted;
                cmbStatus.ValueField = "Key";
                cmbStatus.TextField = "Value";
                cmbStatus.DataBind();

            }
            else
            {
                cmbStatus.DataSource = CacheHelper.GetInstance.GetValue("AssetStatus", new Queries().GetAllAssetStatus, 100, true, null);
                cmbStatus.ValueField = "Key";
                cmbStatus.TextField = "Value";
                cmbStatus.DataBind();
            }
        }

        protected void Load_grd(ASPxGridView sender)
        {
            var ipGetAssetsForAssetCorrection = Setparam();
            assetlst = QueryHelper.GetAssetsForAssetCorrection(ipGetAssetsForAssetCorrection);
            Session["AssetsForAssetCorrection"] = assetlst;
            sender.DataSource = assetlst;
            sender.DataBind();
        }

        /// <summary>
        /// Bind data to building and status dropdown inside popup
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label Text in Master page is set to Page Name
            if (Master != null)
            {
                System.Web.UI.WebControls.Label lblMasterStatus = (System.Web.UI.WebControls.Label)Master.FindControl("lblStatus");
                lblMasterStatus.Text = "Asset Corrections";
            }

            //AccessGroup for current page is added, Access Validation is performed
            AccessGroups = new List<string> { "AssetLead", "Approver" };
            IsInGroup();

            //When page first load, bind asset details data to grid, load building & status dropdown
            if (!Page.IsPostBack)
            {
                cmbBuilding.DataSource = UIHelper.Helper.GetBuildings();
                cmbBuilding.DataBind();

                cmbStatus.DataSource = CacheHelper.GetInstance.GetValue("AssetStatus", new Queries().GetAllAssetStatus, 100, true, null);
                cmbStatus.ValueField = "Key";
                cmbStatus.TextField = "Value";
                cmbStatus.DataBind();


                //LoadReason(false);
                //grid
                // Load_grd(AdjustmentGrid);
            }
            if (AdjustmentGrid.IsCallback)
                Load_grd(AdjustmentGrid);

        }

        /// <summary>
        /// Binds dataset to PopupGrid for asset selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PopupGrid_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            if (e.Parameters == "submit")
                SubmitBtn();
            else if (e.Parameters == "clear")
            {

                AdjustmentGrid.DataSource = null;
                AdjustmentGrid.DataBind();

                SerialNoTxtClient.Text = null;
                FARTxtClient.Text = null;
                PSIDTxtClient.Text = null;
            }
            else
            {
                LoadGrid(false);
                //cmbenduserdetails.SelectedIndex = -1;
                //cmbBuilding.SelectedIndex = -1;
                //cmbArea.SelectedIndex = -1;
                //cmbCubicle.SelectedIndex = -1;
                var data = assetlst.FirstOrDefault(s => s.AssetId == int.Parse(e.Parameters));
                Session["IsInTransit"] = data.IsInTransit;

                PopupGrid.DataSource = assetlst.Where(s => s.AssetId == int.Parse(e.Parameters));
                PopupGrid.DataBind();

                //LoadReason(false);
            }
        }
        protected void AdjustmentGrid_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
        {
            if (e.Parameters == "clear")
            {

                AdjustmentGrid.DataSource = null;
                AdjustmentGrid.DataBind();
            }
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        // protected void submit_Click(object sender, EventArgs e)
        void SubmitBtn()
        {

            var assetid = int.Parse(PopupGrid.GetRowValues(0, "AssetId").ToString());
            var cubicleid = cmbCubicle.Value;
            var psid = cmbenduserdetails.Value;
            var statusid = cmbStatus.Value;

            var grid = PopupGrid;

            var ipAssetCorrectionUpdate = new List<InputParameters>
            {
                new InputParameters {SqlParam = "SysAssetId", ParamValue = assetid},
                new InputParameters {SqlParam = "ToCubicle", ParamValue = cubicleid},
                new InputParameters {SqlParam = "ToPSID", ParamValue = psid},
                new InputParameters {SqlParam = "AssetStatusID", ParamValue = statusid},
                new InputParameters {SqlParam = "ModBy", ParamValue = GetPSID},
                new InputParameters {SqlParam = "Comments", ParamValue = cmbReason.Value.ToString()!="5"?cmbReason.Text:txtReasonStr.Text},
            };



            //update asset details if new value has been passed
            if (cubicleid != null || psid != null || statusid != null)
            {

                var result = QueryHelper.InsertNewRequestAssetCorrection(ipAssetCorrectionUpdate);

                string AssetStatus = Helper.GetFieldValueFromGrid(grid, assetid, "AssetStatus");
                string AssetType = Helper.GetFieldValueFromGrid(grid, assetid, "AssetType");
                string SerialNo = Helper.GetFieldValueFromGrid(grid, assetid, "SerialNo");

                //old values

                string FromBuilding = Helper.GetFieldValueFromGrid(grid, assetid, "FromBuilding").ToString();
                string FromArea = Helper.GetFieldValueFromGrid(grid, assetid, "FromArea").ToString();
                string FromCubicleNo = Helper.GetFieldValueFromGrid(grid, assetid, "FromCubicleNo").ToString();
                string FromPsid = Helper.GetFieldValueFromGrid(grid, assetid, "FromPsid").ToString();
                string FromStatus = Helper.GetFieldValueFromGrid(grid, assetid, "AssetStatus").ToString();

                //new values

                string ToBuilding = cmbBuilding.Value == null ? "No changes" : cmbBuilding.Text;
                string ToArea = cmbArea.Value == null ? "No changes" : cmbArea.Text;
                string ToCubicleNo = cmbCubicle.Value == null ? "No changes" : cmbCubicle.Text;
                string ToPsid = cmbenduserdetails.Value == null ? "No changes" : cmbenduserdetails.Value + ", " + cmbenduserdetails.Text.Split(';')[1];

                string ToStatus = cmbStatus.Value == null ? "No changes" : cmbStatus.Text;

                string RequestedBy = GetPSID + ", " + GetName;
                string EmailID = ConfigurationManager.AppSettings["AssetCorrectionEmailAddress"].ToString();
                string MailSubject = ConfigurationManager.AppSettings["AssetCorrectionMailSubject"].ToString();

                SendMail(AssetStatus, AssetType, SerialNo, FromBuilding, FromArea, FromCubicleNo, FromPsid, FromStatus, ToBuilding, ToArea, ToCubicleNo, ToPsid, ToStatus, RequestedBy, EmailID, MailSubject, cmbReason.Value.ToString() != "5" ? cmbReason.Text : txtReasonStr.Text);

                //reload grid data
                //LoadGrid(true);
            }



            //set null

            AdjustmentGrid.DataSource = null;
            AdjustmentGrid.DataBind();

            SerialNoTxtClient.Text = null;
            FARTxtClient.Text = null;
            PSIDTxtClient.Text = null;

            //close popup
            AssetDetailsPopup.ShowOnPageLoad = false;
            
        }

        #endregion Event Handlers

        #region User defined methods

        protected void ASPxGridView1_CustomColumnDisplayText(object sender, ASPxGridViewColumnDisplayTextEventArgs e)
        {
            e.EncodeHtml = true;
            string searchText = SerialNoTxtClient.Text;
            string highlightedText = Convert.ToString(e.Value);

            if (!highlightedText.Contains(searchText) || searchText == null || searchText == string.Empty)
                return;
            //e.DisplayText = highlightedText.Replace(searchText, "<span class='highlight'>" + searchText + "</span>");
            //e.DisplayText = highlightedText.Replace(searchText, "<b>" + searchText + "<b>");
        }

        /// <summary>
        /// Fetch all assets from master table for Grid
        /// </summary>
        protected void LoadGrid(Boolean isUpdate)
        {
            if (!isUpdate)
                assetlst = GetSessionValue<List<AssetTranExtn>>("AssetsForAssetCorrection");
            else
                assetlst = null;

            if (assetlst != null)
            {
                AdjustmentGrid.DataSource = assetlst;
                AdjustmentGrid.DataBind();
            }
            else
            {
                var ipGetAssetsForAssetCorrection = Setparam();

                assetlst = QueryHelper.GetAssetsForAssetCorrection(ipGetAssetsForAssetCorrection);
                Session["AssetsForAssetCorrection"] = assetlst;
                AdjustmentGrid.DataSource = assetlst;
                AdjustmentGrid.DataBind();
            }

            if (assetlst.Count == 1)
                Session["IsInTransit"] = assetlst.FirstOrDefault().IsInTransit;
            else
                Session["IsInTransit"] = false;
        }

        void LoadReason(Boolean IsLost)
        {
            lst = GetSessionValue<List<MasterData>>("masterassetcorrection");
            if (lst == null || lst.Count == 0)
            {
                lst = QueryHelper.GetSysMasterData(new List<InputParameters> { new InputParameters { SqlParam = "MasterName", ParamValue = "AssetCorrectionReason" } });
                Session["masterassetcorrection"] = lst;
            }

            if (IsLost)
            {
                var sorted = from rec in lst
                             where rec.KeyName.Contains("Lost") || rec.KeyName.Contains("Others")
                             select rec;
                lst = sorted.ToList<MasterData>();
                
            }
            
            cmbReason.DataSource = lst;
            cmbReason.DataBind();
        }

        protected void cmbReason_Callback(object sender, CallbackEventArgsBase e)
        {
            LoadReason(Convert.ToString(e.Parameter).ToLower()=="true"?true:false);



        }

        /// <summary>
        /// Search grid details by Serial Number passed and reset date field and building values
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SearchBySerialNo_Click(object sender, EventArgs e)
        {
            //Clear previous values of Date fields and Building if existing
            Session["AssetsForAssetCorrection"] = null;
            LoadGrid(true);
        }

        private void SendMail(string AssetStatus, string AssetType, string SerialNo, string PrevBuilding, string PrevArea, string PrevCubicleNo, string PrevPsid, string PrevStatus, string ReqBuilding, string ReqArea, string ReqCubicleNo, string ReqPsid, string ReqStatus, string RequestedBy, string EmailID, string MailSubject, string comments)
        {
            Task.Factory.StartNew(() =>
            {
                try
                {
                    string mailBody = "";
                    using (var reader = new StreamReader(Server.MapPath("~/Templates/AssetCorrection.html")))
                    {
                        mailBody = String.Format(reader.ReadToEnd(), AssetType, SerialNo, RequestedBy, PrevStatus, PrevBuilding, PrevArea, PrevCubicleNo, PrevPsid, ReqStatus, ReqBuilding, ReqArea, ReqCubicleNo, ReqPsid, comments);
                    }
                    //  UIHelper.Helper.SendEmail(mailBody, EmailID, MailSubject);


                    //10/04/2017
                    EMailHelper email = new EMailHelper();
                    email.Sender = ConfigurationManager.AppSettings["EmailFromAddress"].ToString();

                    //if email is not deployed, use dummy email address
                    if (Convert.ToBoolean(ConfigurationManager.AppSettings["IsEmailDeployed"]))
                        email.Recipient = EmailID;
                    else
                    {
                        email.Recipient = ConfigurationManager.AppSettings["DummyEmailAddress"].ToString();
                    }
                    email.RecipientCC = (String.IsNullOrEmpty(ConfigurationManager.AppSettings["EmailCCAddress"].ToString())) ? null : ConfigurationManager.AppSettings["EmailCCAddress"].ToString();

                    email.Subject = MailSubject;
                    email.Body = mailBody;
                    email.Send();

                }
                catch (Exception ex)
                {
                }
            });
        }

        private List<InputParameters> Setparam()
        {
            return new List<InputParameters>
            {
                new InputParameters {SqlParam = "AccessGroupID", ParamValue = GetSessionValue<UserProfile>("UserProfile").UserGroups.FirstOrDefault().GroupID},
                new InputParameters {SqlParam = "SerialNo", ParamValue = Helper.StringExtensions.IsNullOrBlank(SerialNoTxtClient.Text)?null:SerialNoTxtClient.Text},
                new InputParameters {SqlParam = "FARSrNo", ParamValue = Helper.StringExtensions.IsNullOrBlank(FARTxtClient.Text)?null:FARTxtClient.Text.Trim()},
                new InputParameters {SqlParam = "PSID", ParamValue = Helper.StringExtensions.IsNullOrBlank(PSIDTxtClient.Text)?null:PSIDTxtClient.Text}
            };
        }

        #endregion User defined methods
    }
}