﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AssetManagementLibrary.Entities.Movement;
using System.Web.Script.Serialization;
using System.Web.Mvc;
namespace AssetManagement
{
    /// <summary>
    /// Summary description for DataHandler
    /// </summary>
    public class DataHandler : IHttpHandler
    {
        public AssetManagementLibrary.Queries QueryHelper
        {
            get
            {
                return new AssetManagementLibrary.Queries();
            }
        }
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            context.Response.Write("Hello World");

            string method = context.Request.QueryString["MethodName"].ToString();
            context.Response.ContentType = "text/json";
            string hpsm = context.Request.Form["hpsm"];
            string psid = context.Request.Form["psid"];
            switch (method)
            {
                case "GetData":
                    context.Response.Write(GetData(hpsm, psid));
                    break;
            }

        }

        protected string GetData(string hpsm, string psid)
        {
            var recordCount = 0;
            var ipGetDetails = new List<InputParameters>
            {
                new InputParameters {SqlParam = "HPSM", ParamValue = hpsm},
                new InputParameters {SqlParam = "PSID", ParamValue = psid}
            };
            var dt = QueryHelper.GetRelatedAssetsOnNewRequest(ipGetDetails);
            if (dt != null)
            {
                recordCount = dt.Count;
                var jsonSerialiser = new JavaScriptSerializer();

                var list = (List<AssetTranExtn>)HttpContext.Current.Session["datatobind_grdAssetSplit"];
                if (list != null)
                {
                    var sessionCount = list.Where(x => x.HpsmNo == hpsm && x.EndUserId == psid).Count();
                    recordCount += sessionCount;
                }
            }
            //var data = jsonSerialiser.Serialize(new { count = recordCount, hpsmno = hpsm, userid = psid });

            return (new JavaScriptSerializer().Serialize(new { count = recordCount, hpsmno = hpsm, userid = psid }));
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}