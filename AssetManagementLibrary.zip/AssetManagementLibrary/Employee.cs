﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary
{
    public class Employee
    {
        #region Private Variables

        private string _employeeName = string.Empty;
        private string _fullName = string.Empty;
        private string _employeePSID = string.Empty;
        private string _employeeHID = string.Empty;
        private string _departmentID = string.Empty;
        private string _contactNumber = string.Empty;
        private string _residenceAddress = string.Empty;
        private string _latLong = string.Empty;
        private string _addressChangeCount = string.Empty;
        private int _status = 0;
        private DateTime _modDate;

        #endregion

        #region Properties

        public string EmployeeName
        {
            get { return _employeeName; }
            set { _employeeName = value; }
        }

        public string FullName
        {
            get { return _fullName; }
            set { _fullName = value; }
        }

        public string EmployeePSID
        {
            get { return _employeePSID; }
            set { _employeePSID = value; }
        }

        public string EmployeeHID
        {
            get { return _employeeHID; }
            set { _employeeHID = value; }
        }

        public string DepartmentID
        {
            get { return _departmentID; }
            set { _departmentID = value; }
        }

        public string ContactNumber
        {
            get { return _contactNumber; }
            set { _contactNumber = value; }
        }

        public string ResidenceAddress
        {
            get { return _residenceAddress; }
            set { _residenceAddress = value; }
        }

        public string LatLong
        {
            get { return _latLong; }
            set { _latLong = value; }
        }

        public string AddressChangeCount
        {
            get { return _addressChangeCount; }
            set { _addressChangeCount = value; }
        }

        public int Status
        {
            get { return _status; }
            set { _status = value; }
        }

        public DateTime ModDate
        {
            get { return _modDate; }
            set { _modDate = value; }
        }
        #endregion
    }
}
