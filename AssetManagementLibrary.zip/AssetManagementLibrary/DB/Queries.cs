﻿using System.Collections.Generic;
using System.Data;
using I3L.Data;
using System.Configuration;
using System.Web;
using AssetManagement;
using AssetManagementLibrary.Entities;
using System.Data.Entity;
using System.Data.SqlClient;
using AssetManagementLibrary.OtherHelpers;
using AssetManagementLibrary.Entities.Movement;
using System.Linq;
using AssetManagementLibrary.Entities.Movement.Report;
using AssetManagementLibrary.Entities.Movement.Menu;

namespace AssetManagementLibrary
{
    public class Queries
    {
        #region Variables
        SqlServer _sqlServer;
        private string _query;
        readonly string _connectionString;
        private DataSet _dsassetstatus = null;
        private DataSet _dsassettype = null;

        // string connectionString = System.Data.Common.GetConnectionString();

        #endregion


        #region Stored procedure names

        private const string _buildingReportDataQuery = "Usp_GetAssetScanedDetails";
        private const string _getScanEngineers = "Usp_GetScanEngineers";
        private const string _getAssetTrackerSearch = "Usp_AssetTrackerSearch";
        private const string _updateAssetTracker = "Usp_UpdateAssets";
        private const string _insertReviewDetails = "Usp_InsertReviewDetails";
        private const string _userAcceptance = "Usp_UserAcceptance";
        private const string _getuseracceptancedata = "Usp_AssetsUserAcceptance";
        private const string _getpvreport = "USP_GetPVReport";
        private const string _assetdailyreview = "Usp_AssetDailyReview";
        private const string _updateassetdailyreview = "Usp_UpdateAssetDailyReview";
        private const string _username = "Usp_GetUserName";
        private const string _getbuildingonlocation = "Usp_GetBuildingDetails";
        private const string _getareaonblock = "Usp_GetAreaDetails";
        private const string _getcubicleonarea = "Usp_GetCubicleNumbers";
        private const string _getpsid = "Usp_GetEmployeeDetails";
        private const string _insertassets = "Usp_InsertAsset";
        private const string _getloggedinuser = "GS_GetLoggedInUserInfo";

        private const string _getserialnumber = "Usp_GetSerialNumber";
        private const string _getItemMasterDataQuery = "Usp_GetItemMaster";
        private const string _updateItemMaster = "Usp_UpdateItemMaster";
        private const string _insertItemMaster = "Usp_insertItemMaster";
        private const string _getCubicleLocation = "Usp_GetItemMasterCubicle";
        private const string _getDeploymentRegisterDataQuery = "Usp_GetDeploymentRegister";
        private const string _insertDepRegister = "Usp_InsertDeployRegister";
        private const string _updateDepRegister = "Usp_UpdateDeployReg";
        private const string _GetEmployeeSeatOnPSID = "Usp_GetEmployeeSeatOnPSID";
        private const string _delDepRegister = "Usp_delDepRegister";
        private const string _GetKeyValueData = "Usp_GetKeyDataDepRegiter";
        private const string _GetPurpose = "USP_GetPurpose";
        private const string _GetAssetsForReceive = "USP_GetAssetsForReceive";
        private const string _GetAssetsForEndUser = "USP_GetAssetsForEndUser";
        private const string _GetAssetsForBE = "USP_GetAssetsForBE";
        private const string _GetAssetsForGaurd = "USP_GetAssetsForGaurd";
        private const string _GetAssetsForGaurdInTransit = "USP_GetAssetsForGaurdInTransit";
        private const string _GetAssetsForApproval = "USP_GetAssetsForApproval";
        private const string _UpdateAssetStatus = "USP_UpdateAssetTranStatus";
        private const string _GetUserDetails = "USP_GetUserDetails";
        private const string _GetUserInfo = "USP_GetUserInfo";
        private const string _GetCubicleDetails = "USP_GetCubicleDetails";
        private const string _GetUserDetailsForAddEngineer = "USP_GetUserDetailsForAddEngineer";
        private const string _GetAssetsForAssetAllocation = "USP_GetAssetsForAssetAllocation";
        private const string _GetAssetsForAllocationEdit = "USP_GetAssetsForAllocationEdit";
        private const string _GetAssetsForConfiguration = "USP_GetAssetsForConfiguration";
        private const string _GetAssetsForAssetReallocation = "USP_GetAssetsForAssetReallocation";
        private const string _GetCubicleForComboBox = "USP_GetCubicleForComboBox";
        private const string _UpdateAssetAllocation = "USP_UpdateAssetAllocation";
        private const string _UpdateAssetReallocation = "USP_UpdateAssetReallocation";
        private const string _GetAssetsForTranHistory = "USP_GetAssetsForTransactionHistory";
        private const string _UpdateSysAssetStatus = "USP_UpdateSysAssetStatus";
        private const string _SubmitMovementdata = "USP_InsertNewRequest";
        private const string _GetUseGroupProfile = "USP_GetUserGroupDetails";
        private const string _GetDefualtLocations = "select * from DefaultLocation";
        private const string _GetPopUpAssets = "USP_GetAssetsForSelection";
        private const string _GetAssettranlog = "USP_GetAssetTranDetails";
        private const string _GetAssethandoverData = "USP_GetAssetsForAssetHandover";
        private const string _GetEnginnersDetail = "USP_GetEnginnersDetail";
        private const string _SubmitForHandover = "USP_UpdateAssetHandOver";
        private const string _GetEmailID = "USP_GetEmailID";
        private const string _GetLocationsWithBuildingInfo = "USP_GetLocationsWithBuildingInfo";
        private const string _GetSelectedEmployeeDetails = "USP_EndUserDetails";
        private const string _UpdateConfigurationEngineer = "USP_UpdateConfigurationEngineer";
        private const string _GetAssetsForConfigurationEngineer = "USP_GetAssetsForConfigurationEngineer";
        private const string _GetAssetsForAssetLead = "USP_GetAssetsForAssetAcknowledgement";
        private const string _GetAssetInTransit = "Usp_GetAssestsinTransaction";
        private const string _ReallocateEngineer = "Usp_ReallocateBuildingEngineer";
        private const string _GetSysEngineers = "Usp_GetSysEngineers";
        private const string _AddSysEngineer = "Usp_AddSysEngineer";
        private const string _DeleteSysEngineer = "Usp_DeleteSysEngineer";
        private const string _UpdateSysEngineer = "Usp_UpdateSysEngineer";
        private const string _GetTeamInfo = "Usp_GetTeamInfo";
        private const string _GetEngineerType = "Usp_GetEngineerType";
        private const string _GetAssetsForPrintMaster = "USP_GetAssetsForPrintMaster";
        private const string _GetAssetsForPrintDetail = "USP_GetAssetsForPrintDetail";
        private const string _mailerDetails = "Usp_GetMailerDetailsforDeployemntReg";
        private const string _GetAssetsForPrint = "USP_GetAssetsForHpsmNo";
        private const string _GetAssetLeadAcceptRejectAssets = "USP_GetAssetsForLeadReject";
        private const string _GetAssetstat = "select * from SysAssetStatus ";
        private const string _UpdateFinalreject = "USP_updateAssetRejectStatus";
        private const string _GetRejectedAssetsForTL = "USP_GetAssetsForTLReject";
        private const string _GetAssetsForDeployment = "USP_GetAssetsForDeployment_Print";
        private const string _GetAssetsForMovement = "USP_GetAssetsForMovement_Print";
        private const string _GetAssetsForHandover = "USP_GetAssetsForHandover_Print";
        private const string _UpdateFormNo = "USP_UpdateFormNo";
        private const string _GetAssetsForItemHistory = "USP_GetAssetsForItemSummaryReport";
        private const string _GetAssetStatus = "USP_GetAssetStatus";
        private const string _GetAssetsForStatusReport = "USP_GetAssetsForStatusReport";
        private const string _GetAssetsForStockAdjustment = "USP_GetAssetsForStockAdjustment";
        private const string _InsertNewRequestStockAdjustment = "USP_InsertNewReqForStockAdjustment";
        private const string _UpdateStockAdjustment = "USP_UpdateStockAdjustment";
        private const string _GetEnduserReport = "USP_GetAssestForUserConfirmationReport";
        private const string _UpdateAssetLocation = "USP_UpdateAssetLocation";
        private const string _GetAssetsForOwnershipReport = "USP_GetAssetsForOwnershipReport";
        private const string _GetAssetsForMovementReport = "USP_GetAssetsForMovementReport";
        private const string _GetSerialNumbersforredeploy = "USP_GetSerialNoForReplacement";
        private const string _GetHpsmNo = "USP_GetHpsmNo";
        private const string _GetInventorySummary = "USP_GetInventorySummary";
        private const string _GetMenuAccessItems = "USP_GetMenuAccessItems";

        //New update queries
        private const string _UpdateForApproval = "USP_UpdateForApproval";
        private const string _UpdateForBEAction = "USP_UpdateForBEAction";
        private const string _UpdateForGuard = "USP_UpdateForGuard";
        private const string _UpdateForReceive = "USP_UpdateForReceive";
        private const string _UpdateForConfig = "USP_UpdateForConfiguration";
        private const string _UpdateForAssetAck = "USP_UpdateForAssetAck";
        private const string _UpdateForEndUserAck = "USP_UpdateForEndUserAck";

        private const string _GetHandoverReason = "USP_GetHandoverReason";
        private const string _GetAssetsForExceptionReport = "USP_GetAssetsForExceptionReport";
        private const string _UpdateForTLReject = "USP_UpdateForTLReject";
        private const string _GetAllAssetStatus = "USP_GetAssetStatus";

        private const string _GetLoggedInUserInfoUserAck = "GS_GetLoggedInUserInfo_EndUserAck";
        private const string _GetAcknowledgedAssetsForEndUser = "USP_GetAcknowledgedAssetsForEndUser";

        private const string _GetAssetsForAssetCorrection = "USP_GetAssetsForAssetCorrection";
        private const string _InsertNewRequestAssetCorrection = "USP_InsertNewReqForAssetCorrection";
        private const string _UpdateAssetCorrection = "USP_UpdateForAssetCorrection";

        private const string _InsertAssetDiscrepancy = "USP_InsertForAssetDiscrepancy";
        public const string _GetTier1EnggOnHPSM = "USP_GetEnginnersDetailOnHPSMNo";

        private const string _GetUserDetailsForItemSummary = "USP_GetUserDetailsforItemSummary";
        //10/04/2017
        private const string _GetAssetsForTranRevoke = "USP_GetAssetsForTransactionRevoke";
        private const string _UpdateForTransactionRevoke = "USP_UpdateForTransactionRevoke";
        //end

        private const string _GetRelatedAssetsOnNewRequest = "USP_GetRelatedAssetsOnNewRequest";
        private const string _GetUserRevertActionDetails = "USP_GetUserRevertActionDetails";
        private const string _UpdateUserRevertActionDetails = "USP_UpdateUserRevertActionDetails";
        private const string _GetListOfAssetsForEnduser = "USP_GetListOfAssetsForEnduser";
        private const string _GetCancelAssetData = "USP_GetCancelAssetData";
        private const string _CancelAssetRequest = "USP_CancelAssetRequest";
        private const string _GetSysAssetTypeForDirect = "USP_GetSysAssetTypeForDirect";

        private const string _GetWebGenieComparisionDetails = "USP_GetWebGenieComparisionDetails";
        private const string _GetSysMasterData = "USP_GetSysMasterData";
        private const string _GetReplacementPending = "USP_GetReplacementPending";
        private const string _GetTempPending = "USP_GetTempPending";
        #endregion


        #region Constructor
        public Queries()
        {
            #region Declaring Connection String
            _connectionString = ConfigurationManager.ConnectionStrings["AvaluetConnectionString"].ConnectionString;
            _sqlServer = new SqlServer(_connectionString);
            _query = "";
            #endregion
        }
        #endregion


        #region Functions

        /// <summary>
        /// Gets Location data required in  Main Form Page
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetLocations()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet("Select LocationID,LocationName from Location", CommandType.Text, null);
            }
        }

      

        /// <summary>
        /// Get serial numbers list for deployment
        /// </summary>
        /// <param name="ipEnduser"></param>
        /// <returns></returns>
        public DataSet GetSerialNumbersforredeploy(List<InputParameters> ipEnduser)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetSerialNumbersforredeploy, CommandType.StoredProcedure, ipEnduser);
            }
        }

        /// <summary>
        /// Get asset status types
        /// </summary>
        /// <returns></returns>
        public DataSet GetAssetStat()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetstat, CommandType.Text, null);
            }
        }

        /// <summary>
        /// Get HpsmNo list
        /// </summary>
        /// <returns></returns>
        public DataSet GetHpsmNo()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetHpsmNo, CommandType.Text, null);
            }
        }

        /// <summary>
        /// Get HpsmNo list
        /// </summary>
        /// <returns></returns>
        public DataSet GetHandoverReasonLst()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetHandoverReason, CommandType.StoredProcedure, null);
            }
        }

        /// <summary>
        /// Gets Asset Type data required in Search Asset page ANd Main Form Page
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetAssetType()
        {
            if (HttpContext.Current.Application["SysAssetType"] != null)
            {
                _dsassettype = (DataSet)HttpContext.Current.Application["SysAssetType"];

                return _dsassettype;
            }
            else
            {
                using (var dbHelper = new DBHelper())
                {
                    HttpContext.Current.Application["SysAssetType"] = dbHelper.GetDataSet("SELECT [SysAssetTypeID],[AssetType] FROM [SysAssetType]", CommandType.Text, null);
                }
                return (DataSet)HttpContext.Current.Application["SysAssetType"];
            }
        }

        /// <summary>
        /// Gets SMGTeam data required in Item Master
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet getSMGTeam()
        {
            if (HttpContext.Current.Application["SMGTeam"] != null)
            {
                _dsassettype = (DataSet)HttpContext.Current.Application["SMGTeam"];

                return _dsassettype;
            }
            else
            {
                using (var dbHelper = new DBHelper())
                {
                    HttpContext.Current.Application["SMGTeam"] = dbHelper.GetDataSet("SELECT [SMGTeamID],[SMGTeam] FROM [SysSMGTeam]", CommandType.Text, null);
                }
                return (DataSet)HttpContext.Current.Application["SMGTeam"];
            }
        }


        /// <summary>
        /// Get menu access items mapping
        /// </summary>
        /// <returns></returns>
        public List<MenuAccessGroup> GetMenuAccessItems()
        {

            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetMenuAccessItems, CommandType.StoredProcedure, null).ConvertToMenu();
            }

        }

        /// <summary>
        /// Gets Asset Status data required in Search Asset page ANd Main Form Page
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetAssetStatus()
        {
            if (HttpContext.Current.Application["SysAssetStatus"] != null)
            {
                _dsassetstatus = (DataSet)HttpContext.Current.Application["SysAssetStatus"];

                return _dsassetstatus;
            }
            else
            {
                using (var dbHelper = new DBHelper())
                {
                    HttpContext.Current.Application["SysAssetStatus"] = dbHelper.GetDataSet("SELECT [SysAssetStatusID],[AssetStatus] FROM [SysAssetStatus] WHERE AssetStatus IN ('Un-Assigned','Not-Working')", CommandType.Text, null);
                }
                return (DataSet)HttpContext.Current.Application["SysAssetStatus"];
            }
        }


        /// <summary>
        /// returns asset status from cache
        /// </summary>
        /// <returns></returns>
        public Dictionary<int, string> GetAllAssetStatus()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAllAssetStatus, CommandType.StoredProcedure, null).ConvertAssetStatus();
            }
        }

        /// <summary>
        /// Get end users list
        /// </summary>
        /// <returns></returns>
        public DataSet GetEndUsers()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet("select EMPLID as ToPsid ,NAME_DISPLAY as ToName from I3LIntMaster.dbo.PS_I2L_EMP_INFO", CommandType.Text, null);
            }
        }

        /// <summary>
        /// Get assets to print
        /// </summary>
        /// <param name="iphpsm"></param>
        /// <returns></returns>
        public DataSet GetAssetsToPrint(List<InputParameters> iphpsm)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForPrint, CommandType.StoredProcedure, iphpsm);
            }
        }

        /// <summary>
        /// Gets Scan Enginner data required in Search Asset page 
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetScanUser(List<InputParameters> ipsacnengineer)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_getScanEngineers, CommandType.StoredProcedure, ipsacnengineer);
            }
        }

        /// <summary>
        /// Gets Asset Tracker data required in Search Asset page 
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet LoadGrid(List<InputParameters> ipsearchassetgrid)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_getAssetTrackerSearch, CommandType.StoredProcedure, ipsearchassetgrid);
            }
        }

        /// <summary>
        /// Get Physical Verification Report
        /// </summary>
        /// <param name="ippsid"></param>
        /// <returns>DataSet</returns>
        public DataSet GetPvReport(List<InputParameters> ippsid)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_getpvreport, CommandType.StoredProcedure, ippsid);
            }
        }

        /// <summary>
        /// Loading the Review Grid In Daily review Page
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet LoadReviewGrid(List<InputParameters> ipreviewgrid)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_assetdailyreview, CommandType.StoredProcedure, ipreviewgrid);
            }
        }

        /// <summary>
        /// Loading the Review Grid In Daily review Page
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetUserName(List<InputParameters> ipempid)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_username, CommandType.StoredProcedure, ipempid);
            }
        }

        /// <summary>
        /// User Acceptance to be inserted in the Asset Tracker
        /// </summary>
        /// <returns>DataSet</returns>
        public bool UserAcceptance(List<InputParameters> ipsearchassetgridupdate)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_userAcceptance, CommandType.StoredProcedure, ipsearchassetgridupdate);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipReject"></param>
        /// <returns></returns>
        public bool updateFinalreject(List<InputParameters> ipReject)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateFinalreject, CommandType.StoredProcedure, ipReject);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipReject"></param>
        /// <returns></returns>
        public List<AssetTranExtn> GetTleject(List<InputParameters> ipReject)
        {


            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetRejectedAssetsForTL, CommandType.StoredProcedure, ipReject).ConvertToAssetExtension();
            }

        }

        /// <summary>
        /// Update Asset Tracker data required in Search Asset page 
        /// </summary>
        /// <returns>DataSet</returns>
        public DBResult AssetTrackerUpdate(List<InputParameters> ipsearchassetgridupdate)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQueryWithDbResult(_updateAssetTracker, CommandType.StoredProcedure, ipsearchassetgridupdate);
            }
        }

        /// <summary>
        /// Update Asset Tracker data required in Search Asset page 
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetTeamInfo()
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetTeamInfo, CommandType.StoredProcedure, null);
            }
        }

        /// <summary>
        /// Update Asset Tracker data required in Search Asset page 
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetEngineerType()
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetEngineerType, CommandType.StoredProcedure, null);
            }
        }

        /// <summary>
        /// Update Asset Tracker data required in Search Asset page 
        /// </summary>
        /// <returns>bool</returns>
        public bool AssetInsertReview(List<InputParameters> ipsearchassetgridupdate)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_insertReviewDetails, CommandType.StoredProcedure, ipsearchassetgridupdate);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipGetAssetsForPrint"></param>
        /// <returns></returns>
        public bool UpdateFormNo(List<InputParameters> ipGetAssetsForPrint)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateFormNo, CommandType.StoredProcedure, ipGetAssetsForPrint);
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipAccessgrp"></param>
        /// <returns></returns>
        public List<AssetTranExtn> GetRejectedAssets(List<InputParameters> ipAccessgrp)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetLeadAcceptRejectAssets, CommandType.StoredProcedure, ipAccessgrp).ConvertToAssetExtension();
            }
        }

        /// <summary>
        /// Get building based on location
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetBlockBasedOnLocation(List<InputParameters> ipbuildingonlocation)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_getbuildingonlocation, CommandType.StoredProcedure, ipbuildingonlocation);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipsubmitdata"></param>
        /// <returns></returns>
        public bool SubmitAssetMovement(List<InputParameters> ipsubmitdata)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_SubmitMovementdata, CommandType.StoredProcedure, ipsubmitdata);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipdataonselection"></param>
        /// <returns></returns>
        public DataSet GetpopUpAssetgridData(List<InputParameters> ipdataonselection)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetPopUpAssets, CommandType.StoredProcedure, ipdataonselection);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipuserid"></param>
        /// <returns></returns>
        public DataSet GettransactionLog(List<InputParameters> ipuserid)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssettranlog, CommandType.StoredProcedure, ipuserid);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipdate"></param>
        /// <returns></returns>
        public DataSet GetUserReport(List<InputParameters> ipdate)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetEnduserReport, CommandType.StoredProcedure, ipdate);
            }
        }

        /// <summary>
        /// get area based on building
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetAreaBasedOnBlock(List<InputParameters> ipareabasedonblock)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_getareaonblock, CommandType.StoredProcedure, ipareabasedonblock);
            }
        }

        /// <summary>
        ///  
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetDatatoAcknowledge(List<InputParameters> ipacknowledge)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_getuseracceptancedata, CommandType.StoredProcedure, ipacknowledge);
            }
        }

        /// <summary>
        /// get cubicle numbers based in area details
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetCubicleBasedOnArea(List<InputParameters> ipcubiclebasedonarea)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_getcubicleonarea, CommandType.StoredProcedure, ipcubiclebasedonarea);
            }
        }


        /// <summary>
        /// get Loginuser details
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet Getcredentials(List<InputParameters> iploginuser)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_getloggedinuser, CommandType.StoredProcedure, iploginuser);
            }
        }

        /// <summary>
        /// get Loginuser details 
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetCredentialsForUserAck(List<InputParameters> iploginuser)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetLoggedInUserInfoUserAck, CommandType.StoredProcedure, iploginuser);
            }
        }


        /// <summary>
        /// Get Serial Number
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetSerialNumber(List<InputParameters> ipserialnumber)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_getserialnumber, CommandType.StoredProcedure, ipserialnumber);
            }
        }


        /// <summary>
        /// Get User Details by cubicle number
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetPSID(List<InputParameters> ipcubicleid)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_getpsid, CommandType.StoredProcedure, ipcubicleid);
            }
        }

        /// <summary>
        /// Update Asset Tracker data required in Search Asset page 
        /// </summary>
        /// <returns>bool</returns>
        public bool Reviewpageasset(List<InputParameters> ipreviewasset)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_updateassetdailyreview, CommandType.StoredProcedure, ipreviewasset);
            }
        }

        /// <summary>
        /// InsertAssets in asset tracker
        /// </summary>
        /// <returns>bool</returns>
        public bool InsertAsset(List<InputParameters> ipinsertasset)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_insertassets, CommandType.StoredProcedure, ipinsertasset);
            }
        }

        /// <summary>
        /// Gets [Asset Scanned Count, Asset Type, Asset Status, PSID, Name, Dept, Location, Building, Floor] data used for populating Pivot Grid in buildingReportData.aspx page
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetBuildingReportData()
        {
            using (var dbhelper = new AssetManagement.DBHelper())
            {
                return dbhelper.GetDataSet(_buildingReportDataQuery, System.Data.CommandType.Text, null);
            }
        }

        /// <summary>
        /// Gets Item Master from Item Master Table
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetItemMaster()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_getItemMasterDataQuery, CommandType.Text, null);
            }
        }

        /// <summary>
        /// Update Data in ItemMaster
        /// </summary>
        /// <returns>bool</returns>
        public DBResult UpdateItemMaster(List<InputParameters> ipItemMaster)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQueryWithDbResult(_updateItemMaster, CommandType.StoredProcedure, ipItemMaster);
            }
        }

        /// <summary>
        /// insert Data in ItemMaster
        /// </summary>
        /// <returns>bool</returns>
        public DBResult InsertItemMaster(List<InputParameters> ipItemMaster)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQueryWithDbResult(_insertItemMaster, CommandType.StoredProcedure, ipItemMaster);
            }
        }

        /// <summary>
        /// Get the location of Cubicle from Seating planner
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetCubicleLocation()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_getCubicleLocation, CommandType.Text, null);
            }
        }

        /// <summary>
        /// Gets Item Master from Item Master Table
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetDeploymentRegister()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_getDeploymentRegisterDataQuery, CommandType.Text, null);
            }
        }

        /// <summary>
        /// Insert Data in Deploy Register
        /// </summary>
        /// <returns>bool</returns>
        public DBResult InsertDeployRegister(List<InputParameters> ipItemMaster)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQueryWithDbResult(_insertDepRegister, CommandType.StoredProcedure, ipItemMaster);
            }
        }

        /// <summary>
        /// To fetch asset details for Configuration page
        /// </summary>
        /// <param name="ipGetAssetsForConfig">AccessGroupID, EngineerID, HPSMNo</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetAssetsForConfigEngineer(List<InputParameters> ipGetAssetsForConfig)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForConfigurationEngineer, CommandType.StoredProcedure, ipGetAssetsForConfig).ConvertToAssetExtension();
            }
        }

        /// <summary>
        /// To fetch asset details for Deployment form print
        /// </summary>
        /// <param name="ipGetAssetsForConfig">List of HPSMNo</param>
        /// <returns>List of Form</returns>
        public List<Form> GetAssetsForDeploy(List<InputParameters> ipGetAssetsForDeploymentForm)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForDeployment, CommandType.StoredProcedure, ipGetAssetsForDeploymentForm).ConvertToForm();
            }
        }

        /// <summary>
        /// To fetch asset details for Deployment form print
        /// </summary>
        /// <param name="ipGetAssetsForConfig">List of HPSMNo</param>
        /// <returns>List of Form</returns>
        public List<Form> GetAssetsForMovement(List<InputParameters> ipGetAssetsForMovementForm)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForMovement, CommandType.StoredProcedure, ipGetAssetsForMovementForm).ConvertToForm();
            }
        }

        /// <summary>
        /// To fetch asset details for Deployment form print
        /// </summary>
        /// <param name="ipGetAssetsForConfig">List of HPSMNo</param>
        /// <returns>List of Form</returns>
        public List<Form> GetAssetsForHandover(List<InputParameters> ipGetAssetsForHandoverForm)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForHandover, CommandType.StoredProcedure, ipGetAssetsForHandoverForm).ConvertToForm();
            }
        }

        /// <summary>
        /// To fetch asset details for Configuration page
        /// </summary>
        /// <param name="ipGetAssetsForConfig">AccessGroupID, EngineerID, HPSMNo</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<Engineer> GetAssetsForAddEngineer(List<InputParameters> ipGetSysEngineers)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetSysEngineers, CommandType.StoredProcedure, ipGetSysEngineers).ConvertToEngineer();
            }
        }

        /// <summary>
        /// To fetch asset details for Configuration page
        /// </summary>
        /// <param name="ipGetAssetsForConfig">AccessGroupID, EngineerID, HPSMNo</param>
        /// <returns>List of AssetTranExtn</returns>
        public bool AddSysEngineer(List<InputParameters> ipAddSysEngineers)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_AddSysEngineer, CommandType.StoredProcedure, ipAddSysEngineers);
            }
        }


        /// <summary>
        /// To fetch asset details for Configuration page
        /// </summary>
        /// <param name="ipGetAssetsForConfig">AccessGroupID, EngineerID, HPSMNo</param>
        /// <returns>List of AssetTranExtn</returns>
        public bool DeleteSysEngineer(List<InputParameters> ipDeleteSysEngineers)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_DeleteSysEngineer, CommandType.StoredProcedure, ipDeleteSysEngineers);
            }
        }


        /// <summary>
        /// To fetch asset details for Configuration page
        /// </summary>
        /// <param name="ipGetAssetsForConfig">AccessGroupID, EngineerID, HPSMNo</param>
        /// <returns>List of AssetTranExtn</returns>
        public bool UpdateSysEngineer(List<InputParameters> ipUpdateSysEngineers)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateSysEngineer, CommandType.StoredProcedure, ipUpdateSysEngineers);
            }
        }



        /// <summary>
        /// To fetch asset details for Exception report
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetAssetsForExceptionReport()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForExceptionReport, CommandType.StoredProcedure, null);
            }
        }


        /// <summary>
        /// Gets Assettype details
        /// </summary>
        /// <param name="assetItemId"></param>
        /// <returns>DataSet</returns>
        public DataSet GetInventorySummary(List<InputParameters> ipInv)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetInventorySummary, CommandType.StoredProcedure, ipInv);
            }
        }

        /// <summary>
        /// Gets Assettype details
        /// </summary>
        /// <param name="assetItemId"></param>
        /// <returns>DataSet</returns>
        public DataSet GetAssetItem(string assetItemId)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(@"SELECT SA.SysAssetID,SA.FARNumber,SA.SerialNumber,SA.QRCode FROM SysAsset SA Where SA.SysAssetTypeID = '" + assetItemId + "'", CommandType.Text, null);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectedpsid"></param>
        /// <returns></returns>
        public DataSet GetDefaultBuildingtoBuuildingDataset(List<InputParameters> selectedpsid)
        {

            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetSelectedEmployeeDetails, CommandType.StoredProcedure, selectedpsid);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataSet GetFloorEngineers()
        {
            var getEngineers = @" select distinct eng.EngineerID as PSID,data.NAME_DISPLAY as Name from  [AMS].[dbo].[FloorEngineer] eng left join [I3LIntMaster].dbo.PS_I2L_EMP_INFO data on cast(eng.EngineerID as varchar) =data.EMPLID";
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(getEngineers, CommandType.Text, null);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="psid"></param>
        /// <returns></returns>
        public DataSet GetHpsmNumberforcurrentuserDataSet(string psid)
        {
            var getHpsmNumbers = @" select distinct HPSMNo from AssetTran where ModBy=" + psid + "";
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(getHpsmNumbers, CommandType.Text, null);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="psid"></param>
        /// <returns></returns>
        public DataSet GetMovementTypeforcurrentuserDataSet(string psid)
        {
            var getPurpose = @"select distinct b.SysPurposeID,a.Description from AssetTran b left join SysPurpose a on b.SysPurposeID = a.SysPurposeID where b.ModBy=" +
                  psid + "";
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(getPurpose, CommandType.Text, null);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipParam"></param>
        /// <returns></returns>
        public DataSet GetAssetsInTransactionDataSet(List<InputParameters> ipParam)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetInTransit, CommandType.StoredProcedure, ipParam);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="handoverInputParameterses"></param>
        /// <returns></returns>
        public DataSet GetAssetsforHandoverDataSet(List<InputParameters> handoverInputParameterses)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssethandoverData, CommandType.StoredProcedure, handoverInputParameterses);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipHandoverAssets"></param>
        /// <returns></returns>
        public bool UpdateHandOverStatus(List<InputParameters> ipHandoverAssets)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_SubmitForHandover, CommandType.StoredProcedure, ipHandoverAssets);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataSet GetAvailablePurposeTypesDtaDataSet()
        {
            var getType = @"select SysPurposeID,Description from dbo.SysPurpose";
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(getType, CommandType.Text, null);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipdeployreg"></param>
        /// <returns></returns>
        public DBResult UpdateDeployRegister(List<InputParameters> ipdeployreg)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQueryWithDbResult(_updateDepRegister, CommandType.StoredProcedure, ipdeployreg);
            }
        }

        /// <summary>
        /// Get PSID & Employee Name from i3lIntMaster
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetEmpDataSet()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet("SELECT EMPLID PSID, NAME_DISPLAY UserName FROM I3LIntMaster.dbo.PS_I2L_EMP_INFO WHERE HR_STATUS = 'A' OR  DATEDIFF(day,TERMINATION_DATE,GETDATE()) < 180 ", CommandType.Text, null);
            }
        }

        /// <summary>
        /// To fetch asset details for User Acknowledgement page
        /// </summary>
        /// <param name="ipGetAssetsForEndUser">UserPSID</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetAssetsForAssetLead(List<InputParameters> ipGetAssetsForEndUser)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForAssetLead, CommandType.StoredProcedure, ipGetAssetsForEndUser).ConvertToAssetExtension();
            }
        }



        /// <summary>
        /// Get Seating Details on  PSID
        /// </summary>
        /// <returns>bool</returns>
        public DataSet GetEmpSeatonPsid(List<InputParameters> ipEmployeeSeat)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetEmployeeSeatOnPSID, CommandType.StoredProcedure, ipEmployeeSeat);
            }
        }

        /// <summary>
        /// Update Data in Deploy Register
        /// </summary>
        /// <returns>bool</returns>
        public DBResult DeleteDeployRegister(List<InputParameters> ipDeployregdel)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQueryWithDbResult(_delDepRegister, CommandType.StoredProcedure, ipDeployregdel);
            }
        }

        /// <summary>
        /// Get data from DepRegister based on key Value
        /// </summary>
        /// <returns>bool</returns>
        public DataSet GetKeyValuesDepRegister(List<InputParameters> ipGetKeyValues)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetKeyValueData, CommandType.StoredProcedure, ipGetKeyValues);
            }
        }



        /// <summary>
        /// To fetch the PurposeID and Purpose Details
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetPurpose()
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetPurpose, CommandType.StoredProcedure, null);
            }
        }


        /// <summary>
        /// To fetch the PurposeID and Purpose Details
        /// </summary>
        /// <returns>DataSet</returns>
        public Dictionary<int, string> GetPurposeDictionary()
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetPurpose, CommandType.StoredProcedure, null).ConvertToDictionary<int, string>(0, 1);
            }
        }



        /// <summary>
        /// To fetch the PurposeID and Purpose Details
        /// </summary>
        /// <returns>DataSet</returns>
        public DataSet GetEmailID(List<InputParameters> ipGetEmailID)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetEmailID, CommandType.StoredProcedure, ipGetEmailID);
            }
        }



        /// <summary>
        /// To fetch asset details for Receive page
        /// </summary>
        /// <param name="ipGetAssetsForReceive">AccessGroupID, SysPurposeID</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetAssetsForReceive(List<InputParameters> ipGetAssetsForReceive)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForReceive, CommandType.StoredProcedure, ipGetAssetsForReceive).ConvertToAssetExtension();
            }
        }



        /// <summary>
        /// To fetch asset details for User Acknowledgement page
        /// </summary>
        /// <param name="ipGetAssetsForEndUser">UserPSID</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetAssetsForEndUser(List<InputParameters> ipGetAssetsForEndUser)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForEndUser, CommandType.StoredProcedure, ipGetAssetsForEndUser).ConvertToAssetExtension();
            }
        }




        /// <summary>
        /// To fetch asset details for User Acknowledgement page
        /// </summary>
        /// <param name="ipGetAssetsForEndUser">UserPSID</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetAcknowledgedAssetsForEndUser(List<InputParameters> ipGetAssetsForEndUser)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetAcknowledgedAssetsForEndUser, CommandType.StoredProcedure, ipGetAssetsForEndUser).ConvertToAssetExtension();
            }
        }


        /// <summary>
        /// To fetch asset details for Building Engineer page
        /// </summary>
        /// <param name="ipGetAssetsForBE">AccessGroupID, SysPurposeID, UserPSID</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetAssetsForBE(List<InputParameters> ipGetAssetsForBE)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForBE, CommandType.StoredProcedure, ipGetAssetsForBE).ConvertToAssetExtension();

            }
        }



        /// <summary>
        /// To fetch asset details for Gaurd page
        /// </summary>
        /// <param name="ipGetAssetsForGaurd">UserLoginID, SerialNo, AccessGroupID</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetAssetsForGaurd(List<InputParameters> ipGetAssetsForGaurd)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForGaurd, CommandType.StoredProcedure, ipGetAssetsForGaurd).ConvertToAssetExtension();
            }
        }



        /// <summary>
        /// To fetch asset details for Gaurd page
        /// </summary>
        /// <param name="ipGetAssetsForGaurd">UserLoginID, SerialNo, AccessGroupID</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetAssetsForGaurdInTransit(List<InputParameters> ipGetAssetsForGaurdInTransit)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForGaurdInTransit, CommandType.StoredProcedure, ipGetAssetsForGaurdInTransit).ConvertToAssetExtension();
            }
        }


        /// <summary>
        /// To fetch asset details for Approval page
        /// </summary>
        /// <param name="ipGetAssetsForApproval">Access GroupID, SysPurposeID</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetAssetsForApproval(List<InputParameters> ipGetAssetsForApproval)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForApproval, CommandType.StoredProcedure, ipGetAssetsForApproval).ConvertToAssetExtension();
            }
        }


        /// <summary>
        /// To fetch asset details for Asset Allocation page
        /// </summary>
        /// <param name="ipGetAssetsForAssetAlloc">AccessGroupID, SysPurposeID, HPSMNo</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetAssetsForAssetAllocation(List<InputParameters> ipGetAssetsForAssetAlloc)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForAssetAllocation, CommandType.StoredProcedure, ipGetAssetsForAssetAlloc).ConvertToAssetExtension();
            }
        }

        /// <summary>
        /// To fetch asset details for Allocation edit page
        /// </summary>
        /// <param name="ipGetAssetsForAssetAlloc">AccessGroupID, SysPurposeID, HPSMNo</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetAssetsForAllocationEdit(List<InputParameters> ipGetAssetsForAllocationEdit)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForAllocationEdit, CommandType.StoredProcedure, ipGetAssetsForAllocationEdit).ConvertToAssetExtension();
            }
        }


        /// <summary>
        /// To fetch asset details for Configuration page
        /// </summary>
        /// <param name="ipGetAssetsForConfig">AccessGroupID, SysPurposeID, HPSMNo</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetAssetsForConfig(List<InputParameters> ipGetAssetsForConfig)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForConfiguration, CommandType.StoredProcedure, ipGetAssetsForConfig).ConvertToAssetExtension();
            }
        }


        /// <summary>
        /// To fetch asset details for Asset Reallocation page
        /// </summary>
        /// <param name="ipGetAssetsForAssetReallocation">AccessGroupID, SysPurposeID, HPSMNo</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetAssetsForAssetReallocation(List<InputParameters> ipGetAssetsForAssetReallocation)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForAssetReallocation, CommandType.StoredProcedure, ipGetAssetsForAssetReallocation).ConvertToAssetExtension();
            }
        }


        /// <summary>
        /// To fetch asset details for Transaction History page
        /// </summary>
        /// <param name="ipGetAssetsForTranHistory">Serial No (optional), FromModDt, ToModDt, Building(optional)</param>
        /// <returns></returns>
        public DataSet GetAssetStatusForComboBox()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetStatus, CommandType.StoredProcedure, null);
            }
        }




        /// <summary>
        /// To fetch asset details for Transaction History page
        /// </summary>
        /// <param name="ipGetAssetsForTranHistory">Serial No (optional), FromModDt, ToModDt, Building(optional)</param>
        /// <returns></returns>
        public List<AssetTranExtn> GetAssetsForStockAdjustment(List<InputParameters> ipGetAssetsForStock)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForStockAdjustment, CommandType.StoredProcedure, ipGetAssetsForStock).ConvertToAssetExtension();
            }
        }




        /// <summary>
        /// To fetch asset details for Transaction History page
        /// </summary>
        /// <param name="ipGetAssetsForTranHistory">Serial No (optional), FromModDt, ToModDt, Building(optional)</param>
        /// <returns></returns>
        public List<AssetTranExtn> GetAssetsForAssetCorrection(List<InputParameters> ipGetAssetsForStock)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForAssetCorrection, CommandType.StoredProcedure, ipGetAssetsForStock).ConvertToAssetExtension();
            }
        }


        /// <summary>
        /// To fetch asset details for Transaction History page
        /// </summary>
        /// <param name="ipGetAssetsForTranHistory">Serial No (optional), FromModDt, ToModDt, Building(optional)</param>
        /// <returns></returns>
        public List<AssetTranExtn> GetAssetsForStatusReport(List<InputParameters> ipGetAssetsForStatusReport)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForStatusReport, CommandType.StoredProcedure, ipGetAssetsForStatusReport).ConvertToAssetExtension();
            }
        }




        /// <summary>
        /// To fetch asset details for Transaction History page
        /// </summary>
        /// <param name="ipGetAssetsForTranHistory">Serial No (optional), FromModDt, ToModDt, Building(optional)</param>
        /// <returns></returns>
        public List<AssetTranExtn> GetAssetsForTranHistory(List<InputParameters> ipGetAssetsForTranHistory)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForTranHistory, CommandType.StoredProcedure, ipGetAssetsForTranHistory).ConvertToAssetExtension();
            }
        }



        /// <summary>
        /// To fetch asset details for Transaction page
        /// </summary>
        /// <param name="ipGetAssetsForTranHistory">Transaction Date</param>
        /// <returns>List of AssetTranExtn entity</returns>
        public DataSet GetAssetsForItemHistory(List<InputParameters> ipGetAssetsForItemHistory)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForItemHistory, CommandType.StoredProcedure, ipGetAssetsForItemHistory);
            }
        }


        /// <summary>
        /// To fetch asset details for Transaction page
        /// </summary>
        /// <returns>List of AssetTranExtn entity</returns>
        public DataSet GetAssetsForOwnershipReport(List<InputParameters> ipTranGrid)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForOwnershipReport, CommandType.StoredProcedure, ipTranGrid);
            }
        }


        /// <summary>
        /// To fetch asset details for Transaction page
        /// </summary>
        /// <returns>List of AssetTranExtn entity</returns>
        public DataSet GetAssetsForMovementReport(List<InputParameters> ipTranGrid)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForMovementReport, CommandType.StoredProcedure, ipTranGrid);
            }
        }


        /// <summary>
        /// To fetch asset details for Print page master grid
        /// </summary>
        /// <param name="ipGetAssetsForTranHistory">HpsmNo (optional), FromModDt, ToModDt(optional)</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetAssetsForPrintMaster(List<InputParameters> ipGetAssetsForPrintMaster)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForPrintMaster, CommandType.StoredProcedure, ipGetAssetsForPrintMaster).ConvertToAssetExtension();
            }
        }


        /// <summary>
        /// To fetch asset details for Print page detail grid
        /// </summary>
        /// <param name="ipGetAssetsForTranHistory">HpsmNo</param>
        /// <returns></returns>
        public List<AssetTranExtn> GetAssetsForPrintDetail(List<InputParameters> ipGetAssetsForPrintDetail)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForPrintDetail, CommandType.StoredProcedure, ipGetAssetsForPrintDetail).ConvertToAssetExtension();
            }
        }


        /// <summary>
        /// To update asset location in SysAsset and AssetTran
        /// </summary>
        /// <param name="ipUpdateAssetLocation">AssetTranID</param>
        /// <returns></returns>
        public bool UpdateAssetLocation(List<InputParameters> ipUpdateAssetLocation)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateAssetLocation, CommandType.StoredProcedure, ipUpdateAssetLocation);
            }
        }


        /// <summary>
        /// Update Asset transaction status from any page
        /// </summary>
        /// <param name="ipUpdateAssetStatus">AssetTranID</param>
        /// <returns>bool</returns>
        public bool UpdateAssetStatus(List<InputParameters> ipUpdateAssetStatus)
        {
            using (var dbHelper = new DBHelper())
            {
                bool result = true;
                var tran = dbHelper.BeginTransaction();
                try
                {
                    result = dbHelper.ExecuteNonQuery(_UpdateAssetStatus, CommandType.StoredProcedure, ipUpdateAssetStatus);

                    if (result)
                        tran.Commit();
                    else
                        tran.Rollback();
                }
                catch
                {
                    tran.Rollback();
                }

                return result;
            }
        }


        //New Update methods --------------------

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipUpdateList"></param>
        /// <returns>bool</returns>
        public bool UpdateForApproval(List<InputParameters> ipUpdateList)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateForApproval, CommandType.StoredProcedure, ipUpdateList);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipUpdateList"></param>
        /// <returns>bool</returns>
        public bool UpdateForBEAction(List<InputParameters> ipUpdateList)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateForBEAction, CommandType.StoredProcedure, ipUpdateList);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipUpdateList"></param>
        /// <returns>bool</returns>
        public bool UpdateForGuard(List<InputParameters> ipUpdateList)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateForGuard, CommandType.StoredProcedure, ipUpdateList);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipUpdateList"></param>
        /// <returns>bool</returns>
        public bool UpdateForReceive(List<InputParameters> ipUpdateList)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateForReceive, CommandType.StoredProcedure, ipUpdateList);
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipUpdateList"></param>
        /// <returns>bool</returns>
        public bool UpdateForConfig(List<InputParameters> ipUpdateList)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateForConfig, CommandType.StoredProcedure, ipUpdateList);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipUpdateList"></param>
        /// <returns>bool</returns>
        public bool UpdateForAssetAck(List<InputParameters> ipUpdateList)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateForAssetAck, CommandType.StoredProcedure, ipUpdateList);
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipUpdateList"></param>
        /// <returns>bool</returns>
        public bool UpdateForEndUserAck(List<InputParameters> ipUpdateList)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateForEndUserAck, CommandType.StoredProcedure, ipUpdateList);
            }
        }


        /// <summary>
        /// Update action from TL reject page
        /// </summary>
        /// <param name="ipGetAssetsForUpdate"></param>
        /// <returns></returns>
        public bool UpdateForTLReject(List<InputParameters> ipGetAssetsForUpdate)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateForTLReject, CommandType.StoredProcedure, ipGetAssetsForUpdate);
            }
        }



        // New Update methods ends here --------------------------------------




        /// <summary>
        /// Update Asset details for Stock Adjustment
        /// </summary>
        /// <param name="ipUpdateAssetStatus"></param>
        /// <returns>bool</returns>
        public bool UpdateStockAdjustment(List<InputParameters> ipUpdateStockAdjust)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateStockAdjustment, CommandType.StoredProcedure, ipUpdateStockAdjust);
            }
        }


        /// <summary>
        /// Insert the new request for stock adjusment
        /// </summary>
        /// <param name="ipUpdateAssetStatus"></param>
        /// <returns>bool</returns>
        public bool InsertNewRequestStockAdjustment(List<InputParameters> ipUpdateStockAdjust)
        {
            using (var dbHelper = new DBHelper())
            {
                bool result = false;
                var tran = dbHelper.BeginTransaction();

                try
                {
                    result = dbHelper.ExecuteNonQuery(_InsertNewRequestStockAdjustment, CommandType.StoredProcedure, ipUpdateStockAdjust);
                    if (result)
                        tran.Commit();
                    else
                        tran.Rollback();
                }
                catch
                {
                    tran.Rollback();
                }

                return result;
            }
        }




        /// <summary>
        /// Update Asset details for Stock Adjustment
        /// </summary>
        /// <param name="ipUpdateAssetStatus"></param>
        /// <returns>bool</returns>
        public bool UpdateAssetCorrection(List<InputParameters> ipUpdateStockAdjust)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateAssetCorrection, CommandType.StoredProcedure, ipUpdateStockAdjust);
            }
        }


        /// <summary>
        /// Insert the new request for stock adjusment
        /// </summary>
        /// <param name="ipUpdateAssetStatus"></param>
        /// <returns>bool</returns>
        public bool InsertNewRequestAssetCorrection(List<InputParameters> ipUpdateAssetCorrection)
        {
            using (var dbHelper = new DBHelper())
            {
                bool result = false;
                var tran = dbHelper.BeginTransaction();

                try
                {
                    result = dbHelper.ExecuteNonQuery(_InsertNewRequestAssetCorrection, CommandType.StoredProcedure, ipUpdateAssetCorrection);
                    if (result)
                        tran.Commit();
                    else
                        tran.Rollback();
                }
                catch
                {
                    tran.Rollback();
                }

                return result;
            }
        }


        /// <summary>
        /// Update Engineers for AddEngineer page
        /// </summary>
        /// <param name="ipengineers"></param>
        /// <returns></returns>
        public bool UpdateEngineers(List<InputParameters> ipengineers)
        {

            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_ReallocateEngineer, CommandType.StoredProcedure, ipengineers);
            }
        }
        /// <summary>
        /// Update Asset transaction status from any page
        /// </summary>
        /// <param name="ipUpdateUserAckAssetStatus">AssetTranID</param>
        /// <returns>bool</returns>
        public bool UpdateUserAckAsssetStatus(List<InputParameters> ipUpdateUserAckAssetStatus)
        {
            using (var dbHelper = new DBHelper())
            {
                bool result = false;
                var tran = dbHelper.BeginTransaction();

                try
                {
                    result = dbHelper.ExecuteNonQuery(_UpdateAssetStatus, CommandType.StoredProcedure, ipUpdateUserAckAssetStatus);
                    ipUpdateUserAckAssetStatus.Remove(ipUpdateUserAckAssetStatus.Where(x => x.SqlParam == "IsEndUserAcknowledged").FirstOrDefault());
                    result = dbHelper.ExecuteNonQuery(_UpdateSysAssetStatus, CommandType.StoredProcedure, ipUpdateUserAckAssetStatus);
                    if (result)
                        tran.Commit();
                    else
                        tran.Rollback();
                }
                catch
                {
                    tran.Rollback();
                }

                return result;
            }
        }



        /// <summary>
        /// To update asset details from AssetReallocation page
        /// </summary>
        /// <param name="ipUpdateAssetRealloc">AssetTranID, FromPsid, FromCubicleNo, FromFloorId, UserPsid</param>
        /// <returns>Boolean</returns>
        public bool UpdateConfigurationEngineer(List<InputParameters> ipUpdatConfigEngg)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateConfigurationEngineer, CommandType.StoredProcedure, ipUpdatConfigEngg);
            }
        }

        /// <summary>
        /// To update asset details from 
        /// </summary>
        /// <param name="ipUpdateAssetAlloc">AssetTranId, FromPsid, FromCubicleNo, FromFloorId, ToPsid, ToCubicleNo, ToFloorId, MovementEnggId, UserPsid</param>
        /// <returns>Boolean</returns>
        public bool UpdateAssetAllocation(List<InputParameters> ipUpdateAssetAlloc)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateAssetAllocation, CommandType.StoredProcedure, ipUpdateAssetAlloc);
            }
        }

        /// <summary>
        /// To update asset details from AssetReallocation page
        /// </summary>
        /// <param name="ipUpdateAssetRealloc">AssetTranID, FromPsid, FromCubicleNo, FromFloorId, UserPsid</param>
        /// <returns>Boolean</returns>
        public bool UpdateAssetReallocation(List<InputParameters> ipUpdateAssetRealloc)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateAssetReallocation, CommandType.StoredProcedure, ipUpdateAssetRealloc);
            }
        }


        /// <summary>
        /// To fetch User details like Location, Building, Area, CubicleNo
        /// </summary>
        /// <param name="ipGetUserDetails">PSID</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetUserDetails(List<InputParameters> ipGetUserDetails)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetUserDetails, CommandType.StoredProcedure, ipGetUserDetails).ConvertToAssetExtension();
            }
        }

        public DataSet GetUserInfo(List<InputParameters> ipGetUserDetails)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetUserInfo, CommandType.StoredProcedure, ipGetUserDetails);
            }
        }
        /// <summary>
        /// To fetch User details like Location, Building, Area, CubicleNo
        /// </summary>
        /// <param name="ipGetUserDetails">PSID</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetCubicleDetails(List<InputParameters> ipGetCubicleDetails)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetCubicleDetails, CommandType.StoredProcedure, ipGetCubicleDetails).ConvertToAssetExtension();
            }
        }

        public DataSet GetUserDetails_ds(List<InputParameters> ipGetUserDetails)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetUserDetails, CommandType.StoredProcedure, ipGetUserDetails);
            }
        }

        /// <summary>
        /// To fetch User details like Location, Building, Area, CubicleNo
        /// </summary>
        /// <param name="ipGetUserDetails">PSID</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetUserDetailsForAddEngineer(List<InputParameters> ipGetUserDetails)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetUserDetailsForAddEngineer, CommandType.StoredProcedure, ipGetUserDetails).ConvertToAssetExtension();
            }
        }

        /// <summary>
        /// To fetch CubicleID, CubicleNo for Cubicle ComboBox
        /// </summary>
        /// <param name="ipGetCubicle">FloorID</param>
        /// <returns></returns>
        public List<AssetTranExtn> GetCubicleForComboBox(List<InputParameters> ipGetCubicle)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetCubicleForComboBox, CommandType.StoredProcedure, ipGetCubicle).ConvertToAssetExtension();
            }
        }


        /// <summary>
        /// Gets the userprofile details
        /// </summary>
        /// <param name="parameters">list of parameters</param>
        /// <returns>userprofile</returns>
        public static UserProfile GetUserProfile(List<InputParameters> parameters)
        {
            var sqlParm1 = new SqlParameter(parameters[0].SqlParam, parameters[0].ParamValue);
            var sqlParm2 = new SqlParameter(parameters[1].SqlParam, parameters[1].ParamValue);
            var queryStr = string.Format(@"{0} @{1}, @{2}", _GetUseGroupProfile, sqlParm1.ParameterName, sqlParm2.ParameterName);

            var result = DBHelper.DbContextSqlQueryRetrive<UserProfileDetail>(queryStr, sqlParm1, sqlParm2).ConvertToUserProfile();

            return result;

        }
        /// <summary>
        /// Gets default locations for cache 
        /// </summary>
        /// <returns>Dataset with the locations</returns>
        public DataSet GetDefaultLocationsForCache()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetDefualtLocations, CommandType.Text, null);
            }
        }

        /// <summary>
        /// Gets the engineers detail 
        /// </summary>
        /// <returns>list if engineers </returns>
        public List<Engineer> GetEnginnersDetail()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetEnginnersDetail, CommandType.Text, null).ConvertToEngineer();
            }
        }


        /// <summary>
        /// Gets locations with building info
        /// </summary>
        /// <returns>list of locations </returns>
        public List<Location> GetLocationsWithBuildingInfo()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetLocationsWithBuildingInfo, CommandType.Text, null).ConvertToLocations();
            }
        }

        /// <summary>
        /// Mailer Details After Adding in Deployment Register
        /// </summary>
        /// <returns>Dataset</returns>
        public DataSet GetMailerDetails(List<InputParameters> ipmailerDetails)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_mailerDetails, CommandType.StoredProcedure, ipmailerDetails);
            }
        }


        public bool InsertAssetdiscrepancy(List<InputParameters> ipinsertassetdiscrepancy)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_InsertAssetDiscrepancy, CommandType.StoredProcedure, ipinsertassetdiscrepancy);
            }
        }

        /// <summary>
        /// To fetch Tier1 Coordinator on HPSM
        /// </summary>
        /// <param name="ipGetUserDetails">PSID</param>
        /// <returns>List of Movement Engg</returns>
        public List<Engineer> GetTier1EnggOnHPSM(List<InputParameters> ipGetEnggDetails)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetTier1EnggOnHPSM, CommandType.StoredProcedure, ipGetEnggDetails).ConvertToEngineer();
            }
        }

        /// <summary>
        /// To fetch User details for Item Summary
        /// </summary>
        /// <param name="ipGetUserDetails">PSID</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetUserDetailsForItemSummary(List<InputParameters> ipGetUserDetails)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetUserDetailsForItemSummary, CommandType.StoredProcedure, ipGetUserDetails).ConvertToAssetExtension();
            }
        }

        /// <summary>
        /// To fetch asset details for Transaction History page
        /// </summary>
        /// <param name="ipGetAssetsForRevoke">Serial No (optional), FromModDt, ToModDt, Building(optional)</param>
        /// <returns></returns>
        public List<AssetTranExtn> GetAssetsForRevoke(List<InputParameters> ipGetAssetsForRevoke)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetAssetsForTranRevoke, CommandType.StoredProcedure, ipGetAssetsForRevoke).ConvertToAssetExtension();
            }
        }

        public bool UpdateForTransactionRevoke(List<InputParameters> ipGetAssetsForUpdate)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_UpdateForTransactionRevoke, CommandType.StoredProcedure, ipGetAssetsForUpdate);
            }
        }

        /// <summary>
        /// To fetch related assets on hpsmno & User from Assettran
        /// </summary>
        /// <param name="ipGetDetails">PSID</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetRelatedAssetsOnNewRequest(List<InputParameters> ipGetDetails)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetRelatedAssetsOnNewRequest, CommandType.StoredProcedure, ipGetDetails).ConvertToAssetExtension();
            }
        }

         /// <summary>
        /// To fetch User Feedback
        /// </summary>
        /// <param name="ipGetDetails"></param>
        /// <returns></returns>
        public DataSet GetUserRevertActionDetails()
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetUserRevertActionDetails, CommandType.StoredProcedure, null);
            }
        }



        /// <summary>
        /// To fetch User Feedback
        /// </summary>
        /// <param name="ipGetDetails"></param>
        /// <returns></returns>
        public DataSet UpdateUserRevertActionDetails(List<InputParameters> ipUserRevert)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_UpdateUserRevertActionDetails, CommandType.StoredProcedure, ipUserRevert);
            }
        }

        /// <summary>
        /// To fetch related assets on hpsmno & User from Assettran
        /// </summary>
        /// <param name="ipGetDetails">PSID</param>
        /// <returns>List of AssetTranExtn</returns>
        public List<AssetTranExtn> GetListOfAssetsForEndUser(List<InputParameters> ipGetDetails)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetListOfAssetsForEnduser, CommandType.StoredProcedure, ipGetDetails).ConvertToAssetExtension();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipuserid"></param>
        /// <returns></returns>
        public DataSet GetCancelDataList()
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetCancelAssetData, CommandType.StoredProcedure, null);
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipuserid"></param>
        /// <returns></returns>
        public bool CancelAssetRequest(List<InputParameters> ipCancelAsset)
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.ExecuteNonQuery(_CancelAssetRequest, CommandType.StoredProcedure, ipCancelAsset);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipuserid"></param>
        /// <returns></returns>
        public DataSet GetSysAssetTypeForDirect()
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetSysAssetTypeForDirect, CommandType.StoredProcedure, null);
            }
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipuserid"></param>
        /// <returns></returns>
        public DataSet GetWebGenieComparisionDetails()
        {
            using (var dbHelper = new AssetManagement.DBHelper())
            {
                return dbHelper.GetDataSet(_GetWebGenieComparisionDetails, CommandType.StoredProcedure, null);
            }
        }

        public List<MasterData> GetSysMasterData(List<InputParameters> ipGetDetails)
        {
            using (var dbHelper = new DBHelper())
            {
                return dbHelper.GetDataSet(_GetSysMasterData, CommandType.StoredProcedure, ipGetDetails).ConvertToMasterData();
            }
        }
     
        #endregion
    }
}

