﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary
{
   public class AMDefinitions
    {
        // PageURL ID
        public static int Sync_aspx = 1013;
        public static int Assignment_aspx = 1001;
        public static int UserRegistrationForm_aspx = 1006;
        public static int HardwareTypeList_aspx = 1002;
        public static int ItemInformation_aspx = 1003;
        public static int AddLocation_aspx = 1012;
        public static int ManufacturerList_aspx = 1005;
        public static int ViewLocation_aspx = 1004;
        public static int Search_aspx = 1007;
        public static int TechnologyList_aspx = 1008;
        public static int VendorList_aspx = 1009;
        public static int Reports_aspx = 1010;
        public static int AddAssetNumber_aspx = 1000;
        public static int GRNote_aspx = 1011;
        public static int AssetSearch_aspx = 1018;

        public static int ManageAccess_aspx = 2020;
        public static int HardwareTypeForm_aspx = 1014;
        public static int ManufacturerForm_aspx = 1015;
        public static int TechnologyForm_aspx = 1016;
        public static int VendorForm_aspx = 1017;


        public static string INVALIDADCREDENTIALS = "Invalid active directory credentials.";
        public static string NOSUFFICIENTPREVILAGES = "Do not have sufficient privileges.";
        public static string SUPERADMIN = "SuperAdmin";
        public static string USER = "User";
        public static string FINANCEADMIN = "FinanceAdmin";
        public static string REPORTADMIN = "ReportAdmin";

        public static string DECRYPTARGNULLEXEPTION = "The string which needs to be decrypted can not be null.";
        public static string ENCRYPTARGNULLEXEPTION = "The string which needs to be encrypted can not be null.";
        public static string UPDATEDSUCCESSFULLY = "Updated successfully.";
        public static string PLEASETYPETEXT = "Please type the text in asset search!";
        public static string LOGS = "Logs";
        public static string EXCEPTIONLOG = "ExceptionLog";

        //Home
        public static string USERROLEID = "1001";

        //AddAssetNumber
        public static string NORECORDINTHISASSETCLASS = "There are no records. Please select different Asset Class.";
        public static string ERRORINUPDATING = "Error in updating.";

        //AddLocation / ViewLocation        
        public static string NODATA = "-";
        public static string UNABLETOLOADLOCATININFORMATION = "Unable to load location information.";
        public static string UPDATEEXISTING = "Update Existing";
        public static string ADDUSINGEXISTING = "Add Using Existing";
        public static string YETTOASSIGN = "Yet to be assigned.";
        public static string LOCATIONADDED = "Location added successfully.";
        public static string LOCATIONUPDATED = "Location updated successfully.";
        public static string PLEASEPROVIDEAREANAME = "Please provide area name.";
        public static string PLEASEPROVIDEBLOCKNAME = "Please provide block name.";
        public static string PLEASEPROVIDECOMPANYNAME = "Please provide company name.";
        public static string PLEASEPROVIDELOCATIONNAME = "Please provide location name.";
        public static string PLEASEPROVIDELOCATIONADDRESS = "Please provide location address.";
        public static string LOCATIONALREADYEXISTS = "Sorry! This location detail already exist. Please provide some other name.";
        public static string ERRORADDINDLOCATION = "Error adding Location.";
        public static string NOTMODIFIEDLOCATION = "Sorry! You haven't changed any data to modify.";
        public static string ERRORUPDATINGLOCATION = "Error updating the location information.";

        //Reports
        public static string NORECORDS = "No record matches for this search.";
        public static string NORECORDSFOUND = "No records found";
        //GRNote
        public static string PONUMBEREXISTS = "Item with same PO Number already exists. Please enter different PO Number.";

        //Settings - TechnologyForm/List, ManufacturerForm/List, HardwareForm/List
        public static string TECHADDED = "Technology added successfully.";
        public static string VENDADDED = "Vendor added successfully.";
        public static string MANUDADDED = "Manufacturer added successfully.";
        public static string ITEMCLASSADDED = "Item class added successfully.";
        public static string TECHMODIFIED = "Technology modified successfully.";
        public static string VENDMODIFIED = "Vendor modified successfully.";
        public static string MANUMODIFIED = "Manufacturer modified successfully.";
        public static string ITEMCLASSMODIFIED = "Item class modified successfully.";
        public static string ITEMCLASSEXISTS = "Item Class with the same name already exists.";
        public static string TECHALREADYEXISTS = "Technology Type with the same name already exists.";
        public static string VENDORALREADYEXISTS = "Vendor with the same name already exists.";
        public static string PLEASESELECTRECORD = "Please select a record to be modified.";

        public static string MODIFIED = "Modified!";
        public static string NOTMODIFIED = "Not Modified";
        public static string NOTSAVED = "Not Saved";

        //MainForm
        public static string PASSWORDDOESNOTEXIST = "Password does not exist.";
        public static string USERDOESNOTEXIST = "User does not exist.";
        public static string LOCATIONDOESNOTEXIST = "Location does not exist.";

        //ManageAccess
        public static string ACCESSDETAILSUPDATED = "Access details updated successfully.";
        public static string SELECTROLE = "Please Select a Role.";
        public static string SELECTREADORWRITEACCESS = "Please Select the Read/Write Access for the Pages.";

        //Search
        public static string PLEASEENTERASSETNAME = "Please enter an asset name to search for...";
        public static string ASSETALREADYSELECTED = "This asset has already been selected! Please select a different one.";

        //UserRegistrationForm
        public static string STAR = "*";
        public static string NOTAVAILABLE = "Unavailable";
        public static string ERRORACCESSINGUSERDATA = "Error accessing user details from the database, please try again later.";
        public static string ERRORACCESSINGUSERDATAFROMAD = "Error loading the user data from AD, user name seems to be wrong.";
        public static string USERDOESNOTEXISTINAD = "This user name does not exist in the Active directory, please enter a valid user name!";
        public static string USERDATASAVED = "User data saved sucessfully.";
        public static string USERDATAUNSAVED = "User data could not be saved.";
        public static string USERDATAUPDATED = "User data modified sucessfully.";
        public static string USERDATANOTUPDATED = "User data could not be modified.";
        public static string PLEASETRYAGAIN = "Please try again.";

        //Assignment Page
        public static string NOUSERWITHTHISNAME = "Sorry, there is no user with this name. ";
        public static string NOASSETASSOCIATEDTOUSER = "No assets associated with this user, please click on Add/Edit Assets to select.";
        public static string NOASSIGNMENT = "You have no assignment attached, please contact Admin for details.";
        public static string NOASSETASSOCIATEDTOASSET = "No assets associated with this asset, please click on Add/Edit Assets to select.";
        public static string NOASSETWITHTHISNAME = "Sorry, there is no asset with this name ";
        public static string PLEASERETYPE = " , please retype the name & search again.";
        public static string NOASSETASSOCIATEDTOLOCATION = "No assets associated with this location, please click on Add/Edit Assets to select.";
        public static string PLEASEENTERVALUE = "Please enter a location name";
        public static string PLEASEENTERDESKVALUE = "Please enter Username/Desk No";
        public static string PLEASESELECTASSET = "Click on Add/Edit and select an asset to proceed.";
        public static string PERSONALIZEUSER = "Please personalize this user using the handheld and proceed.";
        public static string ASSIGNMENTSAVED = "Assignment has been saved successfully.";
        public static string ASSIGNMENTNOTSAVED = "Assignment has not been saved";
        public static string SELECTLOCTIONTYPE = "Select the location type.";
        public static string PLEASESELECTLOCATIONFORUSER = "Please select a location for the user.";
        public static string PLEASESELECTASSIGNMENTTOMODIFY = "Please select an assignemnt to modify, by providing a Location or an Asset.";
        public static string ATLEASETONEASSETNEEDSTOBEASSIGNED = "Atleast one asset has to be assigned! Click on Add/Edit Assets to select.";
        public static string PLEASESELECTLOCATION = "Please provide location to proceed...";
        public static string NOLOCATIONWITHTHISNAME = "Sorry, there is no desk/location with the name.";
        public static string LOADUSERASSIGNMENT = "LoadUserAssignment()";
        public static string LOADASSETASSIGNMENT = "LoadAssetAssignment()";
        public static string LOADLOCATIONASSIGNMENT = "LoadLocationAssignment()";

        //ItemInformation
        public static string ITEMNOTFOUND = "Item not found.";
        public static string NOQUOTATION = "No quotation for this item.";
        public static string NOACCESSORIES = "No accessories for this item.";
        public static string CAPTUREITEMINFO = "Item information is required to be captured before selecting any quotation.";
        public static string NOQUOTATIONADDED = "No new quotation added.";
        public static string QUOTATIONADDED = "Quotation added successfully.";
        public static string ERRORADDINGQUOTATION = "Error adding quotation.";
        public static string ITEMUPDATED = "Item updated successfully.";
        public static string ERRORUPDATINGITEM = "Error updating Item details.";
        public static string QUOTATIONVENDORALREADYADDED = "This quotation vendor has already been added.";
        public static string QUOTATIONUPDATED = "Quotation updated successfully.";
        public static string ERRORUPDATINGQUOTATION = "Error updating the Quotation.";
        public static string ERRORSORTINGQUOTATION = "Error while sorting the Quotations.";
        public static string ERRORDELETINGQUOTATION = "Error deleting the quotation.";
        public static string QUOTATIONDELETED = "Quotation deleted successfully.";
        public static string PURCHASEINFOUPDATED = "Purchase information updated successfully.";
        public static string ERRORUPDATINGPURCHASEINFO = "Error updating Purchase information.";
        public static string CAPTUREITEMINFOACCESSORY = "Item Information is required to be captured before selecting any Accessory.";
        public static string SAMEITEMCANNOTBEADDEDASACCESSORY = "Same item cannot be added as an accessory, please select other item.";
        public static string ACCESSORYADDED = "Accessory added successfully.";
        public static string ERRORADDINGACCESSORY = "Error adding accessory.";
        public static string ERRORSORTINGACCESSORIES = "Error while sorting the accessories.";
        public static string ERRORDELETINGACCESSORY = "Error deleting the accessory.";
        public static string ACCESSORYDELETED = "Accessory deleted successfully.";


        //Page List
        public static string HOME = "Home.aspx";
        public static string MANAGEACCESS = "ManageAccess.aspx";
        public static string MAINFORM = "MainForm.aspx";
        public static string REGISTRATION = "UserRegistrationForm.aspx";
        public static string VIEWLOCATIONS = "ViewLocations.aspx";
        public static string ADDLOCATIONS = "AddLocation.aspx";
        public static string SEARCH = "Search.aspx";
        public static string ASSETSEARCH = "AssetSearch.aspx";
        public static string ASSIGNMENT = "Assignment.aspx";
        public static string GRNOTE = "GRNote.aspx";
        public static string ADDASSETNUMBER = "AddAssetNumber.aspx";
        public static string IMPORTDATAFROMEXCEL = "ImportDataFromExcel.aspx";
        public static string ITEM = "ItemInformation.aspx";
        public static string SYNC = "Sync.aspx";
        public static string REPORT = "Reports.aspx";

        public static string HARDWARETYPELIST = "HardwareTypeList.aspx";
        public static string HARDWARETYPEFORM = "HardwareTypeForm.aspx";
        public static string MANUFACTURERLIST = "ManufacturerList.aspx";
        public static string MANUFACTURERFORM = "ManufacturerForm.aspx";
        public static string VENDORLIST = "VendorList.aspx";
        public static string VENDORFORM = "VendorForm.aspx";
        public static string TECHNOLOGYLIST = "TechnologyList.aspx";
        public static string TECHNOLOGYFORM = "TechnologyForm.aspx";
        public static string ASSETINFORMATIONREPORT = "AssetInformationReport.aspx";
        public static string DATABASEDTAGGINGREPORT = "DataBasedTaggingReport.aspx";
        public static string ITEMRELOCATIONREPORT = "ItemRelocationReport.aspx";
        public static string LOCATIONBASEDASSETREPORT = "LocationBasedAssetReport.aspx";
        public static string SMARTEYEREPORT = "SmartEyeReport.aspx";
        public static string TRACKINGREPORT = "TrackingReport.aspx";
        public static string INSERVICEDATEBASEDTAGGINGREPORT = "InServiceDateBasedTaggingReport.aspx";
        public static string GOODSRECEIVEDREPORT = "GoodsReceivedReport.aspx";
        public static string GRREPORT = "GRReport.aspx";

        //public static string MODIFY = "2";
        //public static string ADD = "1";
        //public static string EMPTY = "0";
        //public static string SUCCESS = "Success";
        //public static string Added = "Added!";
        //public static string SAVEDSUCESSFULLY = "Successfully Saved!"; 

    }
}
