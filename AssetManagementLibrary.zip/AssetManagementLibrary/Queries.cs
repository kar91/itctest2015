﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using I3L.Data;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Xml.Linq;
using System.Configuration;

namespace AssetManagementLibrary
{
    public class Queries
    {
        #region Variables
        SqlServer sqlServer;
        string query;
        string connectionString;

        List<ItemEntityClass> obj1 = new List<ItemEntityClass>();
        DataTable DT = new DataTable();
        DataSet ds = new DataSet();
        SqlCommand Sqlcmd = new SqlCommand();
        // string connectionString = System.Data.Common.GetConnectionString();


        #endregion

        #region Constructor
        public Queries()
        {
            #region Declaring Connection String
            connectionString = ConfigurationManager.ConnectionStrings["AvaluetConnectionString"].ConnectionString;
            sqlServer = new SqlServer(connectionString);
            query = "";
            #endregion
        }
        #endregion



        string m_stablename;
        public string TableName
        {
            get
            {
                return m_stablename;
            }
            set
            {
                m_stablename = value;
            }
        }

        /// <summary>
        /// CreatedBy By  : Sankar TN
        /// Modified Date : 2016      
        /// </summary>  

        #region Functions
        public DataTable GetLocations()
        {
            query = "Select LocationID,LocationName from Location";
            DataTable dtresult = sqlServer.ExecuteSel(connectionString, query, "Locaton", false);
            return dtresult;
        }

        public DataTable GetAssetType()
        {
            query = "SELECT [SysAssetTypeID],[AssetType] FROM [SysAssetType]";
            DataTable dtresult = sqlServer.ExecuteSel(connectionString, query, "AssetType", false);
            return dtresult;
        }

        public DataTable GetAssetStatus()
        {
            query = "SELECT [SysAssetStatusID],[AssetStatus] FROM [SysAssetStatus]";
            DataTable dtresult = sqlServer.ExecuteSel(connectionString, query, "AssetStatus", false);
            return dtresult;
        }

        public DataSet GetScanUser(int appid, string psid)
        {
            try
            {
                sqlServer = new SqlServer(connectionString);
                IDbCommand cmd = sqlServer.DefaultDBConnection.CreateCommand();

                cmd.CommandText = "[Usp_GetScanEngineers]";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlServer.DefaultDBConnection;



                IDbDataParameter sdt = cmd.CreateParameter();
                sdt.ParameterName = "@PSID";
                sdt.Value = psid;
                cmd.Parameters.Add(sdt);

                IDbDataParameter edt = cmd.CreateParameter();
                edt.ParameterName = "@ApplicationID";
                edt.Value = appid;
                cmd.Parameters.Add(edt);


                IDbDataParameter vdt = cmd.CreateParameter();
                vdt.ParameterName = "@AssetSearch";
                vdt.Value = 1;
                cmd.Parameters.Add(vdt);

                DataSet ds = sqlServer.ExecuteCmd(connectionString, cmd);

                if (sqlServer.DefaultDBConnection.State != ConnectionState.Closed)
                    sqlServer.DefaultDBConnection.Close();

                return ds;
            }
            catch (Exception ex)
            {
                return null;


            }
        }

        public bool InsertScanItem(string BuildingName, string AreaName, string CubicleStatus,
            string CubicleNumber, string PSID, string Name,
            string AssetType, string SerialNumber, string LocationName, string ModifiedBy, DateTime ScanDate)
        {
            #region Inserts a record into Item Table
            try
            {
                sqlServer = new SqlServer(connectionString);
                IDbCommand cmd = sqlServer.DefaultDBConnection.CreateCommand();

                cmd.CommandText = "spInsertScannedItem";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlServer.DefaultDBConnection;

                IDbDataParameter parbuildingname = cmd.CreateParameter();
                parbuildingname.ParameterName = "@BuildingName";
                parbuildingname.Value = BuildingName;
                cmd.Parameters.Add(parbuildingname);

                IDbDataParameter parAreaName = cmd.CreateParameter();
                parAreaName.ParameterName = "@AreaName";
                parAreaName.Value = AreaName;
                cmd.Parameters.Add(parAreaName);

                IDbDataParameter parCubicleStatus = cmd.CreateParameter();
                parCubicleStatus.ParameterName = "@CubicleStatus";
                parCubicleStatus.Value = CubicleStatus;
                cmd.Parameters.Add(parCubicleStatus);

                IDbDataParameter parCubicleNumber = cmd.CreateParameter();
                parCubicleNumber.ParameterName = "@CubicleNumber";
                parCubicleNumber.Value = CubicleNumber;
                cmd.Parameters.Add(parCubicleNumber);

                IDbDataParameter parPSID = cmd.CreateParameter();
                parPSID.ParameterName = "@PSID";
                parPSID.Value = PSID;
                cmd.Parameters.Add(parPSID);

                IDbDataParameter parName = cmd.CreateParameter();
                parName.ParameterName = "@Name";
                parName.Value = Name;
                cmd.Parameters.Add(parName);

                IDbDataParameter parAssetType = cmd.CreateParameter();
                parAssetType.ParameterName = "@AssetType";
                parAssetType.Value = AssetType;
                cmd.Parameters.Add(parAssetType);

                IDbDataParameter parSerialNumber = cmd.CreateParameter();
                parSerialNumber.ParameterName = "@SerialNumber";
                parSerialNumber.Value = SerialNumber;
                cmd.Parameters.Add(parSerialNumber);

                //IDbDataParameter parQRCodeNumber = cmd.CreateParameter();
                //parQRCodeNumber.ParameterName = "@QRCodeNumber";
                //parQRCodeNumber.Value = QRCodeNumber;
                //cmd.Parameters.Add(parQRCodeNumber);


                IDbDataParameter parLocationID = cmd.CreateParameter();
                parLocationID.ParameterName = "@LocationName";
                parLocationID.Value = LocationName;
                cmd.Parameters.Add(parLocationID);

                IDbDataParameter parModifiedBy = cmd.CreateParameter();
                parModifiedBy.ParameterName = "@ModifiedBy";
                parModifiedBy.Value = ModifiedBy;
                cmd.Parameters.Add(parModifiedBy);

                IDbDataParameter parScanDate = cmd.CreateParameter();
                parScanDate.ParameterName = "@ScanDate";
                parScanDate.Value = ScanDate;
                cmd.Parameters.Add(parScanDate);

                DataSet ds = sqlServer.ExecuteCmd(connectionString, cmd);

                if (ds != null)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
            finally
            {
                if (sqlServer.DefaultDBConnection != null)
                {
                    if (sqlServer.DefaultDBConnection.State != ConnectionState.Closed)
                        sqlServer.DefaultDBConnection.Close();
                }
            }
            #endregion
        }


        public DataSet LoadGrid(string loc = null, DateTime? st = null, DateTime? et = null, int userid = 0)
        {
            try
            {
                sqlServer = new SqlServer(connectionString);
                IDbCommand cmd = sqlServer.DefaultDBConnection.CreateCommand();

                cmd.CommandText = "[Usp_AssetTrackerSearch]";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlServer.DefaultDBConnection;

                IDbDataParameter parUserName = cmd.CreateParameter();
                parUserName.ParameterName = "@Name";
                parUserName.Value = loc;
                cmd.Parameters.Add(parUserName);

                IDbDataParameter sdt = cmd.CreateParameter();
                sdt.ParameterName = "@StartDate";
                sdt.Value = st;
                cmd.Parameters.Add(sdt);

                IDbDataParameter edt = cmd.CreateParameter();
                edt.ParameterName = "@EndDate";
                edt.Value = et;
                cmd.Parameters.Add(edt);

                IDbDataParameter uid = cmd.CreateParameter();
                uid.ParameterName = "@ScanUserID";
                uid.Value = userid;
                cmd.Parameters.Add(uid);


                DataSet ds = sqlServer.ExecuteCmd(connectionString, cmd);

                if (sqlServer.DefaultDBConnection.State != ConnectionState.Closed)
                    sqlServer.DefaultDBConnection.Close();

                return ds;
            }
            catch
            {
                return null;


            }


        }


        public DataSet LoadbuildingGrid(string psid)
        {
            try
            {
                sqlServer = new SqlServer(connectionString);
                IDbCommand cmd = sqlServer.DefaultDBConnection.CreateCommand();

                cmd.CommandText = "[USP_GetPVReport]";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlServer.DefaultDBConnection;
                IDbDataParameter uid = cmd.CreateParameter();
                uid.ParameterName = "@PSID";
                uid.Value = psid;
                cmd.Parameters.Add(uid);
                DataSet ds = sqlServer.ExecuteCmd(connectionString, cmd);

                if (sqlServer.DefaultDBConnection.State != ConnectionState.Closed)
                    sqlServer.DefaultDBConnection.Close();

                return ds;
            }
            catch
            {
                return null;


            }
        }

        public DataSet LoadReviewGrid(DateTime? st = null, DateTime? et = null, int userid = 0)
        {
            try
            {
                sqlServer = new SqlServer(connectionString);
                IDbCommand cmd = sqlServer.DefaultDBConnection.CreateCommand();

                cmd.CommandText = "[Usp_AssetDailyReview]";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlServer.DefaultDBConnection;



                IDbDataParameter sdt = cmd.CreateParameter();
                sdt.ParameterName = "@StartDate";
                sdt.Value = st;
                cmd.Parameters.Add(sdt);

                IDbDataParameter edt = cmd.CreateParameter();
                edt.ParameterName = "@EndDate";
                edt.Value = et;
                cmd.Parameters.Add(edt);

                IDbDataParameter uid = cmd.CreateParameter();
                uid.ParameterName = "@ScanUserID";
                uid.Value = userid;
                cmd.Parameters.Add(uid);


                DataSet ds = sqlServer.ExecuteCmd(connectionString, cmd);

                if (sqlServer.DefaultDBConnection.State != ConnectionState.Closed)
                    sqlServer.DefaultDBConnection.Close();

                return ds;
            }
            catch
            {
                return null;


            }


        }



        public DataTable GetUserName(string EMPLID)
        {
            #region User Details
            try
            {
                sqlServer = new SqlServer(connectionString);
                IDbCommand cmd = sqlServer.DefaultDBConnection.CreateCommand();
                cmd.CommandText = "[Usp_GetUserName]";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlServer.DefaultDBConnection;

                IDbDataParameter parUserID = cmd.CreateParameter();
                parUserID.ParameterName = "@EMPLID";
                parUserID.Value = EMPLID;
                cmd.Parameters.Add(parUserID);

                DataSet ds = sqlServer.ExecuteCmd(connectionString, cmd);

                if (sqlServer.DefaultDBConnection.State != ConnectionState.Closed)
                    sqlServer.DefaultDBConnection.Close();

                return ds.Tables[0];
            }
            catch
            {
                return null;
            }
            #endregion
        }

        public bool UpdateAsset(ItemEntityClass Item)
        {
            #region UpdateUser
            try
            {
                sqlServer = new SqlServer(connectionString);
                IDbCommand cmd = sqlServer.DefaultDBConnection.CreateCommand();

                cmd.CommandText = "spUpdateAssets";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlServer.DefaultDBConnection;

                IDbDataParameter parItemID = cmd.CreateParameter();
                parItemID.ParameterName = "@ItemID";
                parItemID.Value = Item.ItemID;
                cmd.Parameters.Add(parItemID);

                IDbDataParameter parLocationName = cmd.CreateParameter();
                parLocationName.ParameterName = "@LocationName";
                parLocationName.Value = Item.LocationName;
                cmd.Parameters.Add(parLocationName);

                IDbDataParameter parBuildingName = cmd.CreateParameter();
                parBuildingName.ParameterName = "@BuildingName";
                parBuildingName.Value = Item.BuildingName;
                cmd.Parameters.Add(parBuildingName);

                IDbDataParameter parAreaName = cmd.CreateParameter();
                parAreaName.ParameterName = "@FloorNo";
                parAreaName.Value = Item.AreaName;
                cmd.Parameters.Add(parAreaName);

                IDbDataParameter parCubicleNumber = cmd.CreateParameter();
                parCubicleNumber.ParameterName = "@CubicleNumber";
                parCubicleNumber.Value = Item.CubicleNumber;
                cmd.Parameters.Add(parCubicleNumber);

                IDbDataParameter parCubicleStatus = cmd.CreateParameter();
                parCubicleStatus.ParameterName = "@CubicleStatus";
                parCubicleStatus.Value = Item.CubicleStatus;
                cmd.Parameters.Add(parCubicleStatus);

                IDbDataParameter parPSID = cmd.CreateParameter();
                parPSID.ParameterName = "@PSID";
                parPSID.Value = Item.PSID;
                cmd.Parameters.Add(parPSID);


                IDbDataParameter parName = cmd.CreateParameter();
                parName.ParameterName = "@Name";
                parName.Value = Item.Name;
                cmd.Parameters.Add(parName);

                IDbDataParameter parAssetType = cmd.CreateParameter();
                parAssetType.ParameterName = "@AssetType";
                parAssetType.Value = Item.AssetType;
                cmd.Parameters.Add(parAssetType);

                IDbDataParameter parSerialNumber = cmd.CreateParameter();
                parSerialNumber.ParameterName = "@SerialNumber";
                parSerialNumber.Value = Item.SerialNumber;
                cmd.Parameters.Add(parSerialNumber);

                IDbDataParameter parQRCodeNumber = cmd.CreateParameter();
                parQRCodeNumber.ParameterName = "@QRCodeNumber";
                parQRCodeNumber.Value = Item.QRCodeNumber;
                cmd.Parameters.Add(parQRCodeNumber);

                IDbDataParameter parFARNumber = cmd.CreateParameter();
                parFARNumber.ParameterName = "@FARNumber";
                parFARNumber.Value = Item.FARNumber;
                cmd.Parameters.Add(parFARNumber);

                IDbDataParameter parModifiedBy = cmd.CreateParameter();
                parModifiedBy.ParameterName = "@ModifiedBy";
                parModifiedBy.Value = Item.ModifiedBy;
                cmd.Parameters.Add(parModifiedBy);

                IDbDataParameter parScanDate = cmd.CreateParameter();
                parScanDate.ParameterName = "@ScanDate";
                parScanDate.Value = Item.ScanDate;
                cmd.Parameters.Add(parScanDate);


                DataSet ds = sqlServer.ExecuteCmd(connectionString, cmd);

                if (sqlServer.DefaultDBConnection.State != ConnectionState.Closed)
                    sqlServer.DefaultDBConnection.Close();

                if (ds != null)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
            #endregion
        }

        public bool acknowledge(string PSID, string item, string type, string comments)
        {
            using (SqlConnection con = new SqlConnection(connectionString))

                try
                {
                    {
                        using (SqlCommand cmd = new SqlCommand("[dbo].[Usp_UserAcceptance]", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;


                            cmd.Parameters.Add("@PSID", SqlDbType.NVarChar).Value = PSID;
                            cmd.Parameters.Add("@ItemID", SqlDbType.NVarChar).Value = item;

                            cmd.Parameters.Add("@IsAcknowleged", SqlDbType.NVarChar).Value = type;
                            cmd.Parameters.Add("@Comments", SqlDbType.NVarChar).Value = comments;
                            con.Open();
                            cmd.ExecuteNonQuery();
                        }


                    }
                    return true;
                }

                catch (Exception ex)
                {
                    return false;
                }

                finally
                {
                    con.Close();
                }
        }

        public string searchupdate(string key, string cubestat, string psid, int asettypeid, int asetstatusid, string sernumb, string qrcode, string frnumb, string modby, int present, int cid = 1)
        {
           

                using (SqlConnection con = new SqlConnection(connectionString))
                     try
                         {
                    using (SqlCommand cmd = new SqlCommand("[dbo].[Usp_UpdateAssets]", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@AssetTrackerID", SqlDbType.Int).Value = key;
                        cmd.Parameters.Add("@CubicleStatus", SqlDbType.NVarChar).Value = cubestat;

                        cmd.Parameters.Add("@PSID", SqlDbType.NVarChar).Value = psid;
                        cmd.Parameters.Add("@AssetStatusID", SqlDbType.Int).Value = asetstatusid;
                        cmd.Parameters.Add("@AssetTypeID", SqlDbType.Int).Value = asettypeid;

                        cmd.Parameters.Add("@SerialNumber", SqlDbType.NVarChar).Value = sernumb;
                        cmd.Parameters.Add("@QRCode", SqlDbType.NVarChar).Value = qrcode;

                        cmd.Parameters.Add("@FARNumber", SqlDbType.NVarChar).Value = frnumb;
                        cmd.Parameters.Add("@Present", SqlDbType.Int).Value = present;
                        cmd.Parameters.Add("@ModifiedBy", SqlDbType.NVarChar).Value = modby;
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }

                         return "Successfully Updated";
                }

               
            catch (SqlException err)
            {
                string error = GetErrorMessage(err.Message);
                return error;
            }
            catch (Exception ex)
            {
                return "Error";
            }
            finally
            {
                con.Close();
            }
        }
        public string UpdateReviewDetails(int AssetID, string PSID)
        {
           
                using (SqlConnection con = new SqlConnection(connectionString))
                 try
            {
                    using (SqlCommand cmd = new SqlCommand("[dbo].[Usp_InsertReviewDetails]", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@AssetID", SqlDbType.Int).Value = AssetID;
                        cmd.Parameters.Add("@PSID", SqlDbType.NVarChar).Value = PSID;
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                     return "Successfully Updated";
                }
                
           
            catch (SqlException err)
            {
                string error = GetErrorMessage(err.Message);
                return error;
            }
            catch (Exception ex)
            {
                return "Error";
            }
            finally
            {
                con.Close();
            }
        }
        public DataSet LoadAssetMovmentGrid(string Psid)
        {
            try
            {
                sqlServer = new SqlServer(connectionString);
                IDbCommand cmd = sqlServer.DefaultDBConnection.CreateCommand();
                cmd.CommandText = "spGetAssetSerialNumbers";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlServer.DefaultDBConnection;

                IDbDataParameter parUserID = cmd.CreateParameter();
                parUserID.ParameterName = "@Psid";
                parUserID.Value = Psid;
                cmd.Parameters.Add(parUserID);

                DataSet ds = sqlServer.ExecuteCmd(connectionString, cmd);

                if (sqlServer.DefaultDBConnection.State != ConnectionState.Closed)
                    sqlServer.DefaultDBConnection.Close();

                return ds;
            }
            catch
            {
                return null;
            }
        }

        public DataSet AssetMovementGridLoad(string LocationName, string BuildingName, String AreaName, String CubicleNumber)
        {
            try
            {
                sqlServer = new SqlServer(connectionString);
                IDbCommand cmd = sqlServer.DefaultDBConnection.CreateCommand();
                cmd.CommandText = "spGetMovementAssets";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlServer.DefaultDBConnection;

                IDbDataParameter parLocationName = cmd.CreateParameter();
                parLocationName.ParameterName = "@LocationName";
                parLocationName.Value = LocationName;
                cmd.Parameters.Add(parLocationName);

                IDbDataParameter parBuildingName = cmd.CreateParameter();
                parBuildingName.ParameterName = "@BuildingName";
                parBuildingName.Value = BuildingName;
                cmd.Parameters.Add(parBuildingName);


                IDbDataParameter parAreaName = cmd.CreateParameter();
                parAreaName.ParameterName = "@AreaName";
                parAreaName.Value = AreaName;
                cmd.Parameters.Add(parAreaName);

                IDbDataParameter parCubicleNumber = cmd.CreateParameter();
                parCubicleNumber.ParameterName = "@CubicleNumber";
                parCubicleNumber.Value = CubicleNumber;
                cmd.Parameters.Add(parCubicleNumber);

                DataSet ds = sqlServer.ExecuteCmd(connectionString, cmd);

                if (sqlServer.DefaultDBConnection.State != ConnectionState.Closed)
                    sqlServer.DefaultDBConnection.Close();

                return ds;
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetBlockBasedOnLocation(int LocationID, string PSID)
        {
            try
            {
                sqlServer = new SqlServer(connectionString);
                IDbCommand cmd = sqlServer.DefaultDBConnection.CreateCommand();
                cmd.CommandText = "Usp_GetBuildingDetails";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlServer.DefaultDBConnection;

                IDbDataParameter parUserID = cmd.CreateParameter();
                parUserID.ParameterName = "@LocationID";
                parUserID.Value = LocationID;
                cmd.Parameters.Add(parUserID);

                IDbDataParameter parPSID = cmd.CreateParameter();
                parPSID.ParameterName = "@PSID";
                parPSID.Value = PSID;
                cmd.Parameters.Add(parPSID);

                IDbDataParameter parAppID = cmd.CreateParameter();
                parAppID.ParameterName = "@ApplicationID";
                parAppID.Value = Convert.ToInt16(System.Configuration.ConfigurationManager.AppSettings["ApplicationID"]);
                cmd.Parameters.Add(parAppID);

                DataSet ds = sqlServer.ExecuteCmd(connectionString, cmd);

                if (sqlServer.DefaultDBConnection.State != ConnectionState.Closed)
                    sqlServer.DefaultDBConnection.Close();

                return ds.Tables[0];
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetAreaBasedOnBlock(int BuildingID, string PSID)
        {
            try
            {
                sqlServer = new SqlServer(connectionString);
                IDbCommand cmd = sqlServer.DefaultDBConnection.CreateCommand();
                cmd.CommandText = "Usp_GetAreaDetails";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlServer.DefaultDBConnection;

                IDbDataParameter parBlockID = cmd.CreateParameter();
                parBlockID.ParameterName = "@BuildingID";
                parBlockID.Value = BuildingID;
                cmd.Parameters.Add(parBlockID);

                IDbDataParameter parPSID = cmd.CreateParameter();
                parPSID.ParameterName = "@PSID";
                parPSID.Value = PSID;
                cmd.Parameters.Add(parPSID);

                IDbDataParameter parAppID = cmd.CreateParameter();
                parAppID.ParameterName = "@ApplicationID";
                parAppID.Value = Convert.ToInt16(System.Configuration.ConfigurationManager.AppSettings["ApplicationID"]);
                cmd.Parameters.Add(parAppID);

                DataSet ds = sqlServer.ExecuteCmd(connectionString, cmd);

                if (sqlServer.DefaultDBConnection.State != ConnectionState.Closed)
                    sqlServer.DefaultDBConnection.Close();

                return ds.Tables[0];
            }
            catch
            {
                return null;
            }

        }


        public DataTable getDatatoAcknowledge(String PSID)
        {
            try
            {
                sqlServer = new SqlServer(connectionString);
                IDbCommand cmd = sqlServer.DefaultDBConnection.CreateCommand();
                cmd.CommandText = "Usp_AssetsUSerAcceptance";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlServer.DefaultDBConnection;

                IDbDataParameter parAreaID = cmd.CreateParameter();
                parAreaID.ParameterName = "@PSID";
                parAreaID.Value = PSID;
                cmd.Parameters.Add(parAreaID);

                DataSet ds = sqlServer.ExecuteCmd(connectionString, cmd);

                if (sqlServer.DefaultDBConnection.State != ConnectionState.Closed)
                    sqlServer.DefaultDBConnection.Close();

                return ds.Tables[0];
            }
            catch
            {
                return null;
            }

        }

        public DataTable GetCubicleBasedOnArea(int BuildingFloorID)
        {
            try
            {
                sqlServer = new SqlServer(connectionString);
                IDbCommand cmd = sqlServer.DefaultDBConnection.CreateCommand();
                cmd.CommandText = "Usp_GetCubicleNumbers";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlServer.DefaultDBConnection;

                IDbDataParameter parAreaID = cmd.CreateParameter();
                parAreaID.ParameterName = "@BuildingFloorID";
                parAreaID.Value = BuildingFloorID;
                cmd.Parameters.Add(parAreaID);

                DataSet ds = sqlServer.ExecuteCmd(connectionString, cmd);

                if (sqlServer.DefaultDBConnection.State != ConnectionState.Closed)
                    sqlServer.DefaultDBConnection.Close();

                return ds.Tables[0];
            }
            catch
            {
                return null;
            }

        }

        //For Checking User Access
        public DataSet Getcredentials(string UserID, Int16 ApplicationID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string Param = "'" + UserID + "'" + ',' + ApplicationID;
                SqlDataAdapter sda = new SqlDataAdapter("Exec GS_GetLoggedInUserInfo " + Param, connection);
                sda.Fill(ds);
                connection.Close();

            }
            return ds;
        }


        public int GetSerialNumber(string SerialNumber)
        {
            SqlConnection con1 = new SqlConnection(connectionString);
            using (SqlCommand sqlCommand = new SqlCommand("select count(1) from AssetTracker WHERE SerialNumber = @SerialNumber", con1))
            {
                con1.Open();
                sqlCommand.Parameters.AddWithValue("@SerialNumber", SerialNumber);
                int userCount = (int)sqlCommand.ExecuteScalar();
                con1.Close();
                return userCount;
            }

        }


        public DataTable GetPSID(string CubicleID)
        {
            #region User Details
            try
            {
                sqlServer = new SqlServer(connectionString);
                IDbCommand cmd = sqlServer.DefaultDBConnection.CreateCommand();
                cmd.CommandText = "[Usp_GetEmployeeDetails]";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlServer.DefaultDBConnection;

                IDbDataParameter parUserID = cmd.CreateParameter();
                parUserID.ParameterName = "@CubicleID";
                parUserID.Value = CubicleID;
                cmd.Parameters.Add(parUserID);

                DataSet ds = sqlServer.ExecuteCmd(connectionString, cmd);

                if (sqlServer.DefaultDBConnection.State != ConnectionState.Closed)
                    sqlServer.DefaultDBConnection.Close();

                return ds.Tables[0];
            }
            catch
            {
                return null;
            }
            #endregion
        }

        public Boolean reviewreviewpageasset(string id, string modid, int Appid)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
                try
                {


                    {
                        connection.Open();
                        SqlCommand Sqlcmd = new SqlCommand("[Usp_UpdateAssetDailyReview]", connection);
                        Sqlcmd.Connection = connection;
                        Sqlcmd.Parameters.AddWithValue("@SysAssetDailyReviewID ", id);


                        Sqlcmd.Parameters.AddWithValue("@ReviewedBy ", modid);
                        Sqlcmd.Parameters.AddWithValue("@ApplicationID ", Appid);


                        Sqlcmd.CommandType = CommandType.StoredProcedure;
                        Sqlcmd.ExecuteNonQuery();
                    }
                    return true;
                }

                catch (Exception ex)
                {
                    return false;
                }
                finally
                {
                    connection.Close();
                }
        }
        public Boolean InsertAsset(string SerialNumber, string QRCodeNumber, string FARNumber, int AssetType, int AssetStatus, int BuildingNameid, int FloorNoid, int LocationNameid, string CubicleStatus, string CubicleNumber, string PSID, string Name, string ModifiedBy, int presence)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))

                try
                {
                    {
                        connection.Open();
                        SqlCommand Sqlcmd = new SqlCommand("[Usp_InsertAsset]", connection);
                        Sqlcmd.Connection = connection;
                        Sqlcmd.Parameters.AddWithValue("@SearialNumber", SerialNumber);
                        Sqlcmd.Parameters.AddWithValue("@QRCodeNumber", QRCodeNumber);
                        Sqlcmd.Parameters.AddWithValue("@FARNumber", FARNumber);
                        Sqlcmd.Parameters.AddWithValue("@AssetTypeID", AssetType);
                        Sqlcmd.Parameters.AddWithValue("@AssetStatusID", AssetStatus);
                        Sqlcmd.Parameters.AddWithValue("@BuildingID", BuildingNameid);
                        Sqlcmd.Parameters.AddWithValue("@FloorID", FloorNoid);
                        Sqlcmd.Parameters.AddWithValue("@LocationID", LocationNameid);
                        Sqlcmd.Parameters.AddWithValue("@CubicleStatus", CubicleStatus);
                        Sqlcmd.Parameters.AddWithValue("@CubicleNumber", CubicleNumber);
                        Sqlcmd.Parameters.AddWithValue("@PSID", PSID);
                        Sqlcmd.Parameters.AddWithValue("@Name", Name);
                        Sqlcmd.Parameters.AddWithValue("@Modby", ModifiedBy);
                        Sqlcmd.Parameters.AddWithValue("@UserPresence", presence);

                        Sqlcmd.CommandType = CommandType.StoredProcedure;
                        Sqlcmd.ExecuteNonQuery();
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }
                finally
                {
                    connection.Close();
                }
        }
        public string GetErrorMessage(string errMsg)
        {
            string error = "";

            string[] words = errMsg.Split(',');
            foreach (string word in words)
            {
                if (word.Contains("Error"))
                {
                    error = word;
                    break;
                }
                else
                { continue; }
            }
            return error;
        }


        #endregion
    }
}
