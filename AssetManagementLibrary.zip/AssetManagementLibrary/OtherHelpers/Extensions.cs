﻿using AssetManagementLibrary.Entities;
using AssetManagementLibrary.Entities.Movement;
using AssetManagementLibrary.Entities.Movement.Menu;
using AssetManagementLibrary.Entities.Movement.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.OtherHelpers
{
    public static class Extensions
    {
        /// <summary>
        /// Convert passed list to User Profile object
        /// </summary>
        /// <param name="sources"></param>
        /// <returns></returns>
        public static UserProfile ConvertToUserProfile(this List<UserProfileDetail> sources)
        {
            List<UserProfile> usrProfiles = new List<UserProfile>();
            sources.ForEach(s =>
            {
                var usrProfile = usrProfiles.Where(u => u.PSID == s.PSID).FirstOrDefault();
                if (usrProfile != null)
                {
                    if (!usrProfile.UserGroups.Any(u => u.GroupID == s.AcessGroupID))
                        usrProfile.UserGroups.Add(new UserGroup { GroupName = s.AccessGroupName, GroupID = s.AcessGroupID });
                }
                else
                {
                    var usrgrp = new UserGroup { GroupID = s.AcessGroupID, GroupName = s.AccessGroupName };
                    usrProfiles.Add(new UserProfile { PSID = s.PSID, FloorID = s.FloorID, Location = s.Location,Worklocation=s.Worklocation,  IsGaurd = s.IsGaurd, Name = s.Name, UserGroups = new List<UserGroup> { usrgrp } });
                }

            });
            return usrProfiles.FirstOrDefault();
        }


        /// <summary>
        /// Convert to disctionary of default location
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static Dictionary<int, DefaultLocation> ConvertToDefualtLocations(this DataSet source)
        {
            var dictionaryDfltLocations = new Dictionary<int, DefaultLocation>();

            foreach (DataRow row in source.Tables[0].Rows)
            {
                dictionaryDfltLocations.Add((int)row["SysPurposeID"], new DefaultLocation() { SysPurposeID = (int)row["SysPurposeID"], FromLocationID = (int?)row["FromLocationID"], FromBuildingID = (int?)row["FromBuildingID"], FromFloorID = (int?)row["FromFloorID"], FromPSID = row["FromPSID"].ToString(), ToLocationID = (int?)row["ToLocationID"], ToBuildingID = (int?)row["ToBuildingID"], ToFloorID = (int?)row["ToFloorID"], ToPSID = row["ToPSID"].ToString() });
            }
            return dictionaryDfltLocations;
        }

        /// <summary>
        /// To convert dataset into dictionary of menu items
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static List<MenuAccessGroup> ConvertToMenu(this DataSet source)
        {
            var menu_access_grp_lst = new List<MenuAccessGroup>();

            foreach (DataRow row in source.Tables[0].Rows)
            {

                if (menu_access_grp_lst.Any(mag => mag.AccessGroupID == (int)row["AccessGroupID"]))
                {
                    if (menu_access_grp_lst.Where(mag => mag.AccessGroupID == (int)row["AccessGroupID"]).Any(ma => ma.MenuGroup.Any(m => m.MenuGroupID == (int)row["MenuGroupID"])))
                    {
                        menu_access_grp_lst.Where(mag => mag.AccessGroupID == (int)row["AccessGroupID"]).First().MenuGroup.Where(mg => mg.MenuGroupID == (int)row["MenuGroupID"]).First().Menu.Add(new Menu
                        {
                            MenuID = (int)row["MenuID"],
                            Menu_Desc = row["Menu_Desc"].ToString(),
                            Url = row["Url"].ToString(),
                            ImgUrl = row["ImgUrl"].ToString(),
                            Name = row["Name"].ToString(),
                            Background_Color = row["Background_Color"].ToString()
                        });
                    }
                    else
                    {
                        menu_access_grp_lst.Where(mag => mag.AccessGroupID == (int)row["AccessGroupID"]).First().MenuGroup.Add(new MenuGroup
                        {
                            MenuGroupID = (int)row["MenuGroupID"],
                            Name = row["MenuGrpName"].ToString(),
                            Menu = new List<Menu> { 
                            new Menu {
                                    MenuID = (int)row["MenuID"],
                                    Menu_Desc = row["Menu_Desc"].ToString(),
                                    Url = row["Url"].ToString(),
                                    ImgUrl = row["ImgUrl"].ToString(),
                                    Name = row["Name"].ToString(),
                                    Background_Color = row["Background_Color"].ToString()
                                }
                            }
                        });
                    }
                }
                else
                {
                    menu_access_grp_lst.Add(new MenuAccessGroup
                    {
                        AccessGroupID = (int)row["AccessGroupID"],
                        MenuGroup = new List<MenuGroup> { 
                            new MenuGroup(){
                                MenuGroupID = (int)row["MenuGroupID"],
                                Name = row["MenuGrpName"].ToString(),
                                Menu = new List<Menu> {
                                    new Menu {
                                        MenuID = (int)row["MenuID"],
                                        Name = row["Name"].ToString(),
                                        Menu_Desc = row["Menu_Desc"].ToString(),
                                        Url = row["Url"].ToString(),
                                        ImgUrl = row["ImgUrl"].ToString(),
                                        Background_Color = row["Background_Color"].ToString()
                                    }
                                }
                            }
                        }
                    });
                }
            }
            return menu_access_grp_lst;
        }

        /// <summary>
        /// To convert into AssetTranExtn entity type
        /// </summary>
        /// <param name="source">DataSet</param>
        /// <returns>List of AssetTranExtn</returns>
        public static List<AssetTranExtn> ConvertToAssetExtension(this DataSet source)
        {
            if (source != null)
                return source.Tables[0].AsEnumerable().Select(s => GetAssetExtenstion(s)).ToList();
            else
                return null;
        }

        public static List<MasterData> ConvertToMasterData(this DataSet source)
        {
                var mstData = new List<MasterData>();
            if (source != null)
            {
                int count = 0;
                foreach (DataRow dr in source.Tables[0].Rows)
                {
                    if (count == 0)
                        mstData.Add(new MasterData { Name = dr.GetValue<string>("Name"), KeyName = "", Value = 0 });
                    
                        mstData.Add(new MasterData { Name = dr.GetValue<string>("Name"), KeyName = dr.GetValue<string>("KeyName"), Value = dr.GetValue<int>("VALUE") });
                    count++;
                }
                return mstData;
            }
            else
                return null;
        }

        /// <summary>
        /// Gets all the asset status list
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static Dictionary<int, string> ConvertAssetStatus(this DataSet source)
        {
            var assetStatusList = new Dictionary<int, string>();
            var result = source.Tables[0].AsEnumerable();
            foreach (var element in result)
            {
                assetStatusList.Add(Convert.ToInt32(element["SysAssetStatusID"]), element["AssetStatus"].ToString());
            }

            return assetStatusList;
        }


        /// <summary>
        /// To convert into AssetTranExtn entity type
        /// </summary>
        /// <param name="source">DataSet</param>
        /// <returns>List of AssetTranExtn</returns>
        public static List<Form> ConvertToForm(this DataSet source)
        {
            return source.Tables[0].AsEnumerable().Select(s => GetFormData(s)).ToList();
        }



        /// <summary>
        /// Returns Form entity object
        /// </summary>
        /// <param name="dr">DataRow</param>
        /// <returns>Form entity object</returns>
        private static Form GetFormData(DataRow dr)
        {
            return new Form
            {
                Creator = new Creator { Name = dr.GetValue<string>("ReqName"), PSID = dr.GetValue<string>("ReqPSID"), Date = dr.GetValue<DateTime>("CreatedOn") },
                Header = new Header { Date = dr.GetValue<DateTime>("Date").Date.ToString("dd/MM/yyyy"), FormNO = dr.GetValue<string>("FormNo"), Location = dr.GetValue<string>("Location"), Purpose = dr.GetValue<string>("Purpose"), Remarks = dr.GetValue<string>("Remarks"), TicketNo = dr.GetValue<string>("TicketNo"), HpsmNo = dr.GetValue<string>("HpsmNo"), IsReplacement = dr.GetValue<string>("IsReplacement") },
                Owners = new List<Owner> { new Owner { BuildingName = dr.GetValue<string>("BuildingName"), ContactNo = dr.GetValue<string>("ContactNo"), CubicleNo = dr.GetValue<string>("CubicleNo"), Department = dr.GetValue<string>("Dept"), Floor = dr.GetValue<string>("Floor"), Name = dr.GetValue<string>("Name"), PSID = dr.GetValue<string>("PSID") } },
                Assets = new List<AssetDetails> { new AssetDetails { AssetType = dr.GetValue<string>("Type"), FAR = dr.GetValue<string>("FARNumber"), Make = dr.GetValue<string>("Make"), Model = dr.GetValue<string>("Model"), SerialNumber = dr.GetValue<string>("SerialNumber") } },
                From = new Movement { Psid = dr.GetValue<string>("FromPsid"), Name = dr.GetValue<string>("FromName"), BuildingName = dr.GetValue<string>("FromBuilding"), Cubicle = dr.GetValue<string>("FromCubicle"), Floor = dr.GetValue<string>("FromArea") },
                To = new Movement { Psid = dr.GetValue<string>("ToPsid"), Name = dr.GetValue<string>("ToName"), BuildingName = dr.GetValue<string>("ToBuilding"), Cubicle = dr.GetValue<string>("ToCubicle"), Floor = dr.GetValue<string>("ToArea") }
            };
        }


        /// <summary>
        /// To merge assets in form data
        /// </summary>
        /// <param name="src">List of Form</param>
        /// <returns>List of Form</returns>
        public static List<Form> MergeAssets(List<Form> src)
        {
            List<Form> formlst = new List<Form>();

            var grpForms = src.GroupBy(g => g.Header.HpsmNo);
            foreach (var item in grpForms)
            {
                Form firstform = null;
                foreach (Form form in item)
                {
                    if (firstform == null)
                        firstform = form;
                    else
                        firstform.Assets.AddRange(form.Assets);
                }
                formlst.Add(firstform);
            }
            return formlst;

        }

        /// <summary>
        /// convert passed string to nullable int
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static int? ToNullableInt(string s)
        {
            int i;
            if (int.TryParse(s, out i)) return i;
            return null;
        }

        /// <summary>
        /// To remove duplicates in NextStage when multiple actions are available
        /// </summary>
        /// <param name="src">List of AssetTranExtn</param>
        /// <returns>List of AssetTranExtn</returns>
        public static List<AssetTranExtn> RemoveDuplicates(List<AssetTranExtn> src)
        {
            List<AssetTranExtn> assetTranExtnlst = new List<AssetTranExtn>();
            foreach (AssetTranExtn asset in src)
            {
                var assetTransExtn = assetTranExtnlst.Where(a => a.AssetTranId == asset.AssetTranId).FirstOrDefault();
                if (assetTransExtn != null)
                {
                    if (assetTransExtn.NextStages.Any(a => a.PurposeStageID != asset.NextStage.PurposeStageID))
                    {
                        assetTransExtn.NextStages.Add(asset.NextStage);
                    }
                }
                else
                {
                    var CurrentStatusGrp = asset.CurrentStage;
                    assetTranExtnlst.Add(new AssetTranExtn
                    {
                        AssetTranId = asset.AssetTranId,
                        CurrentStage = CurrentStatusGrp,
                        NextStages = new List<PurposeStage> { asset.NextStage },
                        AssetType = asset.AssetType,
                        SerialNo = asset.SerialNo,
                        QRCode = asset.QRCode,
                        FromBuilding = asset.FromBuilding,
                        FromArea = asset.FromArea,
                        ToFloorId = asset.ToFloorId,
                        ToFloor = asset.ToFloor,
                        ToCubicleId = asset.ToCubicleId,
                        FromCubicleNo = asset.FromCubicleNo,
                        NextStatus = asset.NextStatus,
                        Comments = asset.Comments,
                        ToBuilding = asset.ToBuilding,
                        ToArea = asset.ToArea,
                        ToCubicleNo = asset.ToCubicleNo,
                        HpsmNo = asset.HpsmNo,
                        FARNumber = asset.FARNumber,
                        AssetCategory = asset.AssetCategory,
                        FromLocation = asset.FromLocation,
                        ToLocation = asset.ToLocation,
                        MovementEnggId = asset.MovementEnggId,
                        FromName = asset.FromName,
                        FromPsid = asset.FromPsid,
                        ToPsid = asset.ToPsid,
                        PurposeName = asset.PurposeName,
                        ToName = asset.ToName,
                        CreatedByName = asset.CreatedByName,
                        AssetStatus = asset.AssetStatus,
                        Psid = asset.Psid,
                        CreatedByPsid = asset.CreatedByPsid,
                        Tier1EnggId = asset.Tier1EnggId,
                        FromFloorId = asset.FromFloorId,
                        FromCubicleId = asset.FromCubicleId,
                        SysPurposeId = asset.SysPurposeId,
                        CurrentStatus = asset.CurrentStatus,
                        ModBy = asset.ModBy,
                        ModDt = asset.ModDt,
                        AssetMake = asset.AssetMake,
                        AssetModel  =  asset.AssetModel,
                        FromBuildingEnggId = asset.FromBuildingEnggId,
                        ReasonID = asset.ReasonID,
                        CreatedOn = asset.CreatedOn,
                        IsBlocked = asset.IsBlocked,
                        DateConfigured = asset.DateConfigured,
                        IsInTransit = asset.IsInTransit,
                        ToBuildingEnggId = asset.ToBuildingEnggId,
                        ToEmailID = asset.ToEmailID,
                        IsEndUserAcknowledged = asset.IsEndUserAcknowledged,
                        EndUserId = asset.EndUserId,
                        IsReplacement = asset.IsReplacement,
                        ReplacementDate = asset.ReplacementDate,
                        RejectType = asset.RejectType,
                        AssetCount = asset.AssetCount,
                        StatusName=asset.StatusName,
                        CategoryName=asset.CategoryName,
                        IsApproverReq=asset.IsApproverReq,
                        Approvers=asset.Approvers,
                       IsDirectDeploy=asset.IsDirectDeploy
                    });
                }
            }

            return assetTranExtnlst;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T1"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <param name="source"></param>
        /// <param name="index0"></param>
        /// <param name="index1"></param>
        /// <returns></returns>
        public static Dictionary<T1, T2> ConvertToDictionary<T1, T2>(this DataSet source, int index0 = 0, int index1 = 1)
        {
            var dictionary = new Dictionary<T1, T2>();
            foreach (DataRow row in source.Tables[0].Rows)
            {
                dictionary.Add((T1)row[index0], (T2)row[index1]);
            }
            return dictionary;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TKey"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="dictionary"></param>
        /// <param name="key"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static TValue GetValueOrDefault<TKey, TValue>(this IDictionary<TKey, TValue> dictionary, TKey key, TValue defaultValue)
        {
            TValue value;
            return dictionary.TryGetValue(key, out value) ? value : defaultValue;
        }

        /// <summary>
        /// Returns AssetTranExtn entity object
        /// </summary>
        /// <param name="dr">DataRow</param>
        /// <returns>AssetTranExtn entity object</returns>
        private static AssetTranExtn GetAssetExtenstion(DataRow dr)
        {
            return new AssetTranExtn
            {
                AssetTranId = dr.GetValue<int>("AssetTranID"),
                AssetId = dr.GetValue<int>("AssetId"),
                AssetType = dr.GetValue<string>("AssetType"),
                HpsmNo = dr.GetValue<string>("HPSMNo"),
                SerialNo = dr.GetValue<string>("SerialNo"),
                QRCode = dr.GetValue<string>("QRCode"),
                FromLocation = dr.GetValue<string>("FromLocation"),
                FromBuilding = dr.GetValue<string>("FromBuilding"),
                FromBuildingId = dr.GetValue<int?>("FromBuildingID"),
                FromArea = dr.GetValue<string>("FromArea"),
                FromName = dr.GetValue<string>("FromName"),
                FromCubicleNo = dr.GetValue<string>("FromCubicleNo"),
                FromCubicleId = dr.GetValue<int?>("FromCubicleId"),
                FromPsid = dr.GetValue<string>("FromPsid"),
                ToLocation = dr.GetValue<string>("ToLocation"),
                ToBuilding = dr.GetValue<string>("ToBuilding"),
                ToBuildingId = dr.GetValue<int?>("ToBuildingId"),
                ToArea = dr.GetValue<string>("ToArea"),
                ToCubicleNo = dr.GetValue<string>("ToCubicleNo"),
                ToCubicleId = dr.GetValue<int?>("ToCubicleId"),
                ToFloorId = dr.GetValue<int?>("ToFloorId"),
                ToPsid = dr.GetValue<string>("ToPsid"),
                FARNumber = dr.GetValue<string>("FARNumber"),
                MovementEnggId = dr.GetValue<string>("MovementEnggID"),
                PurposeName = dr.GetValue<string>("PurposeName"),
                ToName = dr.GetValue<string>("ToName"),
                Psid = dr.GetValue<string>("Psid"),
                CreatedByPsid = dr.GetValue<string>("CreatedByPsid"),
                FromFloorId = dr.GetValue<int>("FromFloorId"),
                AssetCategory = dr.GetValue<string>("AssetCategory"),
                SysPurposeId = dr.GetValue<int>("SysPurposeId"),
                CreatedByName = dr.GetValue<string>("CreatedByName"),
                FromFloor = dr.GetValue<string>("FromFloor"),
                AssetModel = dr.GetValue<string>("AssetModel"),
                AssetMake = dr.GetValue<string>("AssetMake"),
                ToFloor = dr.GetValue<string>("ToFloor"),
                AssetStatus = dr.GetValue<string>("AssetStatus"),
                IsBlocked = dr.GetValue<int>("IsBlocked"),
                CurrentStatus = dr.GetValue<string>("CurrentStatus"),
                NextStatus = dr.GetValue<string>("NextStatus"),
                OverSeer = dr.GetValue<string>("OverSeer"),
                Tier1EnggId = dr.GetValue<string>("Tier1EnggId"),
                Comments = dr.GetValue<string>("Comments"),
                ModBy = dr.GetValue<string>("ModBy"),
                ModDt = dr.GetValue<System.DateTime?>("ModDt"),
                CreatedOn = dr.GetValue<System.DateTime?>("CreatedOn"),
                DateConfigured = dr.GetValue<System.DateTime?>("DateConfigured"),
                FromBuildingEnggId = dr.GetValue<string>("FromBuildingEngineerId"),
                ToBuildingEnggId = dr.GetValue<string>("ToBuildingEngineerId"),
                FromEngineer = dr.GetValue<string>("FromEngineer"),
                ToEngineer = dr.GetValue<string>("ToEngineer"),
                ReasonID = dr.GetValue<int?>("ReasonID"),
                IsReplacement = dr.GetValue<bool>("IsReplacement"),
                ReplacementDate = dr.GetValue<string>("ReplacementDate"),
                IsInTransit = dr.GetValue<bool>("IsInTransit"),
                AssetCount = dr.GetValue<int>("AssetCount"),
                EndUserId = dr.GetValue<string>("EndUserId"),
                EndUserName = dr.GetValue<string>("EndUserName"),
                RejectType = dr.GetValue<string>("RejectType"),
                SysPurposeStageId = dr.GetValue<int?>("SysPurposeStageId"),
                ToEmailID = dr.GetValue<string>("ToEmailID"),
                IsEndUserAcknowledged = dr.GetValue<bool?>("IsEndUserAcknowledged"),
                CurrentStage = new PurposeStage { PurposeStageID = dr.GetValue<int>("CurrentStatusID"), PurposeStageName = dr.GetValue<string>("CurrentStatus") },
                NextStage = new PurposeStage { PurposeStageID = dr.GetValue<int?>("NextStatusID"), PurposeStageName = dr.GetValue<string>("NextStatus") },
                AssetTranIdNullable = dr.GetValue<int?>("AssetTranIdNullable"),
                ServiceStatus = dr.GetValue<string>("ServiceStatus"),
                FARSerialNo = dr.GetValue<string>("FARSerialNo"),
                FARID = dr.GetValue<string>("FARID"),
                StatusName=dr.GetValue<string>("StatusName"),
                CategoryName=dr.GetValue<string>("CategoryName"),
                ATHistoryID= dr.GetValue<int>("ATHistoryID"),
                IsDirectDeploy=dr.GetValue<bool>("IsDirectDeploy"),
                RowNo=dr.GetValue<int>("RowNo"),
                xRank=dr.GetValue<int>("xRank"),
                CancellationRemarks = dr.GetValue<string>("CancellationRemarks"),
                IsApproverReq = dr.GetValue<int>("IsApproverReq"),
                Approvers = dr.GetValue<string>("Approvers"),
                ReplaceTempDate = dr.GetValue<string>("ReplaceTempDate"),
                ReplacementAssest = dr.GetValue<string>("ReplacementAssest"),
                DeploymentType = dr.GetValue<string>("DeploymentType")
                

            };
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="dr"></param>
        /// <returns></returns>
        private static Engineer GetEngineerExtension(DataRow dr)
        {
            var eng = new Engineer
            {
                PSID = dr.GetValue<string>("PSID"),
                Name = dr.GetValue<string>("NAME_DISPLAY"),
                SysTeamID = dr.GetValue<int?>("TeamID"),
                TeamName = dr.GetValue<string>("TeamName"),
                SysEngineerID = dr.GetValue<int>("SysEngineerID"),
                SysEngineerTypeID = dr.GetValue<int?>("SysEngineerTypeID"),
                Type = dr.GetValue<string>("Type"),
                ModBy = dr.GetValue<string>("ModBy"),
                ModDt = dr.GetValue<DateTime?>("ModDt"),
                Locations = new List<Location>{new Location
                {
                    LocationID = dr.GetValue<int?>("LocationID")
                    , LocationName = dr.GetValue<string>("LocationName")
                    , BuildingInfo = new List<BuildingInfo>{
                        new BuildingInfo{
                            BuildingId = dr.GetValue<int?>("BuildingId"), BuildingFloorId = dr.GetValue<int?>("BuildingFloorId"), FloorNo = dr.GetValue<string>("FloorNo"), BuildingName = dr.GetValue<string>("BuildingName")
                    }}
                }},
                IsDefault=Convert.ToBoolean(dr.GetValue<Boolean?>("IsDefault"))

            };
            return eng;
        }

        /// <summary>
        /// To fetch value of column in a row
        /// </summary>
        /// <typeparam name="T">Returns Generic type</typeparam>
        /// <param name="row">DataRow</param>
        /// <param name="columnName">Column Name</param>
        /// <returns></returns>
        private static T GetValue<T>(this DataRow row, string columnName)
        {
            if (row.Table.Columns.Contains(columnName))
            {
                return row.Field<T>(columnName);
            }
            else
            {
                return default(T);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static List<Engineer> ConvertToEngineer(this DataSet source)
        {
            var engineers = new List<Engineer>();
            if (!source.CheckNULL())
            {
                engineers = source.Tables[0].AsEnumerable().Select(s => GetEngineerExtension(s)).ToList();
            }
            return engineers;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static List<Location> ConvertToLocations(this DataSet source)
        {
            var locations = new List<Location>();
            if (!source.CheckNULL())
            {
                var result = source.Tables[0].AsEnumerable()
                    .Select(s => new
                    {
                        LocationID = s.Field<int>("LocationID"),
                        BuildingId = s.Field<int>("BuildingID"),
                        BuildingName = s.Field<string>("BuildingName"),
                        BuildingFloorId = s.Field<int?>("BuildingFloorID"),
                        FloorNo = s.Field<string>("FloorNo"),
                    }).ToList();

                result.ForEach(x =>
                {
                    if (locations.Any(e => e.LocationID == x.LocationID))
                    {
                        locations.Where(w => w.LocationID == x.LocationID).First().BuildingInfo.Add(new BuildingInfo
                        {
                            BuildingFloorId = x.BuildingFloorId,
                            BuildingId = x.BuildingId,
                            BuildingName = x.BuildingName,
                            FloorNo = x.FloorNo
                        });
                    }
                    else
                    {
                        locations.Add(new Location
                        {
                            LocationID = x.LocationID,
                            BuildingInfo = new List<BuildingInfo>{new BuildingInfo
                            {
                                BuildingFloorId = x.BuildingFloorId, BuildingId= x.BuildingId, BuildingName = x.BuildingName, FloorNo= x.FloorNo
                            }}
                        });
                    }
                });

            }
            return locations;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static bool CheckNULL(this DataSet source)
        {
            if (source != null)
            {
                if (source.Tables.Count > 0)
                    return false;

                return true;
            }
            return true;
        }

        /// <summary>
        /// Converts object value into nullable int
        /// </summary>
        /// <param name="source">data</param>
        /// <returns>converted value</returns>
        public static int? ToInt(this object source)
        {
            if (source == null || string.IsNullOrEmpty(source.ToString()))
                return null;

            return Convert.ToInt32(source.ToString());
        }

        /// <summary>
        /// Converts object value if null to empty string
        /// </summary>
        /// <param name="source">data</param>
        /// <returns>converted value</returns>
        public static string CheckEmptyObj(this object source)
        {
            return source == null ? "" : source.ToString();
        }

        /// <summary>
        /// Linq distinct, which does the distinct by property.
        /// </summary>
        /// <typeparam name="TSource">IEnumerable object</typeparam>
        /// <typeparam name="TKey">key selector delegate</typeparam>
        /// <param name="source">IEnumerable object</param>
        /// <param name="keySelector">key selector delegate</param>
        /// <returns>IEnumerable of fillterd source</returns>
        public static IEnumerable<TSource> DistinctBy<TSource, TKey>(this IEnumerable<TSource> source, Func<TSource, TKey> keySelector)
        {
            HashSet<TKey> seenKeys = new HashSet<TKey>();
            foreach (TSource element in source)
            {
                if (seenKeys.Add(keySelector(element)))
                {
                    yield return element;
                }
            }
        }

    }


    /// <summary>
    /// 
    /// </summary>
    public class UserProfileDetail
    {
        public string PSID { get; set; }
        public string Name { get; set; }
        public int? FloorID { get; set; }
        public bool IsGaurd { get; set; }
        public string AccessGroupName { get; set; }
        public int? AcessGroupID { get; set; }
        public string Location { get; set; }

        public string Worklocation { get; set; }
    }

}
