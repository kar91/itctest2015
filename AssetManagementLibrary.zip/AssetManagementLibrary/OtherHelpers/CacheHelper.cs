﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;

namespace AssetManagementLibrary.OtherHelpers
{
    /// <summary>
    /// Helper class for adding and retriving the values from managed cache
    /// </summary>
    public class CacheHelper
    {
        /// <summary>
        /// .Net guarantees of thread safe for static fields
        /// </summary>
        static readonly CacheHelper AsssetCache = new CacheHelper();

        private readonly MemoryCache _cache = new MemoryCache("CachingProvider");


        private CacheHelper() { }

        /// <summary>
        /// Property for retriving the instance of the cache helper
        /// </summary>
        public static CacheHelper GetInstance
        {
            get
            {
                return AsssetCache;
            }
        }

        /// <summary>
        /// Gets the value from the cache
        /// </summary>
        /// <typeparam name="TCacheobject">Generic type for the return object</typeparam>
        /// <param name="key">key for the value</param>
        /// <param name="aquire">delegate for the retriving the value</param>
        /// <param name="minutes">minutes to hold the value in the cache</param>
        /// <param name="isLongTermCache">Stores in cache till 8 PM for the day</param>
        /// <param name="dependencies">any dependencies for this key/value</param>
        /// <returns>Tcacheobject</returns>
        public TCacheobject GetValue<TCacheobject>(string key, Func<TCacheobject> aquire, int minutes, bool isLongTermCache, params string[] dependencies)
        {
            if (_cache.Contains(key)) // here cache is MemoryCache.Default
            {
                return (TCacheobject)_cache.Get(key);
            }

            var result = aquire();
            AddValue(key, result, minutes, isLongTermCache, dependencies);

            return result;
        }

        /// <summary>
        /// Adding value to the cache
        /// </summary>
        /// <param name="key">key for the value</param>
        /// <param name="value">Value to be added</param>
        /// <param name="minutes">minutes to hold the value in the cache</param>
        /// <param name="isLongTermCache">Stores in cache till 8 PM for the day</param>
        /// <param name="dependencies">any dependencies for this key/value</param>
        public void AddValue(string key, object value, int minutes, bool isLongTermCache, string[] dependencies)
        {
            var policy = new CacheItemPolicy
            {
                AbsoluteExpiration =
                    isLongTermCache ? DateTime.Now.AddHours(8) : DateTime.Now.AddMinutes(minutes)
            };

            if (dependencies != null && dependencies.Any())
            {
                policy.ChangeMonitors.Add(
                    MemoryCache.Default.CreateCacheEntryChangeMonitor(dependencies)
                );
            }

            _cache.Add(key, value, policy);
        }

        /// <summary>
        /// Removes the cahche content based on the key passed
        /// </summary>
        /// <param name="key">string value which holds the key</param>
        public void Remove(string key)
        {
            if (_cache.Contains(key)) // here cache is MemoryCache.Default
            {
                _cache.Remove(key);
            }
        }

    }
}
