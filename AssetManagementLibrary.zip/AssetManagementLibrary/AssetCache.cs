﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Caching;

namespace AssetManagementLibrary
{
    public class AssetCache
    {
        /// <summary>
        /// .Net guarantees of thread safe for static fields
        /// </summary>
        static readonly AssetCache _asssetCache = new AssetCache();

        private MemoryCache _cache = new MemoryCache("CachingProvider");

        public AssetCache GetInstance
        {
            get
            {
                return _asssetCache;
            }
        }

        public Tcacheobject GetValue<Tcacheobject>(string key, Func<Tcacheobject> aquire, int minutes, params string[] dependencies)
        {
            if (_cache.Contains(key)) // here cache is MemoryCache.Default
            {
                return (Tcacheobject)_cache.Get(key);
            }

            var result = aquire();
            AddValue(key, result, minutes, dependencies);

            return result;
        }

        private void AddValue(string key, object value, int minutes, string[] dependencies)
        {
            var policy = new CacheItemPolicy
            {
                AbsoluteExpiration = DateTimeOffset.Now.AddMinutes(minutes)
            };

            if (dependencies != null && dependencies.Count() > 0)
            {
                policy.ChangeMonitors.Add(
                    MemoryCache.Default.CreateCacheEntryChangeMonitor(dependencies)
                );
            }

            _cache.Add(key, value, policy);
        }
    }
}
