﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace AssetManagement
{


    public class InputParameters
    {
        public string SqlParam { get; set; }
        public string ParamValue { get; set; }
    }

    /// <summary>
    /// An ADO.NET helper class
    /// </summary>
    public class DBHelper : IDisposable
    {
        
        // Internal members
        private readonly string _connString = ConfigurationManager.ConnectionStrings["AMSConnectionString"].ConnectionString;

        private SqlConnection _conn = null;
        private SqlTransaction _trans = null;
        private bool _disposed = false;
        public string ErrortoDisplay = "";


        /// <summary>
        /// Sets or returns the connection string use by all instances of this class.
        /// </summary>
        private static string ConnectionString { get; set; }

        /// <summary>
        /// Returns the current SqlTransaction object or null if no transaction
        /// is in effect.
        /// </summary>
        private SqlTransaction Transaction
        {
            get { return _trans; }
        }

        /// <summary>
        /// Constructor using global connection string.
        /// </summary>
        public DBHelper()
        {
            Connect();
        }

        /// <summary>
        /// Constructure using connection string override
        /// </summary>
        /// <param name="connString">Connection string for this instance</param>
        public DBHelper(string connString)
        {
            _conn = new SqlConnection(_connString);
            Connect();
        }

        // Creates a SqlConnection using the current connection string
        private void Connect()
        {
            _conn = new SqlConnection(_connString);
            _conn.Open();
        }

        /// <summary>
        /// Constructs a SqlCommand with the given parameters. This method is normally called
        /// from the other methods and not called directly. But here it is if you need access
        /// to it.
        /// </summary>
        /// <param name="qry">SQL query or stored procedure name</param>
        /// <param name="type">Type of SQL command</param>
        /// <param name="parameters">Query arguments. Arguments should be in pairs where one is the
        /// name of the parameter and the second is the value. The very last argument can
        /// optionally be a SqlParameter object for specifying a custom argument type</param>
        /// <returns></returns>
        private SqlCommand CreateCommand(string qry, CommandType type, List<InputParameters> parameters)
        {
            SqlCommand cmd = new SqlCommand(qry, _conn);

            // Associate with current transaction, if any
            if (_trans != null)
                cmd.Transaction = _trans;

            // Set command type
            cmd.CommandType = type;

            if (parameters == null) return cmd;
            //// Construct SQL parameters
            foreach (var item in parameters)
            {
                cmd.Parameters.AddWithValue("@" + item.SqlParam.ToString() + "", item.ParamValue);

            }
            return cmd;
        }


        #region Transaction Members

        /// <summary>
        /// Begins a transaction
        /// </summary>
        /// <returns>The new SqlTransaction object</returns>
        public SqlTransaction BeginTransaction()
        {
            Rollback();
            _trans = _conn.BeginTransaction();
            return Transaction;
        }

        /// <summary>
        /// Commits any transaction in effect.
        /// </summary>
        public void Commit()
        {
            if (_trans != null)
            {
                _trans.Commit();
                _trans = null;
            }
        }

        /// <summary>
        /// Rolls back any transaction in effect.
        /// </summary>
        private void Rollback()
        {
            if (_trans != null)
            {
                _trans.Rollback();
                _trans = null;
            }
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                // Need to dispose managed resources if being called manually
                if (disposing)
                {
                    if (_conn != null)
                    {
                        Rollback();
                        _conn.Dispose();
                        _conn = null;
                    }
                }
                _disposed = true;
            }
        }

        #endregion

        #region DBFunctions

        public DataSet GetDataSet(string spName, CommandType cmdType, List<InputParameters> parameters = null)
        {
            try
            {
                var cmd = CreateCommand(spName, cmdType, parameters);
                var sda = new SqlDataAdapter { SelectCommand = cmd };
                var dataset = new DataSet();

                sda.Fill(dataset);
                writeLog("Fetch successful  executing sp :" + spName + " at " + DateTime.Now.ToString() + "",
                    "generic data  Handler");
                return dataset;
            }

            catch (Exception ex)
            {
                writeLog("CRUD unsuccesful successful  error :" + ex.Message + " at " + DateTime.Now.ToString() + "",
                    "generic data  Handler");
                ErrortoDisplay = ex.Message;


                return null;
            }

        }


        public bool ExecuteNonQuery(string spName, CommandType cmdType, List<InputParameters> parameters = null)
        {
            try
            {

                var cmd = CreateCommand(spName, cmdType, parameters);
                cmd.ExecuteNonQuery();

                writeLog(
                    "Fetch successful  executing sp :" + spName + " at " + DateTime.Now.ToString() + "",
                    "generic data  Handler");

                return true;
            }

            catch (Exception ex)

            {
                writeLog(
                    "Fetch unsuccesful successful  error :" + ex.Message + " at " + DateTime.Now.ToString() + "",
                    "generic data  Handler");

                ErrortoDisplay = ex.Message;

                return false;

            }

        }

        #endregion

        private void writeLog(string message, string filepreix)
        {

            //    string stat = WebConfigurationManager.AppSettings["Trace"];


            //    if (stat == "yes")
            //    {
            //        FileStream fileStream = null;
            //        StreamWriter streamWriter = null;
            //        try
            //        {
            //            string logFilePath = "c:\\XpertPlusAccount\\";

            //            logFilePath = logFilePath + filepreix + "-" + DateTime.Today.ToString("yyyyMMdd") + "." + "txt";

            //            if (logFilePath.Equals("")) return;
            //            #region Create the Log file directory if it does not exists 
            //            DirectoryInfo logDirInfo = null;
            //            FileInfo logFileInfo = new FileInfo(logFilePath);
            //            logDirInfo = new DirectoryInfo(logFileInfo.DirectoryName);
            //            if (!logDirInfo.Exists) logDirInfo.Create();
            //            #endregion Create the Log file directory if it does not exists

            //            if (!logFileInfo.Exists)
            //            {
            //                fileStream = logFileInfo.Create();
            //            }
            //            else
            //            {
            //                fileStream = new FileStream(logFilePath, FileMode.Append);
            //            }
            //            streamWriter = new StreamWriter(fileStream);
            //            streamWriter.WriteLine(message);
            //        }
            //        finally
            //        {
            //            if (streamWriter != null) streamWriter.Close();
            //            if (fileStream != null) fileStream.Close();
            //        }
            //    }
            //}

        }

    }
}

