﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary
{
    public class ItemEntityClass
    {
        #region Private variables
        private int itemId;
        private string itemName;
        private string itemDescription;
        private string itemUtilizationRemarks;
        private int technologyID;
        private int itemClassID;
        private int manufacturerID;
        private int vendorID;
        private string pOSentTo;
        private bool purchased;
        private string itemModelNumber;
        private string itemSerialNumber;
        private DateTime itemPurchasedDate;
        private string itemPrice;
        private int itemWarrentyPeriod;
        private DateTime itemPOIssueDate;
        private string i3lAssetNumber;
        private DateTime installationDate;
        private string itemPartNumber;
        private int itemQuantity;
        private string itemAMC;
        private string periodical;
        private string scheduled;
        private string assetType;
        private string assetstatus;
        private string cubiclestatus;
        private int cubicleStatusID;
        private int assetStatusID;
        private int assetTypeID;
        private string pONumber;
        private string gRNumber;
        private string bondNumber;
       // private int modifiedBy;

        private DateTime grDate;
        private DateTime assetDateTime;
        private DateTime taggedDate;
        private int hhtID;
        private int itemStatus;
        private int printStatus;
        private string invoiceNumber;
        private DateTime invoiceDate;
        private string remarks;
        private bool itemType;
        private string challanNumber;
        private DateTime challanDate;
        private int teamID;
        private string currency;
        private string companyID;

        private string Buildingname;
        private string Areaname;
        private string Locationname;
        private string Cubiclestatus;
        private string Cubiclenumber;
        private string Modifiedby;
        private string Serialnumber;
        private string Qrcodenumber;
        private string Farnumber;
        private string Assettype;
        private string Assetstatus;
        private string Psid;
        private string name;          
        private DateTime Scandate;  


        #endregion

        #region Properties

        public string BuildingName
        {
            get { return Buildingname; }
            set { Buildingname = value; }
        }
        public int CubicleStatusID
        {
            get { return cubicleStatusID; }
            set { cubicleStatusID = value; }
        }
        public string CubicleStatus
        {
            get { return cubiclestatus; }
            set { cubiclestatus = value; }
        }
        public int AssetStatusID
        {
            get { return assetStatusID; }
            set { assetStatusID = value; }
        }

        public string AssetStatus
        {
            get { return assetstatus; }
            set { assetstatus = value; }
        }

        public string AssetType
        {
            get { return assetType; }
            set { assetType = value; }
        }

        public int AssetTypeID
        {
            get { return assetTypeID; }
            set { assetTypeID = value; }
        }
        public string AreaName
        {
            get { return Areaname; }
            set { Areaname = value; }
        }

        public string LocationName
        {
            get { return Locationname; }
            set { Locationname = value; }
        }
       

        public string CubicleNumber
        {
            get { return Cubiclenumber; }
            set { Cubiclenumber = value; }
        }

        public string SerialNumber
        {
            get { return Serialnumber; }
            set { Serialnumber = value; }
        }

        public string QRCodeNumber
        {
            get { return Qrcodenumber; }
            set { Qrcodenumber = value; }
        }

        public string FARNumber
        {
            get { return Farnumber; }
            set { Farnumber = value; }
        }  

        public string PSID
        {
            get { return Psid; }
            set { Psid = value; }
        }

        public string Name  
        {
            get { return name; }
            set { name = value; }
        }

        public DateTime ScanDate
        {
            get { return Scandate; }
            set { Scandate = value; }
        }

        public string ModifiedBy
        {
            get { return Modifiedby; }
            set { Modifiedby= value; }
        }

        public int ItemID
        {
            get { return itemId; }
            set { itemId = value; }
        }

        public string ItemName
        {
            get { return itemName; }
            set { itemName = value; }
        }

        public string ItemDescription
        {
            get { return itemDescription; }
            set { itemDescription = value; }
        }

        public string ItemUtilizationRemarks
        {
            get { return itemUtilizationRemarks; }
            set { itemUtilizationRemarks = value; }
        }

        public int TechnologyID
        {
            get { return technologyID; }
            set { technologyID = value; }
        }

        public int ItemClassID
        {
            get { return itemClassID; }
            set { itemClassID = value; }
        }

        public int ManufacturerID
        {
            get { return manufacturerID; }
            set { manufacturerID = value; }
        }

        public int VendorID
        {
            get { return vendorID; }
            set { vendorID = value; }
        }

        public string POSentTo
        {
            get { return pOSentTo; }
            set { pOSentTo = value; }
        }

        public bool Purchased
        {
            get { return purchased; }
            set { purchased = value; }
        }

        public string ItemModelNumber
        {
            get { return itemModelNumber; }
            set { itemModelNumber = value; }
        }

        public string ItemSerialNumber
        {
            get { return itemSerialNumber; }
            set { itemSerialNumber = value; }
        }

        public DateTime ItemPurchasedDate
        {
            get { return itemPurchasedDate; }
            set { itemPurchasedDate = value; }
        }

        public string ItemPrice
        {
            get { return itemPrice; }
            set { itemPrice = value; }
        }

        public int ItemWarrentyPeriod
        {
            get { return itemWarrentyPeriod; }
            set { itemWarrentyPeriod = value; }
        }

        public DateTime ItemPOIssueDate
        {
            get { return itemPOIssueDate; }
            set { itemPOIssueDate = value; }
        }

        public string I3lAssetNumber
        {
            get { return i3lAssetNumber; }
            set { i3lAssetNumber = value; }
        }

        public DateTime InstallationDate
        {
            get { return installationDate; }
            set { installationDate = value; }
        }

        public string ItemPartNumber
        {
            get { return itemPartNumber; }
            set { itemPartNumber = value; }
        }

        public int ItemQuantity
        {
            get { return itemQuantity; }
            set { itemQuantity = value; }
        }

        public string ItemAMC
        {
            get { return itemAMC; }
            set { itemAMC = value; }
        }

        public string Periodical
        {
            get { return periodical; }
            set { periodical = value; }
        }

        //public string Scheduled
        //{
        //    get { return scheduled; }
        //    set { scheduled = value; }
        //}


        public string PONumber
        {
            get { return pONumber; }
            set { pONumber = value; }
        }

        public string GRNumber
        {
            get { return gRNumber; }
            set { gRNumber = value; }
        }

        public string BondNumber
        {
            get { return bondNumber; }
            set { bondNumber = value; }
        }

        //public int ModifiedBy
        //{
        //    get { return modifiedBy; }
        //    set { modifiedBy = value; }
        //}


        public DateTime GrDate
        {
            get { return grDate; }
            set { grDate = value; }
        }

        public DateTime AssetDateTime
        {
            get { return assetDateTime; }
            set { assetDateTime = value; }
        }
        public DateTime TaggedDate
        {
            get { return taggedDate; }
            set { taggedDate = value; }
        }
        public int HhtID
        {
            get { return hhtID; }
            set { hhtID = value; }
        }
        public int ItemStatus
        {
            get { return itemStatus; }
            set { itemStatus = value; }
        }
        public int PrintStatus
        {
            get { return printStatus; }
            set { printStatus = value; }
        }
        public string InvoiceNumber
        {
            get { return invoiceNumber; }
            set { invoiceNumber = value; }
        }
        public DateTime InvoiceDate
        {
            get { return invoiceDate; }
            set { invoiceDate = value; }
        }
        public string Remarks
        {
            get { return remarks; }
            set { remarks = value; }
        }
        public bool ItemType
        {
            get { return itemType; }
            set { itemType = value; }
        }
        public string ChallanNumber
        {
            get { return challanNumber; }
            set { challanNumber = value; }
        }
        public DateTime ChallanDate
        {
            get { return challanDate; }
            set { challanDate = value; }
        }
        public int TeamID
        {
            get { return teamID; }
            set { teamID = value; }
        }
        public string Currency
        {
            get { return currency; }
            set { currency = value; }
        }

        public string CompanyID
        {
            get { return companyID; }
            set { companyID = value; }
        }
        #endregion
    }
}
