﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities.Movement
{
    public class BuildingInfo
    {
        public int? BuildingId { get; set; }

        public int? BuildingFloorId { get; set; }

        public string FloorNo { get; set; }

        public string BuildingName { get; set; }
    }
}
