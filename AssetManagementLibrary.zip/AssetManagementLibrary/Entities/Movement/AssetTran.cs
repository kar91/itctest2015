﻿using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations.Schema;

namespace AssetManagementLibrary.Entities.Movement
{
    public class AssetTran
    {
        public int AssetTranId { get; set; } // AssetTranID (Primary key)
        public int? AssetId { get; set; } // AssetID
        public string HpsmNo { get; set; } // HPSMNo
        public int? SysPurposeId { get; set; } // SysPurposeID

        [NotMapped]
        public string PurposeName { get; set; }
        public int? FromFloorId { get; set; } // FromFloorID
        public int? FromCubicleId { get; set; } // FromCubicleID
        public string FromPsid { get; set; } // FromPSID
        public string FromBuildingEnggId { get; set; } // FromBuildingEnggID
        public int? ToFloorId { get; set; } // ToFloorID
        public int? ToCubicleId { get; set; } // ToCubicleID
        public string ToPsid { get; set; } // ToPSID
        public string MovementEnggId { get; set; } // MovementEnggID
        public string ToBuildingEnggId { get; set; } // ToBuildingEnggID
        public string CreatedByPsid { get; set; } // CreatedByPSID
        public string Tier1LeadId { get; set; } // Tier1LeadID
        public string Tier1EnggId { get; set; } // Tier1EnggID
        public string ApprovedByPsid { get; set; } // ApprovedByPSID
        public string EndUserId { get; set; } // EndUserID
        public int? EndUserCubicleID { get; set; } // ToCubicleID

        public bool? IsEndUserAcknowledged { get; set; } // IsEndUserAcknowledged
        public System.DateTime? ModDt { get; set; } // ModDt
        public string ModBy { get; set; } // ModBy
        public int? SysPurposeStageId { get; set; } // SysPurposeStageID
        public string Comments { get; set; } // Comments (length: 100)
        public List<PurposeStage> NextStages { get; set; } //List of Next Stage
        public PurposeStage CurrentStage { get; set; } // Current Stage
    }
}
