﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities.Movement.Report
{
    public class Form
    {
        public Header Header { get; set; }

        public List<Owner> Owners { get; set; }

        public List<AssetDetails> Assets { get; set; }

        public Creator Creator { get; set; }

        public Movement From { get; set; }

        public Movement To { get; set; }
    }

    public class Movement
    {
        public string Psid { get; set; }

        public string Name { get; set; }
        
        public string BuildingName { get; set; }

        public string Floor { get; set; }

        public string Cubicle { get; set; }
    }
}
