﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities.Movement.Report
{
    public class Owner
    {
        public string PSID { get; set; }

        public string Name { get; set; }

        public string ContactNo { get; set; }

        public string BuildingName { get; set; }

        public string Floor { get; set; }

        public string CubicleNo { get; set; }

        public string Department { get; set; }
    }
}
