﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities.Movement.Report
{
    public class Header
    {
        public string Location { get; set; }

        public string HpsmNo { get; set; }

        public string FormNO { get; set; }

        public string Purpose { get; set; }

        public string Date { get; set; }

        public string TicketNo { get; set; }

        public string Remarks { get; set; }

        public string IsReplacement { get; set; }
    }
}
