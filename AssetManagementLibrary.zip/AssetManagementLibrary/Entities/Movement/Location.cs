﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities.Movement
{
    /// <summary>
    /// / Maintains the location with corresponding buildings
    /// </summary>
    public class Location
    {
        public int? LocationID { get; set; }

        public string LocationName { get; set; }

        public List<BuildingInfo> BuildingInfo { get; set; }
    }
}
