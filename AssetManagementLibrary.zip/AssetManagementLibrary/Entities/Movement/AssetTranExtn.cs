﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities.Movement
{
    /// <summary>
    /// Extenstion of assetTran, Had to design this extension as the DevExpress doesnt support the hieracy level data binding
    /// </summary>
    public class AssetTranExtn : AssetTran
    {
        public PurposeStage NextStage { get; set; }
        public string AssetType { get; set; } // AssetType
        public string SerialNo { get; set; } // Serial Number
        public string QRCode { get; set; } // QR Code
        public string FromLocation { get; set; } // From Location
        public string FromBuilding { get; set; } // From Building Name
        public string FromArea { get; set; } // From Area Name
        public string FromCubicleNo { get; set; } // From Cubicle No
        public string FromName { get; set; }
        public string FromFloor { get; set; }
        public string ToLocation { get; set; } // To Location
        public string ToBuilding { get; set; } // From Building Name
        public string ToArea { get; set; } // From Area Name
        public string ToCubicleNo { get; set; } // From Cubicle No
        public string FARNumber { get; set; } // FAR Number
        public string ToName { get; set; } // To Name
        public string ToFloor { get; set; }
        public string CurrentStatus { get; set; }
        public string NextStatus { get; set; }
        public string OverSeer { get; set; }

        public string Psid { get; set; } // Temporary, for Large combobox data

        public int? FromBuildingId { get; set; }
        public int? ToBuildingId { get; set; }
        public string CreatedByName { get; set; }
        public string FromEngineer { get; set; }
        public string ToEngineer { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? DateConfigured { get; set; }
        public string ToEmailID { get; set; }
        public string RejectType { get; set; }
        public string AccessGroup { get; set; }
        public bool IsInTransit { get; set; }
        public bool IsReplacement { get; set; }
        public string ReplacementDate { get; set; }
        public int AssetCount { get; set; }
        public string AssetStatus { get; set; }
        public int? ReasonID { get; set; }
        public bool IsConfigureRequired { get; set; }
        public string AssetCategory { get; set; }

        //Make and model for asset added only for end user page
        public string AssetMake { get; set; }
        public string AssetModel { get; set; }

        public int IsBlocked { get; set; }

        //06/03/2017  - 19047
        public bool IsTemprory { get; set; }

        public string ReturnDate { get; set; }

        public string ReplacementAsset { get; set; }
        //end

        public string NextStageInfo
        {
            get
            {
                var values = string.Empty;
                if (NextStages == null) return values;
                this.NextStages.ForEach(n => values += string.Format("{0}-{1}|", n.PurposeStageID, n.PurposeStageName));
                values = values.Remove(values.LastIndexOf('|'), 1);
                return values;
            }
        }

        public int? AssetTranIdNullable { get; set; }

        public string ServiceStatus { get; set; }
        public string FARSerialNo { get; set; }

        public string FARID { get; set; }

        public string StatusName { get; set; }

        public string CategoryName { get; set; }

        public string IsInTransitStr
        {
            get
            {
                return IsInTransit ? "Yes" : "No";
            }
        }

        public int ATHistoryID { get; set; }

        //17/04/2017
        public bool IsDirectDeploy { get; set; }

        //24/04/2017
        public string EndUserEditReason { get; set; }

        //26/04/2017
        public int RowNo { get; set; }
        public int xRank { get; set; }
        public string EndUserName { get; set; }
        public string CancellationRemarks { get; set; }

        //09/05/2017
        public int IsApproverReq { get; set; }

        public string Approvers { get; set; }

        public string ReplaceTempDate { get; set; }

        public string ReplacementAssest { get; set; }

        public string DeploymentType { get; set; }

    }
}
