﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities
{
    public class UserGroup
    {
        public string GroupName { get; set; }
        public int? GroupID { get; set; }
    }
}
