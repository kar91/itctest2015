﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities.Movement
{
   public class MasterData
    {
        public string Name { get; set; }
        public string KeyName { get; set; }
        public int Value { get; set; }
    }
}
