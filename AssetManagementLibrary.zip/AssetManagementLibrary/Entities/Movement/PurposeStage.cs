﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities.Movement
{
    public class PurposeStage
    {
        public int? PurposeStageID { get; set; }

        public string PurposeStageName { get; set; }
    }
}
