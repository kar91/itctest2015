﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities.Movement
{
    public class Engineer
    {
        public string PSID { get; set; }

        public string Name { get; set; }

        public List<Location> Locations { get; set; }

        public int? SysTeamID { get; set; }

        public string TeamName { get; set; }

        public int? SysEngineerTypeID { get; set; }

        public string Type { get; set; }

        public string ModBy { get; set; }

        public DateTime? ModDt { get; set; }

        public int SysEngineerID { get; set; }


        /// <summary>
        /// TO BE REMOVED
        /// </summary>
        public List<BuildingInfo> BuildingInfo { get; set; }

        //20/02/2017
        public Boolean IsDefault { get; set; }
        //End
    }
}
