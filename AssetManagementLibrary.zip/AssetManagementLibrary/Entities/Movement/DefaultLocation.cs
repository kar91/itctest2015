﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities.Movement
{
    public class DefaultLocation
    {
        public int SysPurposeID { get; set; }
        public int? FromLocationID { get; set; }
        public int? FromBuildingID { get; set; }
        public int? FromFloorID { get; set; }
        public int? FromCubicleID { get; set; }
        public string FromPSID { get; set; }

        public int? ToLocationID { get; set; }
        public int? ToBuildingID { get; set; }
        public int? ToFloorID { get; set; }
        public int? ToCubicleID { get; set; }
        public string ToPSID { get; set; }

        public string ToLocationName { get; set; }
        public string ToBuildingName { get; set; }
        public string ToFloor { get; set; }
        public string ToCubicle { get; set; }
      
    }
}
