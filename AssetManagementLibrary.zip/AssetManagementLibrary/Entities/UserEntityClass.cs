﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary
{
   public class UserEntityClass
    {

        #region Private variables
        private int _userID;
        private string _userName;
        private string _firstName;
        private string _lastName;
        private string _employeeID;
        private string _department;
        private string _contactNumber;
        private string _userGroupTypeID;
        private string _companyID;
        private int _modifiedBy;
        #endregion

        #region Properties
        public int UserID
        {
            get { return _userID; }
            set { _userID = value; }
        }

        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }

        public string EmployeeID
        {
            get { return _employeeID; }
            set { _employeeID = value; }
        }

        public string Department
        {
            get { return _department; }
            set { _department = value; }
        }

        public string ContactNumber
        {
            get { return _contactNumber; }
            set { _contactNumber = value; }
        }

        public string UserGroupTypeID
        {
            get { return _userGroupTypeID; }
            set { _userGroupTypeID = value; }
        }

        public string CompanyID
        {
            get { return _companyID; }
            set { _companyID = value; }
        }

        public int ModifiedBy
        {
            get { return _modifiedBy; }
            set { _modifiedBy = value; }
        }
        #endregion

    }
}
