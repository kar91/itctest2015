﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities
{
    public class UserProfile
    {
        public string PSID { get; set; }
        public string Name { get; set; }
        public List<UserGroup> UserGroups { get; set; }
        public bool IsGaurd { get; set; }
        public int? FloorID { get; set; }

        public string Location { get; set; }

        public string Worklocation { get; set; }
    }
}
