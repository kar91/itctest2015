﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities.Movement.Menu
{
    public class Menu
    {
        public int MenuID { get; set; }

        public string Name { get; set; }

        public string Menu_Desc { get; set; }

        public string Url { get; set; }

        public string ImgUrl { get; set; }

        public string Background_Color { get; set; }

    }
}
