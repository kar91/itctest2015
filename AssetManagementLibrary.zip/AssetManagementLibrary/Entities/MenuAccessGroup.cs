﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities.Movement.Menu
{
    public class MenuAccessGroup
    {
        public int MenuAccessGroupID { get; set; }

        public int AccessGroupID { get; set; }

        public List<MenuGroup> MenuGroup { get; set; }

    }
}
