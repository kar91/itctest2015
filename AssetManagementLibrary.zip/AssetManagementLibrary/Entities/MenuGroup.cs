﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagementLibrary.Entities.Movement.Menu
{
    public class MenuGroup
    {
        public int MenuGroupID { get; set; }

        public string Name { get; set; }

        public List<Menu> Menu { get; set; }
    }
}
